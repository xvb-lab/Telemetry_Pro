# -*- mode: python ; coding: utf-8 -*-
"""
TelemetryPro.spec — build onedir di LMU Telemetry Pro (app autonoma).

Asset inclusi mantenendo la struttura cartelle, così i path
Path(__file__).parent... continuano a funzionare nell'exe.
NB: niente cartella fonts/ (si usano i font di sistema).
"""
from PyInstaller.utils.hooks import collect_submodules

block_cipher = None

datas = [
    ("settings", "settings"),
    ("brandlogo", "brandlogo"),
    ("assets", "assets"),
    ("pyLMUSharedMemory", "pyLMUSharedMemory"),
]

hiddenimports = (
    collect_submodules("core")
    + collect_submodules("telemetry")
    + [
        "PySide6.QtSvg",
        "PySide6.QtSvgWidgets",
    ]
)

a = Analysis(
    ["telemetry_pro.py"],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["gui", "widgets"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="LMU_TelemetryPro",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="LMU_TelemetryPro",
)
