"""
engineer_overlay.py — Race Engineer overlay (stile TinyPedal).

Card frameless trasparente, sempre in primo piano, TRASCINABILE:
  - simbolo ingegnere a sinistra
  - messaggio a destra che compare in FADE a ogni giro chiuso
  - bip radio quando appare il messaggio

Codici messaggio (colorati):
  GOMME:   T++ / T+  = rosso (consumi troppa gomma)   ·  T- / T-- = verde (gestione ok)
  ENERGIA: E++ / E+  = rosso (troppa energia)          ·  E- / E-- = verde (gestione ok)
  (neutro = non mostrato)

USO:
  python engineer_overlay.py
  - trascina la card con il mouse per posizionarla
  - tasto destro sulla card = menu (Demo on/off, Esci)
  - ESC = esci

NOTE: parte in modalità DEMO (cicla messaggi di esempio) così puoi posizionarla
e vedere il fade + il bip. Il collegamento ai dati veri del giro (shared memory
LMU / DB TelemetryPro) è il passo successivo: basta chiamare overlay.push(t_code,
e_code, lap) a ogni giro chiuso.
"""
import sys
from pathlib import Path

from PySide6.QtCore import (Qt, QTimer, QPoint, QByteArray, QPropertyAnimation,
                            QEasingCurve, Property, QUrl)
from PySide6.QtGui import QPainter, QColor, QFont, QAction
from PySide6.QtWidgets import (QApplication, QWidget, QLabel, QHBoxLayout,
                               QVBoxLayout, QFrame, QMenu, QGraphicsOpacityEffect)

try:
    from PySide6.QtSvg import QSvgRenderer
except Exception:
    QSvgRenderer = None

try:
    from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
except Exception:
    QMediaPlayer = QAudioOutput = None

_RADIO_MP3 = Path(__file__).resolve().parent / "assets" / "radio.mp3"
_FONTS_DIR = Path(__file__).resolve().parent / "assets" / "fonts"
_FONT_FAMILY = None


def _ensure_font():
    """Carica una volta il font Titillium Web (pit-wall). Ritorna la famiglia
    o '' se non disponibile (fallback al font di sistema)."""
    global _FONT_FAMILY
    if _FONT_FAMILY is not None:
        return _FONT_FAMILY
    _FONT_FAMILY = ""
    try:
        from PySide6.QtGui import QFontDatabase
        for f in ("TitilliumWeb-Regular.ttf", "TitilliumWeb-SemiBold.ttf",
                  "TitilliumWeb-Bold.ttf"):
            p = _FONTS_DIR / f
            if p.exists():
                i = QFontDatabase.addApplicationFont(str(p))
                fams = QFontDatabase.applicationFontFamilies(i)
                if fams and not _FONT_FAMILY:
                    _FONT_FAMILY = fams[0]
    except Exception:
        _FONT_FAMILY = ""
    return _FONT_FAMILY


def _team_name():
    try:
        import json
        try:
            from core.paths import PROFILE_FILE as p
        except Exception:
            p = Path(__file__).resolve().parent / "settings" / "profile.json"
        d = json.loads(Path(p).read_text(encoding="utf-8"))
        return (d.get("team") or "").strip() or "RACE ENGINEER"
    except Exception:
        return "RACE ENGINEER"


try:
    from core import paths as _paths
    _ENG_CFG = _paths.USER_DIR / "engineer.json"
except Exception:
    _ENG_CFG = Path(__file__).resolve().parent / "settings" / "engineer.json"


def _load_cfg():
    try:
        import json
        return json.loads(_ENG_CFG.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}


def _save_cfg(**kw):
    try:
        import json
        d = _load_cfg(); d.update(kw)
        _ENG_CFG.write_text(json.dumps(d, ensure_ascii=False, indent=2),
                            encoding="utf-8")
    except Exception:
        pass


def _load_lang():
    return _load_cfg().get("lang", "it")


def _save_lang(lang):
    _save_cfg(lang=lang)


def _load_scale():
    try:
        return max(0.5, min(1.8, float(_load_cfg().get("scale", 1.0))))
    except Exception:
        return 1.0


def _save_scale(s):
    _save_cfg(scale=round(float(s), 2))


try:
    import os as _os
    sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
    from core.engineer import Engineer as _Engineer
except Exception:
    _Engineer = None


# ── palette ───────────────────────────────────────────────────────────────
_CARD_BG = QColor(18, 20, 24, 235)      # grafite semitrasparente
_CARD_BORDER = QColor(54, 194, 168, 180)  # teal
_RED = "#ff5b5b"
_GREEN = "#55ff7f"
_DIM = "#9aa0aa"
_FG = "#f2f4f7"

# livelli messaggio: colore accento (icona/bordo) per tipo
_LEVELS = {
    "critical": "#ff3b3b",   # critici (rosso)
    "warn":     "#ffcc33",   # importanti (giallo)
    "info":     "#f2f4f7",   # normali (bianco)
    "good":     "#f2f4f7",   # positivi normali (bianco)
    "green":    "#46e08a",   # tuo best di sessione (verde)
    "best":     "#e23bd0",   # giro/settori veloci, best assoluto (fuxia)
}

# icona ingegnere: cuffia + microfono (headset) in SVG
_ENG_SVG = (
    b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' "
    b"fill='none' stroke='%s' stroke-width='1.8' stroke-linecap='round' "
    b"stroke-linejoin='round'>"
    b"<path d='M4 13v-1a8 8 0 0 1 16 0v1'/>"
    b"<rect x='2.5' y='13' width='3.5' height='6' rx='1.4'/>"
    b"<rect x='18' y='13' width='3.5' height='6' rx='1.4'/>"
    b"<path d='M20 19v1a3 3 0 0 1-3 3h-3'/>"
    b"<circle cx='12' cy='23' r='1'/>"
    b"</svg>"
)


def _code_color(code):
    if not code:
        return _DIM
    return _RED if code[1:2] == "+" else _GREEN     # T+/T++/E+/E++ rosso, T-/.. verde


class _EngIcon(QWidget):
    """Render dell'icona ingegnere (SVG) con colore."""
    def __init__(self, color="#1c9fe0", size=34):
        super().__init__()
        self._sz = size
        self.setFixedSize(size, size)
        self._r = None
        if QSvgRenderer is not None:
            try:
                self._r = QSvgRenderer(QByteArray(_ENG_SVG % color.encode()))
                if not self._r.isValid():
                    self._r = None
            except Exception:
                self._r = None

    def set_color(self, color):
        if QSvgRenderer is None:
            return
        try:
            r = QSvgRenderer(QByteArray(_ENG_SVG % color.encode()))
            self._r = r if r.isValid() else self._r
            self.update()
        except Exception:
            pass

    def paintEvent(self, e):
        if self._r is None:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        self._r.render(p)
        p.end()


class EngineerOverlay(QWidget):
    def __init__(self, standalone=True):
        super().__init__()
        _fam = _ensure_font()
        if _fam:
            f = QFont(_fam); f.setStyleStrategy(QFont.PreferAntialias)
            self.setFont(f)
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setWindowTitle("Race Engineer")
        self._drag = None
        self._standalone = standalone
        self._st = {}          # stato fire-once (no spam dello stesso messaggio)
        self._active = []      # messaggi attualmente a schermo (accorpati)
        self._sev = -1         # severità massima tra gli attivi (per il bordo)
        self._fading_out = False
        self._feed = None      # feed dati live (lazy)
        self.brain = _Engineer(_load_lang()) if _Engineer else None
        self._live_timer = None

        # suono radio (assets/radio.mp3)
        self._player = None
        if QMediaPlayer is not None and _RADIO_MP3.exists():
            try:
                self._player = QMediaPlayer(self)
                self._audio = QAudioOutput(self)
                self._audio.setVolume(1.0)
                self._player.setAudioOutput(self._audio)
                self._player.setSource(QUrl.fromLocalFile(str(_RADIO_MP3)))
            except Exception:
                self._player = None

        # ── card verticale: header (icona + team) + lista messaggi sotto ──
        self.card = QFrame(self); self.card.setObjectName("engCard")
        root = QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self.card)
        cv = QVBoxLayout(self.card); cv.setContentsMargins(14, 10, 18, 12); cv.setSpacing(8)
        self._cv = cv
        self._scale = _load_scale()
        self._msg_rows = []          # (dot, label) per ri-scalare a runtime
        self._msg_px = 16

        # header: icona + (RACE ENGINEER / nome team)
        hdr = QHBoxLayout(); hdr.setSpacing(11)
        self.icon = _EngIcon("#9aa0aa", 30)
        hdr.addWidget(self.icon, 0, Qt.AlignVCenter)
        idcol = QVBoxLayout(); idcol.setContentsMargins(0, 0, 0, 0); idcol.setSpacing(0)
        eyebrow = QLabel("RACE ENGINEER")
        self._eyebrow = eyebrow
        eyebrow.setStyleSheet("color:#6e727b;font-size:8px;font-weight:800;"
                              "letter-spacing:2.5px;background:transparent;")
        self.team = QLabel(_team_name())
        self.team.setStyleSheet("color:#e8eaee;font-size:13px;font-weight:800;"
                                "letter-spacing:1px;background:transparent;")
        idcol.addWidget(eyebrow); idcol.addWidget(self.team)
        hdr.addLayout(idcol); hdr.addStretch()
        cv.addLayout(hdr)

        # divisore (visibile solo coi messaggi)
        self.div = QFrame(); self.div.setObjectName("engDiv"); self.div.setFixedHeight(1)
        self.div.setVisible(False)
        cv.addWidget(self.div)

        # lista messaggi (verticale): compare solo quando ci sono messaggi
        self.msg_host = QWidget(); self.msg_host.setStyleSheet("background:transparent;")
        self.msg_v = QVBoxLayout(self.msg_host)
        self.msg_v.setContentsMargins(0, 2, 0, 0); self.msg_v.setSpacing(6)
        cv.addWidget(self.msg_host)
        self.msg_host.setVisible(False)

        self.setStyleSheet(
            "#engCard{background:#0c0d10;border:1px solid #2a2c30;border-radius:12px;}"
            "#engDiv{background:#23262c;border:none;}")

        # fade sull'intera lista; a fine fade-out la lista si svuota
        self._msg_fx = QGraphicsOpacityEffect(self.msg_host)
        self._msg_fx.setOpacity(0.0)
        self.msg_host.setGraphicsEffect(self._msg_fx)
        self._anim = QPropertyAnimation(self._msg_fx, b"opacity")
        self._anim.setDuration(280)
        self._anim.setEasingCurve(QEasingCurve.InOutQuad)
        self._anim.finished.connect(self._on_anim_done)
        self._hold = QTimer(self); self._hold.setSingleShot(True)
        self._hold.timeout.connect(self._fade_msg_out)

        self.resize(self.sizeHint())
        self._apply_scale()
        self._move_default()

    def _move_default(self):
        scr = QApplication.primaryScreen().availableGeometry()
        self.move(scr.center().x() - self.width() // 2, int(scr.height() * 0.18))

    # ── core: mostra un messaggio (testo già formattato) con livello ──
    def show_msg(self, body, level="info", beep=True, dot=None):
        _sev = {"info": 1, "good": 1, "green": 2, "best": 3, "warn": 4, "critical": 5}.get(level, 1)
        if dot is None:
            dot = _LEVELS.get(level, _LEVELS["info"])
        # se la card stava svanendo, riparti pulito (niente messaggi vecchi)
        if getattr(self, "_fading_out", False) or not self.msg_host.isVisible():
            self._fading_out = False
            self._active = []; self._msg_rows = []
            self._sev = -1
            while self.msg_v.count():
                it = self.msg_v.takeAt(0)
                w = it.widget()
                if w:
                    w.deleteLater()
        added = False
        if body not in self._active:
            self._active.append(body)
            added = True
            _px = getattr(self, "_msg_px", 16)
            _dp = max(1, int(round(7 * float(getattr(self, "_scale", 1.0) or 1.0))))
            row = QWidget(); row.setStyleSheet("background:transparent;")
            rl = QHBoxLayout(row); rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(9)
            d = QLabel(); d.setFixedSize(_dp, _dp)
            d.setProperty("dotcolor", dot)
            d.setStyleSheet("background:%s;border-radius:%dpx;" % (dot, max(1, _dp // 2)))
            rl.addWidget(d, 0, Qt.AlignVCenter)
            lbl = QLabel(body); lbl.setTextFormat(Qt.RichText)
            lbl.setStyleSheet("color:%s;font-size:%dpx;font-weight:600;"
                              "letter-spacing:0.2px;background:transparent;" % (dot, _px))
            rl.addWidget(lbl, 0, Qt.AlignVCenter); rl.addStretch()
            self.msg_v.addWidget(row)
            self._msg_rows.append((d, lbl))
        if _sev > self._sev:
            self._sev = _sev
        accent = _LEVELS[{1: "info", 2: "green", 3: "best", 4: "warn", 5: "critical"}[max(1, self._sev)]]
        self.icon.set_color(accent)
        self.card.setStyleSheet(
            "#engCard{background:#0c0d10;border:1px solid %s;border-radius:12px;}" % accent)
        self.div.setVisible(True)
        self.msg_host.setVisible(True)
        self._refit()
        if added:
            self._play_radio()           # suono radio su ogni nuovo messaggio
        self._fade_msg_in()

    def _apply_scale(self):
        """Riscala tipografia, icona, margini e righe messaggio in base a _scale.
        Tipografia rivista: pesi piu' puliti, meno letter-spacing."""
        s = float(getattr(self, "_scale", 1.0) or 1.0)
        def px(v):
            return max(1, int(round(v * s)))
        self._msg_px = px(16)
        try:
            self._eyebrow.setStyleSheet(
                "color:#7b818c;font-size:%dpx;font-weight:700;"
                "letter-spacing:%.1fpx;background:transparent;" % (px(9), 2.2 * s))
            self.team.setStyleSheet(
                "color:#eef0f3;font-size:%dpx;font-weight:700;"
                "letter-spacing:%.1fpx;background:transparent;" % (px(15), 0.4 * s))
            self.icon.setFixedSize(px(30), px(30))
            self._cv.setContentsMargins(px(14), px(10), px(18), px(12))
            self._cv.setSpacing(px(8))
            self.msg_v.setContentsMargins(0, px(2), 0, 0)
            self.msg_v.setSpacing(px(6))
        except Exception:
            pass
        for d, lbl in getattr(self, "_msg_rows", []):
            try:
                _col = d.property("dotcolor") or _LEVELS["info"]
                d.setFixedSize(px(7), px(7))
                d.setStyleSheet("background:%s;border-radius:%dpx;" % (_col, px(3)))
                lbl.setStyleSheet(
                    "color:%s;font-size:%dpx;font-weight:600;letter-spacing:0.2px;"
                    "background:transparent;" % (_col, self._msg_px))
            except Exception:
                pass
        self._refit()

    def set_scale(self, factor):
        self._scale = max(0.5, min(1.8, float(factor)))
        _save_scale(self._scale)
        self._apply_scale()

    def test_messages(self):
        """Spawna messaggi di prova (dev) per vedere colori/tipografia/durata."""
        samples = [
            ("Giro 1:51.420 · best assoluto", "best"),
            ("S2 +0.412 · Frena prima", "warn"),
            ("Davanti: M. Rossi +0.8", "info"),
            ("Degrado alto · posteriore dx", "warn"),
            ("Box tra 2 · tieni il passo", "critical"),
        ]
        try:
            self.show(); self.raise_()
        except Exception:
            pass
        for body, lvl in samples:
            self.show_msg(body, level=lvl, beep=False)

    def _refit(self):
        """Ricalcola e ridisegna la finestra in modo pulito (frameless trasparente)."""
        try:
            lay = self.layout()
            if lay:
                lay.activate()
        except Exception:
            pass
        self.adjustSize()
        self.resize(self.sizeHint())
        self.update()

    def _on_anim_done(self):
        # fine fade-out: svuota la lista e ripristina header neutro
        if self._msg_fx.opacity() <= 0.01:
            self._fading_out = False
            self._active = []; self._msg_rows = []
            self._sev = -1
            self.div.setVisible(False)
            self.msg_host.setVisible(False)        # nascondi PRIMA di svuotare
            while self.msg_v.count():
                it = self.msg_v.takeAt(0)
                w = it.widget()
                if w:
                    w.deleteLater()
            self.icon.set_color("#9aa0aa")
            self.card.setStyleSheet(
                "#engCard{background:#0c0d10;border:1px solid #2a2c30;border-radius:12px;}")
            self._msg_fx.setOpacity(0.0)
            # rimpicciolisci dopo che il layout si è ricompattato (evita "resta grande")
            QTimer.singleShot(0, self._refit)

    # ── scorciatoie tipiche da ingegnere ──
    def box(self):
        """Carburante < 1 giro: rientro obbligato."""
        self.show_msg("<span style='color:%s'>BOX BOX BOX</span>" % _LEVELS["critical"],
                      "critical")

    def fuel_laps(self, laps):
        """Avviso carburante: giri rimanenti stimati."""
        if laps < 1.0:
            self.box()
            return
        self.show_msg("<span style='color:%s'>FUEL %.1f LAPS</span>" % (_LEVELS["warn"], laps),
                      "warn", beep=False)

    def lift(self, pct):
        """Lift & coast: alza il piede per risparmiare carburante."""
        self.show_msg("<span style='color:%s'>LIFT %d%%</span>" % (_LEVELS["warn"], int(pct)),
                      "warn", beep=False)

    def strategy(self, text):
        """Messaggio strategia generico."""
        self.show_msg("<span style='color:%s'>%s</span>" % (_LEVELS["info"], text),
                      "info", beep=False)

    def consumption(self, t_code=None, e_code=None, lap=None):
        """Consumi gomme/energia: mostra solo i codici forti (++ o --)."""
        important = (t_code in ("T++", "T--")) or (e_code in ("E++", "E--"))
        if not important:
            return
        parts = []
        if t_code:
            parts.append("<span style='color:%s'>%s</span>" % (_code_color(t_code), t_code))
        if e_code:
            parts.append("<span style='color:%s'>%s</span>" % (_code_color(e_code), e_code))
        body = "&nbsp;&nbsp;".join(parts)
        if lap is not None:
            body = ("<span style='color:#9aa0aa'>L%d</span>&nbsp;&nbsp;" % lap) + body
        _red = (_code_color(t_code) == _RED) or (_code_color(e_code) == _RED)
        self.show_msg(body, "info", beep=_red, dot=(_RED if _red else _GREEN))

    # compat: vecchia firma push(t_code, e_code, lap)
    def push(self, t_code=None, e_code=None, lap=None, beep=True):
        self.consumption(t_code, e_code, lap)

    # ── feed dati LIVE (riusa reader + strategy del progetto) ──
    def start_live(self, margin=2.0, hz=1.0):
        """Avvia la lettura live dalla shared memory LMU. Se i moduli del
        progetto non sono importabili (es. fuori dall'app), resta in idle e
        funziona solo il menu Test."""
        try:
            import os
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from telemetry.reader import TelemetryReader
            from telemetry import strategy as _strat
            self._feed = {
                "reader": TelemetryReader(),
                "tracker": _strat.StintTracker(window=3),
                "compute": _strat.compute,
                "margin": margin,
            }
        except Exception:
            self._feed = None
            return False
        self._live_timer = QTimer(self)
        self._live_timer.timeout.connect(self._live_tick)
        self._live_timer.start(int(1000 / max(0.2, hz)))
        return True

    def set_lang(self, lang):
        if self.brain:
            self.brain.set_lang(lang)
        _save_lang("en" if str(lang).lower().startswith("en") else "it")

    def push_msgs(self, msgs):
        """Mostra una lista di messaggi gia' localizzati dal cervello."""
        for m in (msgs or []):
            if not m:
                continue
            body = "<span style='color:%s'>%s</span>" % (m["color"], m["text"])
            self.show_msg(body, level=m["level"], beep=m["beep"], dot=m["color"])

    def feed_latest(self, latest, in_pits=None):
        """Alimentazione dal processo principale: recorder.latest() (strat+raw)."""
        strat = (latest or {}).get("strat") or {}
        raw = (latest or {}).get("raw") or {}
        pits = raw.get("in_pits") if in_pits is None else in_pits
        from core.engineer import session_kind as _sk
        self._eval(strat, pits, laps_done=int(raw.get("laps_completed") or 0),
                   energy_car=(strat.get("constraint") == "VE"),
                   lap_time=raw.get("lap_time"), best=raw.get("best_lap"),
                   session=_sk(raw.get("session_type")), fuel_max=raw.get("fuel_max"))

    def _live_tick(self):
        if not self._feed:
            return
        try:
            d = self._feed["reader"].read()
            if not d:
                self._st = {}            # fuori sessione: azzera fire-once
                return
            self._feed["tracker"].update(d)
            measured = self._feed["tracker"].measured(d)
            strat = self._feed["compute"](measured, self._feed["margin"])
        except Exception:
            return
        self._eval(strat, d.get("in_pits"))

    # ── decide quale messaggio (importante) mostrare, una volta sola ──
    def _eval(self, strat, in_pits, laps_done=0, energy_car=False,
              lap_time=None, best=None, session="race", fuel_max=None):
        if self.brain is None:
            return
        if in_pits:
            self.brain.reset()
            return
        msgs = self.brain.strategy(strat, laps_done=laps_done, in_pits=in_pits,
                                   energy_car=energy_car, lap_time=lap_time,
                                   best_lap_time=best, session=session, fuel_max=fuel_max)
        self.push_msgs(msgs)

    def _play_radio(self):
        if self._player is not None:
            try:
                self._player.stop()
                self._player.setPosition(0)
                self._player.play()
                return
            except Exception:
                pass
        QApplication.beep()              # fallback se mp3/multimedia non disponibili

    def _fade_msg_in(self):
        self._fading_out = False
        self._hold.stop()
        self._anim.stop()
        self._anim.setStartValue(self._msg_fx.opacity())
        self._anim.setEndValue(1.0)
        self._anim.start()
        # durata = base 8s + 2s per ogni messaggio oltre il primo
        n = max(1, len(self._active))
        self._hold.start(8000 + 2000 * (n - 1))

    def _fade_msg_out(self):
        self._fading_out = True
        self._anim.stop()
        self._anim.setStartValue(self._msg_fx.opacity())
        self._anim.setEndValue(0.0)
        self._anim.start()

    # ── trascinamento ──
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._drag is not None and (e.buttons() & Qt.LeftButton):
            self.move(e.globalPosition().toPoint() - self._drag)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def contextMenuEvent(self, e):
        m = QMenu(self)
        sub = m.addMenu("Test message")
        for label, fn in (
            ("BOX BOX BOX", lambda: self.box()),
            ("FUEL 2.0 LAPS", lambda: self.fuel_laps(2.0)),
            ("LIFT 5%", lambda: self.lift(5)),
            ("PIT WINDOW", lambda: self.strategy("PIT WINDOW")),
            ("T-- E+", lambda: self.consumption("T--", "E+")),
            ("E++", lambda: self.consumption(None, "E++")),
        ):
            a = QAction(label, self); a.triggered.connect(fn); sub.addAction(a)
        a_quit = QAction("Quit" if self._standalone else "Hide", self)
        a_quit.triggered.connect(self._close)
        m.addAction(a_quit)
        m.exec(e.globalPos())

    def _close(self):
        if self._standalone:
            QApplication.quit()
        else:
            self.hide()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self._close()


def main():
    app = QApplication(sys.argv)
    w = EngineerOverlay(standalone=True)
    w.start_live()                 # legge live dalla shared memory LMU (se disponibile)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
