#!/usr/bin/env python3
"""
LMU Race Engineer — overlay trasparente sempre in primo piano (stile Tiny Pedal).

A ogni giro chiuso mostra in FADE un messaggio dell'ingegnere sulla gestione di
GOMMA e BENZINA (confronto col giro di spinta dello stint), con un BEEP radio.
Legge il file di registrazione live (.lmtel) che il recorder gia' scrive: non
duplica logica e non serve modificare l'app principale.

USO:   python lmu_engineer.py
- Trascina la finestrella dove vuoi: la posizione viene salvata.
- Tasto destro = chiudi.
"""
import sys
import json
import sqlite3
import threading
from pathlib import Path

from PySide6.QtCore import Qt, QTimer, QPropertyAnimation
from PySide6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel

# --- cartella logs del recorder ---
try:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from core.paths import LOGS_DIR
except Exception:
    import os
    base = os.environ.get("APPDATA") or str(Path.home())
    LOGS_DIR = Path(base) / "LMU_TelemetryPro" / "logs"

CFG = Path(__file__).resolve().parent / "settings" / "engineer_overlay.json"

# soglie verdetto (delta % vs giro di spinta)
SAVE_TH = -3.0
HIGH_TH = 8.0


def _beep():
    """Beep radio breve, non bloccante."""
    def _w():
        try:
            import winsound
            winsound.Beep(1180, 70)
            winsound.Beep(880, 90)
        except Exception:
            try:
                QApplication.beep()
            except Exception:
                pass
    threading.Thread(target=_w, daemon=True).start()


def _latest_file():
    try:
        fs = sorted(LOGS_DIR.glob("*.lmtel"),
                    key=lambda p: p.stat().st_mtime, reverse=True)
        return fs[0] if fs else None
    except Exception:
        return None


def _energy(L):
    v = L.get("ve_used") or 0
    return v if v > 0 else (L.get("fuel_used") or 0)


def _avgw(L):
    ws = [L.get(k) for k in ("w_fl", "w_fr", "w_rl", "w_rr") if L.get(k) is not None]
    return (sum(ws) / len(ws)) if ws else None


def _verdict(delta):
    if delta is None:
        return "\u2014", "#7e828c"
    if delta <= SAVE_TH:
        return "SAVE", "#55ff7f"
    if delta >= HIGH_TH:
        return "HIGH", "#ff5b5b"
    return "OK", "#cfd2d6"


class Engineer(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setMinimumWidth(300)

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        self.card = QWidget()
        self.card.setObjectName("card")
        cl = QVBoxLayout(self.card)
        cl.setContentsMargins(15, 10, 15, 12)
        cl.setSpacing(3)
        self.title = QLabel("RACE ENGINEER")
        self.title.setObjectName("title")
        self.msg = QLabel("waiting for laps\u2026")
        self.msg.setObjectName("msg")
        self.msg.setWordWrap(True)
        self.sub = QLabel("")
        self.sub.setObjectName("sub")
        self.sub.setWordWrap(True)
        cl.addWidget(self.title)
        cl.addWidget(self.msg)
        cl.addWidget(self.sub)
        root.addWidget(self.card)

        self.setStyleSheet(
            "#card{background:rgba(15,16,20,0.88);border:1px solid #2a2c30;"
            "border-radius:12px;}"
            "#title{color:#36c2a8;font-size:10px;font-weight:800;"
            "letter-spacing:1.6px;background:transparent;}"
            "#msg{color:#f2f4f7;font-size:16px;font-weight:800;background:transparent;}"
            "#sub{color:#989ba2;font-size:11px;font-weight:600;background:transparent;}")

        self._anim = QPropertyAnimation(self, b"windowOpacity")
        self.setWindowOpacity(0.0)

        self._file = None
        self._con = None
        self._last_lap = None
        self._drag = None

        self._load_pos()
        self._hide_t = QTimer(self)
        self._hide_t.setSingleShot(True)
        self._hide_t.timeout.connect(self._fade_out)
        self._poll = QTimer(self)
        self._poll.setInterval(700)
        self._poll.timeout.connect(self._tick)
        self._poll.start()
        self.resize(self.sizeHint())
        # messaggio iniziale visibile qualche secondo
        self._show_msg("RACE ENGINEER", "READY", "#36c2a8",
                       "waiting for the next completed lap")
        self.show()

    # ---------- posizione persistente ----------
    def _load_pos(self):
        try:
            d = json.loads(CFG.read_text(encoding="utf-8"))
            self.move(int(d.get("x", 80)), int(d.get("y", 80)))
        except Exception:
            self.move(80, 80)

    def _save_pos(self):
        try:
            CFG.parent.mkdir(parents=True, exist_ok=True)
            CFG.write_text(json.dumps({"x": self.x(), "y": self.y()}), encoding="utf-8")
        except Exception:
            pass

    # ---------- trascinamento / chiusura ----------
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
        elif e.button() == Qt.RightButton:
            self.close()

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        if self._drag is not None:
            self._drag = None
            self._save_pos()

    # ---------- fade ----------
    def _fade_in(self):
        self._anim.stop()
        self._anim.setDuration(260)
        self._anim.setStartValue(self.windowOpacity())
        self._anim.setEndValue(1.0)
        self._anim.start()

    def _fade_out(self):
        self._anim.stop()
        self._anim.setDuration(750)
        self._anim.setStartValue(self.windowOpacity())
        self._anim.setEndValue(0.0)
        self._anim.start()

    def _show_msg(self, title, headline, color, sub, beep=False):
        self.title.setText(title)
        self.msg.setText(headline)
        self.msg.setStyleSheet("color:%s;font-size:16px;font-weight:800;"
                               "background:transparent;" % color)
        self.sub.setText(sub)
        self.resize(self.sizeHint())
        self._fade_in()
        if beep:
            _beep()
        self._hide_t.start(6000)

    # ---------- lettura DB live ----------
    def _open(self, f):
        try:
            if self._con:
                self._con.close()
        except Exception:
            pass
        self._con = sqlite3.connect(str(f), timeout=1.0)
        self._con.row_factory = sqlite3.Row
        self._file = f
        self._last_lap = None

    def _tick(self):
        f = _latest_file()
        if f is None:
            return
        if self._file is None or str(f) != str(self._file):
            self._open(f)
        try:
            rows = self._con.execute(
                "SELECT lap,stint,lap_time,invalid,fuel_used,ve_used,"
                "w_fl,w_fr,w_rl,w_rr FROM laps ORDER BY lap").fetchall()
        except Exception:
            return
        if not rows:
            return
        laps = [dict(r) for r in rows]
        last = laps[-1]
        if last["lap"] == self._last_lap:
            return
        self._last_lap = last["lap"]

        # solo giri validi cronometrati (out-lap / in-lap / invalidi esclusi)
        if last.get("invalid") or not (last.get("lap_time") or 0) > 0:
            return

        stint = last.get("stint") or 1
        sl = [L for L in laps if (L.get("stint") or 1) == stint
              and not L.get("invalid") and (L.get("lap_time") or 0) > 0]
        if not sl:
            return
        push = min(sl, key=lambda L: L["lap_time"])

        # usura per giro (calo wear medio vs giro precedente) all'interno dello stint
        wear_used = {}
        prev = None
        for L in sl:
            a = _avgw(L)
            if prev is not None and a is not None and (prev - a) >= 0:
                wear_used[L["lap"]] = prev - a
            if a is not None:
                prev = a

        if push["lap"] == last["lap"]:
            self._show_msg("RACE ENGINEER", "LAP %d \u00b7 PUSH LAP" % last["lap"],
                           "#36c2a8", "fastest of the stint \u2014 reference", beep=True)
            return

        be = _energy(push)
        e = _energy(last)
        e_d = ((e / be - 1.0) * 100.0) if (be > 0 and e > 0) else None
        bw = wear_used.get(push["lap"])
        lw = wear_used.get(last["lap"])
        w_d = ((lw / bw - 1.0) * 100.0) if (bw and bw > 0 and lw is not None) else None

        fv, fc = _verdict(e_d)
        tv, tc = _verdict(w_d)

        # headline radio in base alla cosa piu' critica
        worst = max([x for x in (e_d, w_d) if x is not None], default=0.0)
        if (e_d is not None and e_d >= HIGH_TH) and (w_d is not None and w_d >= HIGH_TH):
            head, hcol = "EASE OFF \u2014 fuel & tyres high", "#ff5b5b"
        elif e_d is not None and e_d >= HIGH_TH:
            head, hcol = "LIFT & COAST \u2014 fuel high", "#ff5b5b"
        elif w_d is not None and w_d >= HIGH_TH:
            head, hcol = "EASY ON TYRES", "#ff5b5b"
        elif (e_d is not None and e_d <= SAVE_TH) or (w_d is not None and w_d <= SAVE_TH):
            head, hcol = "GOOD MANAGEMENT", "#55ff7f"
        else:
            head, hcol = "ON TARGET", "#cfd2d6"

        def _fmt(v):
            if v is None:
                return "\u2014"
            s = "+" if v >= 0 else "\u2212"
            return "%s%.0f%%" % (s, abs(v))

        sub = "Lap %d \u00b7 FUEL %s %s \u00b7 TYRE %s %s" % (
            last["lap"], fv, _fmt(e_d), tv, _fmt(w_d))
        self._show_msg("RACE ENGINEER", head, hcol, sub, beep=True)


def main():
    app = QApplication(sys.argv)
    w = Engineer()
    w._win_ref = w  # evita garbage collection
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
