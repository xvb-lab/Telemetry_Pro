"""
telemetry_pro.py — Entry point dell'app autonoma LMU Telemetry Pro.

Telemetry Pro e' la suite di analisi telemetrica (Overview, Times, Speed, VE,
Fuel, Hybrid, Tyres, Brakes, Delta, Stint) con registrazione manuale START/STOP.
Gira come applicazione a se', separata dal launcher degli overlay.

Esegui:  python telemetry_pro.py
"""
import os
import sys
from pathlib import Path

# silenzia i warning innocui di DirectWrite sui font bitmap legacy di Windows
os.environ.setdefault("QT_LOGGING_RULES", "qt.qpa.fonts=false;qt.svg=false")

sys.path.insert(0, str(Path(__file__).resolve().parent))

from PySide6.QtWidgets import QApplication
from core.utils import load_custom_fonts
from telemetry.window import TelemetryWindow


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setApplicationName("LMU Telemetry Pro")
    load_custom_fonts()
    win = TelemetryWindow()
    win.show(); win.raise_(); win.activateWindow()
    sys.exit(app.exec())


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
