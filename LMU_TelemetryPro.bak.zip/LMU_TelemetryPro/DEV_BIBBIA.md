# LMU Telemetry Pro — BIBBIA (note di sviluppo per la doc finale)

> File di lavoro: lo aggiorno a ogni blocco. A fine progetto diventa la base
> della documentazione utente + tecnica. Lingua note: IT. UI dell'app: EN.

---

## 1. Cos'è
App autonoma di telemetria e analisi per **Le Mans Ultimate**, scorporata dal
progetto LMU DataOverlay (separazione annunciata pubblicamente, overlay a
v0.8b senza più la scheda telemetria).

Finestra: **LMU Telemetry Pro**. Entry point: `telemetry_pro.py`.

## 2. Avvio e build
- Da sorgente: `python telemetry_pro.py` (richiede PySide6).
- Build Windows: `pyinstaller TelemetryPro.spec` → `dist\LMU_TelemetryPro\`.
- Prima di zippare il build: in `settings\` tenere SOLO `config.default.json`,
  rimuovere `config.json`, `overlay_positions.json`, cartella `logs\`.
- Font: si usano i **font di sistema** (niente cartella `fonts/`). L'unica
  icona (cestino) è un glyph unicode di sistema.

## 3. Struttura progetto (standalone)
```
telemetry_pro.py        entry point
telemetry/              window.py, reader.py, recorder.py, db.py, strategy.py
core/                   shared_memory, paths, brands, utils, config, classes, tyre_cell,
                        lmu_paths.py   (rilevamento install/cartelle setup LMU)
                        svm.py         (parser round-trip dei file setup .svm)
                        motec_ld.py    (writer MoTeC i2 .ld)
                        analysis.py    (motore analisi stint vs REF, deterministico)
pyLMUSharedMemory/      bindings shared memory LMU
settings/               config.default.json, brands.json, tracks.json, trackmap/*.svg
assets/tracklogos/      loghi circuiti (SVG)
brandlogo/              loghi marche auto (SVG)
TelemetryPro.spec  README.md  .gitignore
```
NON incluso: gui/, widgets/, core/icons.py, fonts/, main.py, run_overlay.py.
`widgets.map` è importato in try/except (fallback None): codice morto della
vecchia Live view, non serve.

## 4. Dati utente (runtime)
- Cartella: `%APPDATA%\LMU_DataOverlay` (condivisa con l'overlay PER ORA;
  si può separare in `%APPDATA%\LMU_TelemetryPro` cambiando `core/paths.py`).
- Contiene: `config.json`, `overlay_positions.json`, `logs\*.lmtel`.
- I default di fabbrica restano nell'app: `settings/config.default.json`.
- `config.py.load()` fa deep-merge default+utente (le nuove chiavi compaiono
  senza azzerare la config utente).

## 5. Registrazione
- **Manuale**: pulsante START/STOP in alto a sinistra.
  - verde **START** (fermo), rosso **STOP** (in pista, sta registrando),
    arancione **WAITING** (armato ma auto non in pista).
- Campionamento **50 Hz**.
- Auto-stop quando: niente dati >2s (uscita/fine sessione) o cambia la firma
  sessione (track, session_type).
- File per sessione: `.lmtel` (SQLite) in `logs\`.

## 6. Schema dati (.lmtel, SQLite)
- **session_meta** (1 riga): track, vehicle, car_class, session_type,
  driver, team, fuel_start, air_temp, track_temp, wetness, compound_f/r,
  compounds4 ('S,M,H,W' per FL,FR,RL,RR), fuel_max, ve_max, app_version, ...
- **laps**: lap, lap_time, invalid, s1, s2, s3, ve_used, fuel_used, stint, ...
- **sectors**: lap, sector(0..2), s_time, fuel_used, ve_used, regen_kwh, ...
- **samples** (50 Hz): lap, **t** (tempo dall'inizio giro, s), lapdist (m),
  pos_x/y/z, speed, throttle, brake, steer, g_long, g_lat, gear, rpm, soc,
  regen_kw, boost_state, fuel, ve,
  per-ruota: tyre_t/ts/ti/p _fl/_fr/_rl/_rr, brake_t_*, tyre_w_* (usura).
  - **Aiuti** (da LMU shared mem): tc_active, abs_active (0/1, in intervento),
    brake_bias (frazione posteriore), tc_map, abs_map, tc_slip, tc_cut.
  - **Sospensioni/freni** (per-ruota): ride_h_* (altezza, mm), susp_d_*
    (deflessione, mm), brake_p_* (pressione freno, %).
  (Legacy single-channel: tyre_t/ts/ti/p, brake_t senza suffisso.)
  Nota: i canali aiuti/sospensioni esistono solo per le sessioni registrate
  DOPO la loro introduzione; sulle vecchie sono NULL/0.

## 7. Tab dell'app
L'app è divisa in **3 sezioni principali** (QTabWidget `mainTabs`):
**Overview · Telemetry · Settings**.

### Overview
- SINISTRA = lista telemetrie (tutte le sessioni .lmtel): ogni riga con logo
  auto piccolo, classe·pilota, circuito, data/ora; cestino + icona cartella
  per riga (apre la cartella della sessione). Selezione = clic sulla riga.
- DESTRA = striscia condizioni compatta (logo circuito + sessione/durata +
  Remaining live + Air/Track/DRY-WET) sopra la **board tempi**: tab STINT,
  riga **summary** stint (Duration/Tyre−X%/Fuel/Energy), riga **REF** oro,
  poi i **giri** come card con checkbox (verde=Selected, viola=Compare, oro=REF).
  Best lap rosa, miglior settore fuxia, Theoretical best.

### Telemetry  (sotto-tab, tutte le tracce)
- **Pedals**: throttle/brake + mappa (scrub).
- **Speed / VE / Fuel / Hybrid**: traccia singolo canale vs distanza.
- **Tyres / Brakes / Suspension**: 4 angoli per-ruota con tab layer
  (Tyres: Surface/Press/Wear; Brakes: Temp/Press; Suspension: Ride height/Defl).
- **Gear / Steering / RPM**: tracce dedicate.
- **Aids**: `_TraceTab` con modi **TC active / ABS active / Brake bias /
  TC map / ABS map** (vedi §13 per i dati).
- **G-G**: scatter g_lat vs g_long con cerchi a 1–4 g (Selected/Compare/REF).
- **Delta**: Δt (Compare − Selected) vs distanza, dal canale `t` (esatto).
- **Engineer**: analisi stint vs REF (vedi §14).
- Top-bar: **Export CSV** (giro selezionato) e **Export i2** (stint, vedi §12).

### Settings  (editor assetto .svm, vedi §11)

Selezione/confronto: la board pilota i "motori" nascosti cmb_stint/lap/cmp;
`_sync_board()` ricostruisce ad ogni cambio. Confronto sempre **vs REF**.

## 8. Interazione grafici (_TraceChart)
- **Scrub**: muovi il mouse → cursore + valori; sincronizzato con la mappa.
- **Zoom** rotella, **pan** tasto destro (quando zoomato), **doppio-click**
  reset zoom.
- **Cursori A/B** (NUOVO, blocco 1a): **shift+click** posiziona A (arancione),
  poi B (ciano), 3° click resetta. Readout in alto a dx: ΔX (m) e Δvalore (B−A);
  sul Delta tab il Δ è in secondi (tempo perso/guadagnato tra A e B).
- Auto-best: ogni secondo, se esce un nuovo best nello stint, imposta
  Selected=best e Compare=penultimo best (comparazione manuale ai box resta).

## 9. Comportamenti importanti / fix storici
- Cancellando l'ultima sessione, `_clear_views()` svuota TUTTO (stint, compare,
  grafici, Overview): niente più "dati morti".
- Rimosso il tasto Refresh (le sessioni si aggiornano da sole in registrazione).
- Delta riscritto: prima integrava il tempo dalla velocità (errato, picchi a
  bassa v, deriva); ora usa il canale `t`.

## 10. Glossario campi derivati / pianificati
- **Theoretical best**: somma dei migliori settori validi.
- (Pianificati) canali matematici: sotto/sovrasterzo (steer vs g_lat), coast,
  trail-braking, slip stimato.

## 11. Sezione Settings — editor assetto .svm
Carica/visualizza/modifica/salva i file setup LMU (`.svm`).
- **Formato .svm** (INI): righe header (`VehicleClassSetting=...`, commenti `//`)
  prima della prima sezione; sezioni `[GENERAL] [SUSPENSION] [CONTROLS] ...`;
  chiavi `KeyNameSetting=<intero>//<valore leggibile>`.
- **`core/svm.py`** — parser **round-trip safe**: conserva ogni riga verbatim
  (commenti inclusi); `SVM.parse(text)`, `to_text()`, `sections()`,
  `get(sez,chiave)`, `set_value(idx,valore)` (rigenera solo la riga toccata,
  mantenendo il commento di riferimento), `vehicle_class()`. Regex
  `^([A-Za-z0-9_]+)=(-?\d+)(//.*)?$`. Verificato: parse→to_text == originale.
- **UI** (`_SettingsTab`): bottoni **Load .svm / Save / Save As** (default sulle
  cartelle LMU, §12bis). Sotto-tab **Aero / Suspension / Corners /
  Brakes & Controls / Drivetrain / General**. Ogni voce = nome leggibile +
  **stepper − [valore] +** (chip separati: bottoni grigi con +/− in teal,
  valore in box scuro) + valore leggibile a destra. Modifica → etichetta oro
  "edited → reload in LMU".
- **Pulizia lista** (importante):
  - Voci **non regolabili** nascoste (`_svm_is_fixed`: Non-adjustable / N/A / Fixed).
  - **Flag ridondanti** nascosti (`_SVM_HIDE_KEYS = {TCSetting, ABSSetting}` =
    "Disponibile", doppioni delle mappe vere).
  - **Nomi in-game** via `_SVM_KEY_NAMES` (es. TractionControlMapSetting→
    "Onboard TC", AntilockBrakeSystemMapSetting→"ABS", RearBrakeSetting→
    "Brake Bias", FrontAntiSwaySetting→"Front Anti-Roll Bar", ecc.).
  - Le note manuali nei commenti (`// <-- CAMBIATO ...`) tagliate dal valore
    (`_svm_human_value`) e messe nel **tooltip**.
- **Limite onesto**: si modifica solo l'**intero raw** (indice della regolazione).
  Il valore leggibile è quello del file e non è ricalcolabile (mancano le tabelle
  dell'auto); LMU lo ricalcola al caricamento del setup.

### 12bis. Cartelle LMU (`core/lmu_paths.py`)
Rileva Steam (registro Windows: HKCU `Software\Valve\Steam`, HKLM
`WOW6432Node\Valve\Steam`) → `libraryfolders.vdf` → libreria con **AppID
2399420** → install LMU. `lmu_settings_dir()` = `<install>\UserData\<profilo>\
Settings` (preferisce `player`). `lmu_tracks()` / `lmu_setups(track_dir)` per
liste circuito→setup. Load/Save partono da qui. Su Linux/macOS ritorna None
senza crash (dialog dalla home).

## 12. Export MoTeC i2 (.ld)
- **`core/motec_ld.py`** — writer del formato binario `.ld` (derivato da
  gotzl/ldparser, **GPL**). Solo `struct`, niente numpy/pandas. Canali come
  **float32** (scale=1, shift=0, mul=1, dec=0 → valore memorizzato = reale).
  `write_ld(path, channels, freq, driver, vehicle, venue, comment, when)`.
  Validato in round-trip col parser di riferimento.
- **UI**: bottone **Export i2** → esporta l'**intero stint corrente** (giri
  concatenati con **tempo e distanza continui**), resamplato a 50 Hz. ~40
  canali: Distance, Speed, RPM, Gear, Throttle/Brake %, Steering, G long/lat,
  TC/ABS active, Brake Bias, TC/ABS map, Fuel, VE, temp/press/usura gomme ×4,
  temp/press freni ×4, ride height ×4, deflessione ×4.
- Note: GPL (occhio alla licenza se ridistribuito); canali aiuti/sospensioni
  solo da registrazioni nuove; non ancora testato contro i2 reale.

## 13. Aiuti TC/ABS (dati)
LMU shared mem espone `mTCActive, mABSActive` (in intervento), `mTC, mABS,
mTCSlip, mTCCut` (mappe), `mRearBrakeBias`. Letti in `reader.py` (getattr con
default), salvati nei samples (tc_active/abs_active/brake_bias/tc_map/abs_map/
tc_slip/tc_cut) e mostrati nella tab **Aids** + esportati in i2.

## 14. Engineer — analisi stint vs REF (deterministica, no AI)
**`core/analysis.py`** — `analyze(con, sel_lap, ref_con, ref_lap, step=4.0)`.
- Carica sel e ref (canali in `CHANNELS`), li **campiona sulla distanza** su una
  griglia comune (step 4 m), calcola la **perdita per-segmento**
  `(sel_seg − ref_seg)` dal canale `t`, la liscia e individua le **zone** dove
  si perde (`_find_zones`, soglie `_SEG_THR`/`_MIN_ZONE`).
- **Classifica** ogni zona (`_classify`) per fase — **Braking / Mid-corner /
  Traction** — usando brake, throttle, |steer|, abs_active, tc_active, velocità
  min/ingresso vs REF. Esce causa + consiglio di guida.
- **Consigli assetto** (`_setup_advice`) dai pattern aggregati su tutto il giro:
  - **Understeer** (poca v a metà curva con più sterzo del REF) → ARB ant. più
    morbido / ARB post. più rigido / più ala ant. / meno pressione ant.
  - **Power oversteer** (TC attiva in trazione) → ARB post. più morbido /
    diff coast/preload più alto / più ala post.
  - **Braking stability** (ABS attivo in frenata) → meno pressione freno / bias.
  - **Tyre balance** (front/rear temp Δ>12°) → pressioni/camber.
  - Se il bilanciamento è in linea col REF → "il gap è guida, non assetto".
- **UI** (`_EngineerTab`, in Telemetry): bottone **Analyze stint vs REF** →
  card riepilogo (lap/REF/gap, recuperabile) + **WHERE YOU LOSE** (zone con
  badge fase colorato, metri, −Δs, causa, tip) + **SETUP SUGGESTIONS**.
- Soglie in testa al modulo (`_BRAKE_ON, _THR_ON, _STEER_ON, _LOCK, _SPIN,
  _SEG_THR, _MIN_ZONE`), da tarare sui dati reali.
- **Euristico**: i consigli assetto sono un punto di partenza ragionato dai
  sintomi, non verità assoluta — vanno provati in pista.

---

## ROADMAP "tutto" (a blocchi, testabili uno alla volta)
- [x] +50 Hz
- [x] Theoretical best (Overview + Stint)
- [x] Delta corretto (da canale t)
- [x] Clear views su delete
- [x] Separazione app standalone
- [x] **1a — Cursori A/B** (per grafico)
- [x] **1b — Zoom + A/B SINCRONIZZATI** tra tutte le tab a traccia
- [x] **2 — Reference lap manuale** (Set Ref + vs Ref) su tutte le tab a traccia + Tyres + Delta
      → SUPERATO dai reference automatici (blocco 3); "Set Ref"/"vs Ref" verranno rimossi.
- [x] **3 — Reference AUTOMATICI per classe+pista+meteo** (best record, DRY/WET)
  - [x] **3a** — storage `%APPDATA%\...\refs\ref_<CLASSE>_<Pista>_<DRY|WET>.lmref`;
        auto-update LIVE del best a ogni giro valido migliore (recorder._write_lap →
        db.update_reference_if_better). Meteo a 2 stati (wetness>0.10=WET). Solo giri validi.
        Helper db.py: ref_key/ref_path/ref_best_time/update_reference_if_better/list_references.
  - [x] **3b** — voce **REF** in cima al menu Compare (auto-selezionata se disponibile;
        auto-pick del file per classe+pista+meteo della sessione aperta, anche live).
        REF disabilitata/grigia se non c'è ancora record. Rimossi "Set Ref"/"vs Ref".
        Auto-best non forza più il Compare quando c'è un REF.
  - [x] **3c** — Compare ORO (linea/legenda/cursore) quando è REF; badge **DRY giallo /
        WET azzurro** in Overview (riga Weather a 2 stati) e nella lista sessioni;
        barra in alto ripulita (etichette STINT/LAP/VS, combo uniformi).
- [x] **Overview "board" (nuova selezione)** — il pannello destro dell'Overview è ora
      una **tabella tempi**: tab **STINT** in alto, **riga REF** in cima (logo auto + pilota +
      tempo, oro), poi i **giri** con **checkbox** per scegliere il giro selezionato; il
      confronto è sempre **vs REF** (automatico, best auto-selezionato). La scheda SESSION è
      diventata una **striscia compatta** sopra la board. I dropdown STINT/LAP/VS spariscono
      dalla barra: restano come "motore" nascosto (cmb_stint/lap/cmp), pilotati dalla board
      via _board_stint/_board_select; _sync_board() ricostruisce la board ad ogni cambio.
- [ ] **4 — Multi-lap overlay** (3-4 giri insieme) ← prossimo (le checkbox diventeranno multi)
- [ ] **5 — Canali derivati** (sotto/sovrasterzo, coast, trail-braking, slip)
- [ ] **6 — Distribuzioni/consistenza** + mini-settori
- [ ] **7 — Finestra termica gomme** per compound (derivata dai dati)
- [x] **8 — Export CSV** (giro selezionato)
- [x] **9 — Export MoTeC i2 (.ld)** — intero stint, ~40 canali (§12)
- [x] **10 — Aiuti TC/ABS** — cattura + tab Aids + export (§13)
- [x] **11 — Guscio a 3 sezioni** Overview / Telemetry / Settings (§7)
- [x] **12 — Editor assetto .svm** — load/edit/save round-trip, cartelle LMU,
      lista ripulita + nomi in-game (§11)
- [x] **13 — Engineer** — analisi stint vs REF: zone di perdita + consigli
      guida + consigli assetto, deterministico (§14)
- [ ] **14 — Engineer: applica setup** — un click dai consigli alla voce .svm
- [ ] **15 — Pannello circuiti→setup** a sinistra in Settings (lmu_tracks/lmu_setups)
- [ ] **16 — Lap-beacon** nell'export i2 (split giri in i2)

## Note di processo (per non rompere)
- Consegna SOLO i file cambiati come zip, struttura cartelle preservata.
- Non cambiare APP_VERSION senza richiesta esplicita.
- Modifiche minime e mirate; mai riscrivere codice funzionante.
- Attenzione agli splice grandi: rischio di "mangiare" metodi adiacenti
  (già successo con `_fill_stints` e `_reload_sessions`).
- UI/diagnostica in INGLESE; comunicazione con l'utente in italiano.
