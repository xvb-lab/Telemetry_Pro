"""
core/engineer.py — il "cervello" del Race Engineer.

Logica pura (niente UI): riceve dati strategia/telemetria e decide QUALI
messaggi dire, già localizzati (EN/IT) e con i campi riempiti.

Sorgenti dati:
  - strategy.compute() (carburante/energia, soste, target passo, pit window)
  - core.analysis.analyze() (confronto giro vs best di stint, zone T1..Tn)
  - usura gomma per giro (dal DB)
  - previsione meteo (REST /sessions/weather)

L'overlay/tab chiama questi metodi e mostra i messaggi ritornati.
Ogni messaggio = dict {code, text, level, color, beep}.
"""
import json
from pathlib import Path

_MSGS_FILE = Path(__file__).resolve().parent.parent / "settings" / "engineer_msgs.json"
_LEVELS = {"critical": "#ff3b3b", "warn": "#ffcc33", "info": "#f2f4f7",
           "good": "#f2f4f7", "green": "#46e08a", "best": "#e23bd0"}

# Finestre termiche per categoria (gradi C). Fonte: parametri WEC/ELMS Brembo/Michelin.
#   tyre:  cold = sotto finestra; hot = sopra finestra; over = critico
#   brake: cold = sotto attivazione; hot = sopra finestra esercizio; over = critico
_TYRE_WIN = {
    "hypercar": {"cold": 70, "hot": 115, "over": 125},
    "lmp2":     {"cold": 80, "hot": 95,  "over": 105},
    "lmp3":     {"cold": 75, "hot": 90,  "over": 100},
    "gt3":      {"cold": 70, "hot": 95,  "over": 105},
    "gte":      {"cold": 70, "hot": 90,  "over": 110},
}
_BRAKE_WIN = {
    "hypercar": {"cold": 250, "hot": 850, "over": 1050},
    "lmp2":     {"cold": 250, "hot": 850, "over": 950},
    "lmp3":     {"cold": 100, "hot": 700, "over": 750},
    "gt3":      {"cold": 150, "hot": 750, "over": 800},
    "gte":      {"cold": 150, "hot": 800, "over": 900},
}
# pressione gomma calda target (bar) per categoria. Fonte: parametri WEC/ELMS.
_PRESS_WIN = {
    "hypercar": {"lo": 1.9, "hi": 2.1},
    "lmp2":     {"lo": 1.85, "hi": 2.05},
    "lmp3":     {"lo": 1.8, "hi": 2.0},
    "gt3":      {"lo": 1.95, "hi": 2.15},
    "gte":      {"lo": 1.95, "hi": 2.15},
}
_WHEEL = ("FL", "FR", "RL", "RR")
_WHEEL_IT = ("anteriore sx", "anteriore dx", "posteriore sx", "posteriore dx")


def class_category(car_class):
    """Stringa classe LMU -> categoria termica ('hypercar','lmp2','lmp3','gt3','gte')."""
    s = (car_class or "").upper()
    if "LMP2" in s:
        return "lmp2"
    if "LMP3" in s:
        return "lmp3"
    if "GTE" in s:
        return "gte"
    if "GT3" in s or "LMGT3" in s:
        return "gt3"
    if any(k in s for k in ("HYP", "LMH", "LMDH", "HYPERCAR")):
        return "hypercar"
    return "gt3"          # default: la classe piu' comune


def _load_msgs():
    try:
        d = json.loads(_MSGS_FILE.read_text(encoding="utf-8"))
        return d.get("messages", {}), d.get("_levels", _LEVELS)
    except Exception:
        return {}, _LEVELS


def _turn_name(n):
    return "T%d" % n


def _fmt_s(x):
    try:
        return ("%.2f" % float(x)).rstrip("0").rstrip(".")
    except Exception:
        return str(x)


class Engineer:
    """Decisore. Stateful: evita di ripetere lo stesso messaggio (fire-once)."""

    def __init__(self, lang="it"):
        self.lang = "en" if str(lang).lower().startswith("en") else "it"
        self._msgs, self._levels = _load_msgs()
        self._fired = {}          # fire-once per codice+contesto
        self._best_lap_ms = None  # miglior giro pulito dello stint (ms)
        self._turn_order = []     # distanze d0 dei punti -> numerazione T1..Tn
        self.baseline = None      # profilo appreso (consumo/degrado di riferimento)
        self._cat = "gt3"
        self._tyre_win = _TYRE_WIN["gt3"]
        self._brake_win = _BRAKE_WIN["gt3"]
        self._press_win = _PRESS_WIN["gt3"]
        self._tyre4 = None        # ultime temp carcassa per ruota
        self._press4 = None       # ultime pressioni per ruota
        self._tyre_ema = None     # media mobile temp gomma (carcass)
        self._brake_ema = None    # media mobile temp freni
        self._temp_laps = {}      # persistenza/isteresi per giro
        self._about_to_pit = False
        self._strat_lap = None
        self._pace_mode = None
        self._pace_lap = None
        self._near_t = 0.0
        self._best_track = None    # miglior giro in pista (sessione)
        self._my_best = None       # tuo miglior giro in sessione
        self._mgmt_lap = None      # ultimo giro del feedback gestione (ogni 3)
        self._tyre_lap = None      # ultimo giro del check gomme (ogni 5)

    def set_class(self, car_class):
        cat = class_category(car_class)
        if cat != self._cat:
            self._cat = cat
            self._tyre_win = _TYRE_WIN[cat]
            self._brake_win = _BRAKE_WIN[cat]
            self._press_win = _PRESS_WIN[cat]
            for k in ("tcold", "thot", "tover", "bcold", "bhot", "bover"):
                self._clear_once(k)

    def set_baseline(self, bl):
        self.baseline = bl or None

    # ── lingua ──
    def set_lang(self, lang):
        self.lang = "en" if str(lang).lower().startswith("en") else "it"

    def reset(self):
        self._fired = {}
        self._best_lap_ms = None
        self._turn_order = []
        self._tyre_ema = None
        self._brake_ema = None
        self._temp_laps = {}

    # ── costruzione messaggio localizzato ──
    def msg(self, code, **kw):
        m = self._msgs.get(code)
        if not m:
            return None
        text = m.get(self.lang) or m.get("en") or code
        for k, v in kw.items():
            text = text.replace("{%s}" % k, str(v))
        lvl = m.get("level", "info")
        return {"code": code, "text": text, "level": lvl,
                "color": self._levels.get(lvl, "#1c9fe0"),
                "beep": bool(m.get("beep"))}

    def _once(self, key):
        if self._fired.get(key):
            return False
        self._fired[key] = True
        return True

    def _clear_once(self, key):
        self._fired[key] = False

    # ────────────────────────────────────────────────────────────────────
    #  STRATEGIA / GESTIONE / PASSO  (da strategy.compute output)
    # ────────────────────────────────────────────────────────────────────
    def strategy(self, strat, laps_done=0, in_pits=False, energy_car=False,
                 lap_time=None, best_lap_time=None, session="race", fuel_max=None):
        """Ritorna lista messaggi (fire-once) dallo stato strategia corrente.
        session: 'race' = strategia completa; 'qualy'/'practice' = niente
        risparmio benzina/lift/box (carico basso, si spinge)."""
        out = []
        if not strat:
            return out
        if in_pits:
            self._fired = {}                     # ai box: reset, niente avvisi
            return out
        race = (session == "race")

        # rinfresco periodico: ogni 5 giri ri-annuncia passo/consumo (info stint)
        if laps_done != getattr(self, "_strat_lap", None):
            self._strat_lap = laps_done
            if laps_done and laps_done % 5 == 0:
                for k in ("low", "under", "manage", "canpush"):
                    self._clear_once(k)

        # giri alla fine gara e autonomia col livello attuale
        laps_rem = strat.get("laps_rem")
        pf = strat.get("plan_fuel") or {}
        pe = strat.get("plan_ve") or {}
        plan0 = pe if energy_car else pf
        auto0 = plan0.get("autonomy")
        can_finish = (auto0 is not None and laps_rem is not None and auto0 >= laps_rem - 0.1)
        lo0, hi0 = strat.get("pit_lo"), strat.get("pit_hi")
        in_window = (lo0 is not None and hi0 is not None and lo0 <= laps_done <= hi0)
        # stai per fermarti: in finestra pit e NON puoi finire cosi' -> sosta vera
        self._about_to_pit = bool(in_window and not can_finish)

        # a inizio gara: piano stint dai dati appresi (consumo storico)
        if race and laps_done <= 1:
            st = strat.get("total_stints"); sp = strat.get("stops")
            if st and sp is not None and self._once("plan"):
                out.append(self.msg("plan", stints=st, stops=sp))
            if self.baseline:
                per = self.baseline.get("per_lap")
                if self.baseline.get("samples") and self.baseline.get("provisional"):
                    if self._once("prov"):
                        out.append(self.msg("learn_prov"))
                if per and fuel_max and per > 0:
                    n = int(fuel_max / per)
                    if n > 0 and self._once("planhist"):
                        out.append(self.msg("plan_hist", laps=n))

        if race:
            # CRITICO: non arrivi al traguardo col livello attuale (fine gara)
            if (laps_rem is not None and auto0 is not None and not can_finish
                    and laps_rem <= auto0 + 8):
                short = laps_rem - auto0
                if short > 0.2:
                    if self._once("short"):
                        out.append(self.msg("short_finish", laps=int(round(short))))
                else:
                    self._clear_once("short")
            else:
                self._clear_once("short")
            pf = strat.get("plan_fuel") or {}
            pe = strat.get("plan_ve") or {}
            plan = pe if energy_car else pf
            auto = plan.get("autonomy")          # giri residui col livello attuale

            # FINE GARA: se col livello attuale arrivi al traguardo, niente
            # box/finestra pit (la gara sta per finire).
            if can_finish:
                for k in ("box", "low", "pitwin", "pitin1", "pitin2", "pitin3"):
                    self._clear_once(k)
            else:
                # carburante/energia < 1 giro -> BOX
                if auto is not None and auto < 1.0:
                    if self._once("box"):
                        out.append(self.msg("box_now", lap=laps_done + 1))
                    return [m for m in out if m]
                self._clear_once("box")

                # autonomia bassa (<= 3 giri)
                if auto is not None and auto <= 3.0:
                    code = "energy_laps" if energy_car else "fuel_laps"
                    if self._once("low"):
                        out.append(self.msg(code, laps=int(auto)))
                else:
                    self._clear_once("low")

                # finestra pit aperta + countdown al box
                lo, hi = strat.get("pit_lo"), strat.get("pit_hi")
                if lo is not None and hi is not None and lo <= laps_done <= hi:
                    if self._once("pitwin"):
                        out.append(self.msg("pit_window"))
                else:
                    self._clear_once("pitwin")
                if hi is not None:
                    left = hi - laps_done
                    if 0 < left <= 3:
                        if self._once("pitin%d" % left):
                            out.append(self.msg("pit_in", laps=left))

            # gestione vs spinta
            on = strat.get("on_target")
            delta = strat.get("delta_per_lap")
            if not can_finish and strat.get("save_a_stop"):
                if self._once("save"):
                    out.append(self.msg("save_stop", delta=_fmt_s(abs(delta or 0))))
            elif not can_finish and on == "over":
                code = "manage_energy" if energy_car else "manage_fuel"
                if self._once("manage"):
                    out.append(self.msg(code, delta=_fmt_s(abs(delta or 0))))
                self._clear_once("canpush")
            else:
                self._clear_once("manage"); self._clear_once("save")
                if auto is not None and auto > 4.0 and on == "ok":
                    if self._once("canpush"):
                        out.append(self.msg("can_push"))

            # ── feedback GESTIONE ogni 3 giri (principale) ──
            if (laps_done and laps_done % 3 == 0
                    and laps_done != getattr(self, "_mgmt_lap", None)):
                self._mgmt_lap = laps_done
                ref = getattr(self, "_best_track", None) or best_lap_time
                if strat.get("save_a_stop") or on == "over":
                    out.append(self.msg("stint_lc"))
                elif in_window:
                    out.append(self.msg("stint_push"))
                elif ref:
                    out.append(self.msg("stint_margin", lap_time=_fmt_lap(ref)))

        # ── PASSO GARA dinamico (sempre): target e delta a ogni giro ──
        ref = None
        if getattr(self, "_best_track", None):
            ref = self._best_track          # gap dal miglior giro IN PISTA
        elif self.baseline and self.baseline.get("best_lap"):
            ref = self.baseline["best_lap"]
        if ref is None:
            ref = best_lap_time
        if ref:
            save = bool(strat.get("save_a_stop")) and race
            over = (strat.get("on_target") == "over") and race
            if save:
                mode, target = "save", ref + 0.6
            elif over:
                mode, target = "manage", ref + 0.4
            else:
                mode, target = "push", ref
            # annuncia il target quando cambia modalita' (o a inizio)
            if mode != getattr(self, "_pace_mode", None):
                self._pace_mode = mode
                code = {"push": "target_push", "manage": "target_manage",
                        "save": "target_save"}[mode]
                out.append(self.msg(code, lap_time=_fmt_lap(target)))
            # delta a ogni nuovo giro
            if lap_time and laps_done != getattr(self, "_pace_lap", None):
                self._pace_lap = laps_done
                dd = lap_time - target
                if dd > 0.3:
                    out.append(self.msg("under_pace", delta=_fmt_s(dd)))
                elif dd < -0.3 and mode != "push":
                    out.append(self.msg("pace_margin", delta=_fmt_s(-dd)))
                else:
                    out.append(self.msg("on_pace"))

        return [m for m in out if m]

    # ── feedback giro: tempo + settore peggiore vs best (sempre, ogni giro) ──
    def lap_feedback(self, lap_time, best_lap_time, sectors=None, best_sectors=None,
                     tip=None):
        out = []
        # COLORE: best assoluto di sessione (fuxia) > tuo best (verde) > bianco
        if lap_time:
            overall = getattr(self, "_best_track", None)
            is_overall = (overall is None) or (lap_time <= overall + 1e-6)
            my = getattr(self, "_my_best", None)
            is_pb = (my is None) or (lap_time < my - 1e-6)
            if is_overall:
                code = "lap_best"
            elif is_pb:
                code = "lap_pb"
            else:
                code = "lap_done"
            out.append(self.msg(code, lap_time=_fmt_lap(lap_time)))
            if my is None or lap_time < my:
                self._my_best = lap_time
        # SETTORE: solo il peggiore dove perdi, con consiglio breve
        if sectors and best_sectors and len(sectors) == 3 and len(best_sectors) == 3:
            worst = None
            for i in range(3):
                s, b = sectors[i], best_sectors[i]
                if not (s and b and s > 0 and b > 0):
                    continue
                dl = s - b
                if dl > 0.05 and (worst is None or dl > worst[1]):
                    worst = (i, dl)
            if worst is not None:
                out.append(self.msg("sector_tip", sector="S%d" % (worst[0] + 1),
                                    delta=_fmt_s(worst[1]),
                                    tip=tip or "migliora qui"))
        return [m for m in out if m]

    # ── temperature gomme/freni (gradi C, lista 4 ruote), soglie per categoria ──
    def temps(self, tyre_c=None, brake_c=None):
        out = []
        def _avg(a):
            v = [x for x in (a or []) if x is not None]
            return (sum(v) / len(v)) if v else None
        t = _avg(tyre_c); b = _avg(brake_c)
        tw, bw = self._tyre_win, self._brake_win
        if t is not None:
            if t >= tw["over"]:
                if self._once("tover"):
                    out.append(self.msg("tyres_over"))
            elif t > tw["hot"]:
                if self._once("thot"):
                    out.append(self.msg("tyres_hot"))
            elif t < tw["cold"]:
                if self._once("tcold"):
                    out.append(self.msg("tyres_cold"))
            if tw["cold"] <= t <= tw["hot"]:
                self._clear_once("tcold"); self._clear_once("thot"); self._clear_once("tover")
        if b is not None:
            if b >= bw["over"]:
                if self._once("bover"):
                    out.append(self.msg("brakes_over"))
            elif b > bw["hot"]:
                if self._once("bhot"):
                    out.append(self.msg("brakes_hot"))
            elif b < bw["cold"]:
                if self._once("bcold"):
                    out.append(self.msg("brakes_cold"))
            if bw["cold"] <= b <= bw["hot"]:
                self._clear_once("bcold"); self._clear_once("bhot"); self._clear_once("bover")
        return [m for m in out if m]

    # ── temperature: media nel tempo (EMA) + valutazione a GIRO ──
    def temp_tick(self, tyre_c=None, brake_c=None, tyre_press=None):
        """Aggiorna la media mobile di gomme (carcass) e freni a ogni tick.
        Non emette messaggi: serve solo ad accumulare la temperatura tipica,
        ignorando i picchi istantanei di staccata."""
        def _avg(a):
            v = [x for x in (a or []) if x is not None]
            return (sum(v) / len(v)) if v else None
        if tyre_c and any(x is not None for x in tyre_c):
            self._tyre4 = list(tyre_c)[:4]
        if tyre_press and any(x is not None for x in tyre_press):
            self._press4 = list(tyre_press)[:4]
        t = _avg(tyre_c); b = _avg(brake_c)
        a = 0.05                              # EMA lenta (~ultimi 20 campioni)
        if t is not None:
            self._tyre_ema = t if self._tyre_ema is None else self._tyre_ema * (1 - a) + t * a
        if b is not None:
            self._brake_ema = b if self._brake_ema is None else self._brake_ema * (1 - a) + b * a

    def temps_lap(self, persist=2):
        """A giro chiuso: valuta le MEDIE. Avvisa solo se la media resta fuori
        finestra per >= `persist` giri di fila (persistenza), e non ripete finche'
        non rientra in finestra (isteresi)."""
        out = []
        if getattr(self, "_about_to_pit", False):
            return out                  # stai per fermarti: gomme/freni si cambiano
        out += self._eval_temp_lap("tyre", self._tyre_ema, self._tyre_win,
                                   "tyres_cold", "tyres_hot", "tyres_over", persist)
        out += self._eval_temp_lap("brake", self._brake_ema, self._brake_win,
                                   "brakes_cold", "brakes_hot", "brakes_over", persist)
        return out

    def _tech_lap(self):
        """Dati tecnici a giro: pressioni fuori finestra + squilibrio termico."""
        out = []
        pw = self._press_win
        # pressioni per ruota
        if self._press4:
            for i, p in enumerate(self._press4):
                if p is None:
                    continue
                if p < pw["lo"] and self._once("plo%d" % i):
                    out.append(self.msg("tyre_press_lo", tyre=_WHEEL[i], v=_fmt_s(p)))
                elif p > pw["hi"] and self._once("phi%d" % i):
                    out.append(self.msg("tyre_press_hi", tyre=_WHEEL[i], v=_fmt_s(p)))
                if pw["lo"] <= p <= pw["hi"]:
                    self._clear_once("plo%d" % i); self._clear_once("phi%d" % i)
        # squilibrio termico: una ruota molto piu' calda della media (>12 C)
        if self._tyre4:
            vals = [x for x in self._tyre4 if x is not None]
            if len(vals) == 4:
                mean = sum(vals) / 4
                for i, x in enumerate(self._tyre4):
                    if x is not None and x - mean >= 12:
                        if self._once("imb%d" % i):
                            out.append(self.msg("tyre_imbalance", tyre=_WHEEL[i],
                                                v=int(round(x - mean))))
                    elif x is not None and x - mean < 8:
                        self._clear_once("imb%d" % i)
        return out

    def _eval_temp_lap(self, key, ema, win, cold_c, hot_c, over_c, persist):
        if ema is None:
            return []
        state = None
        if ema >= win["over"]:
            state = "over"
        elif ema > win["hot"]:
            state = "hot"
        elif ema < win["cold"]:
            state = "cold"
        st = self._temp_laps.get(key) or {"state": None, "n": 0, "warned": None}
        if state is not None and state == st["state"]:
            st["n"] += 1
        else:
            st["state"] = state
            st["n"] = 1 if state is not None else 0
        out = []
        if state is None:
            st["warned"] = None               # rientrato in finestra: reset isteresi
        elif st["n"] >= persist and st["warned"] != state:
            st["warned"] = state              # avvisa una volta per stato
            out.append(self.msg({"over": over_c, "hot": hot_c, "cold": cold_c}[state]))
        self._temp_laps[key] = st
        return [m for m in out if m]

    # ── rivali: solo eventi per-tick (gialla, pit del davanti in classe) ──
    def rivals(self, riv, now=None):
        out = []
        if not riv:
            return out
        if riv.get("best_in_session"):
            self._best_track = riv["best_in_session"]
        na = riv.get("name_ahead") or ""
        if riv.get("ahead_pit") and na:
            if self._once("apit_" + na):
                out.append(self.msg("ahead_pit", name=na))
        return [m for m in out if m]

    def relative_lap(self, riv, laps_done):
        """A FINE GIRO, ogni 3 giri: pilota davanti IN CLASSE col gap, senza
        limite di distanza."""
        out = []
        if not riv or not laps_done:
            return out
        if laps_done % 3 != 0 or laps_done == getattr(self, "_rel_lap", None):
            return out
        self._rel_lap = laps_done
        na = riv.get("name_ahead") or ""
        ga = riv.get("gap_ahead")
        if na and ga is not None:
            out.append(self.msg("near_ahead", name=na, gap=_fmt_s(ga)))
        return [m for m in out if m]

    def track_limits_live(self, steps, per_penalty):
        """Avvisa quando sei a un passo dalla penalita' (steps >= per_penalty-1).
        Si riarma solo quando rientri sotto soglia (niente spam)."""
        if not steps or not per_penalty or per_penalty <= 1:
            self._clear_once("tlwarn")
            return []
        out = []
        if steps >= per_penalty - 1:
            if self._once("tlwarn"):
                out.append(self.msg("tlimits_warn"))
        else:
            self._clear_once("tlwarn")
        return [m for m in out if m]

    # ── track limits: giro cancellato (a giro chiuso) ──
    def track_limits_lap(self, invalidated, sector=None):
        if not invalidated:
            return []
        s = (" · S%d" % sector) if sector else ""
        return [self.msg("tlimits_lap", sector=s)]

    def target_pace(self, lap_time_s):
        return self.msg("target_pace", lap_time=_fmt_lap(lap_time_s))

    # ────────────────────────────────────────────────────────────────────
    #  GUIDA  (da core.analysis.analyze(): zone T1..Tn vs best di stint)
    # ────────────────────────────────────────────────────────────────────
    def driving(self, analysis, max_msgs=3, min_lost=0.05):
        """Trasforma le zone di analyze() in messaggi T1..Tn secchi.
        Numerazione T per ordine di pista (distanza), priorità per tempo perso.
        """
        if not analysis or not analysis.get("zones"):
            return []
        zones = analysis["zones"]
        # numerazione T1..Tn per distanza crescente
        order = sorted(range(len(zones)), key=lambda i: zones[i].get("d0", 0))
        tnum = {idx: pos + 1 for pos, idx in enumerate(order)}
        ranked = sorted(range(len(zones)), key=lambda i: -zones[i].get("lost", 0))
        out = []
        self._last_tip = None
        # SOLO la curva peggiore dove perdi molto
        worst_i = next((i for i in ranked if zones[i].get("lost", 0) >= min_lost), None)
        if worst_i is not None:
            z = zones[worst_i]
            self._last_tip = self._zone_tip(z)        # consiglio per il settore
            out.append(self.msg("turn_slow", turn=_turn_name(tnum[worst_i])))
        return [m for m in out if m]

    def _zone_tip(self, z):
        """Consiglio breve dalla fase di perdita della curva."""
        phase = z.get("phase")
        cause = (z.get("cause") or "").lower()
        if phase == "Braking":
            brk_m = z.get("brk_m")
            if "lock" in cause or (brk_m is not None and brk_m >= 8):
                return "Frena prima"
            if brk_m is not None and brk_m <= -8:
                return "Frena dopo"
            return "Porta velocità"
        if phase == "Traction":
            return "Gas dolce" if "spin" in cause else "Trazione in uscita"
        return "Più velocità in curva"

    # ────────────────────────────────────────────────────────────────────
    #  GOMME  (usura per giro dal DB)
    # ────────────────────────────────────────────────────────────────────
    def tyres(self, wear_front_per_lap, wear_rear_per_lap, best_front, best_rear,
              laps_left_stint):
        """Confronta usura/giro vs il miglior giro dello stint.
        wear_* = % usura consumata nel giro; best_* = riferimento (best stint).
        """
        out = []
        if getattr(self, "_about_to_pit", False):
            return out                  # stai per fermarti: inutile parlare di usura
        thr = 0.30        # +0.30%/giro sopra il best = degrado alto
        # se non c'e' un best di stint, usa il degrado appreso come riferimento
        if best_front is None and self.baseline:
            best_front = self.baseline.get("deg_front")
        if best_rear is None and self.baseline:
            best_rear = self.baseline.get("deg_rear")
        if best_rear and wear_rear_per_lap is not None and wear_rear_per_lap - best_rear >= thr:
            if self._once("degR"):
                out.append(self.msg("deg_rear", pct=_fmt_s(wear_rear_per_lap - best_rear)))
        else:
            self._clear_once("degR")
        if best_front and wear_front_per_lap is not None and wear_front_per_lap - best_front >= thr:
            if self._once("degF"):
                out.append(self.msg("deg_front", pct=_fmt_s(wear_front_per_lap - best_front)))
        else:
            self._clear_once("degF")
        return [m for m in out if m]

    def damage(self, dmg):
        """Flat-spot/gomma a terra, ruota staccata, danno carrozzeria (evento)."""
        out = []
        if not dmg:
            return out
        flat = dmg.get("flat") or []
        det = dmg.get("detached") or []
        for i in range(min(4, len(flat))):
            if flat[i]:
                if self._once("flat%d" % i):
                    out.append(self.msg("tyre_flat", tyre=_WHEEL_IT[i]))
            else:
                self._clear_once("flat%d" % i)
        for i in range(min(4, len(det))):
            if det[i]:
                if self._once("det%d" % i):
                    out.append(self.msg("wheel_off", tyre=_WHEEL_IT[i]))
        if int(dmg.get("dent") or 0) >= 2:
            if self._once("dent"):
                out.append(self.msg("damage_body"))
        return [m for m in out if m]

    def tyre_check(self, wear4_per_lap, laps_done, cold=False):
        """Check gomme ogni 5 giri: stato generale (ok/normale/alto) + la gomma
        peggiore se critica. wear4_per_lap = % usura nel giro per ruota."""
        out = []
        if not laps_done or laps_done % 5 != 0 or laps_done == getattr(self, "_tyre_lap", None):
            return out
        self._tyre_lap = laps_done
        if cold:
            out.append(self.msg("tyres_coldchk"))
        vals = [(i, w) for i, w in enumerate(wear4_per_lap or []) if w is not None]
        if not vals:
            return [m for m in out if m]
        worst_i, worst = max(vals, key=lambda x: x[1])
        avg = sum(w for _, w in vals) / len(vals)
        # soglie su % usura/giro (carcassa): regolabili in pista
        if worst >= 0.9:
            out.append(self.msg("deg_corner", tyre=_WHEEL_IT[worst_i]))
        elif avg >= 0.6:
            out.append(self.msg("deg_high"))
        elif avg >= 0.30:
            out.append(self.msg("deg_normal"))
        else:
            out.append(self.msg("tyre_ok"))
        return [m for m in out if m]

    def tyre_plan(self, wear_per_lap, current_wear_pct, laps_left_stint, next_stint_laps):
        """A fine stint: gomme ok fino in fondo / doppio stint / cambia."""
        if wear_per_lap is None or wear_per_lap <= 0:
            return []
        end_wear = current_wear_pct - wear_per_lap * max(0, laps_left_stint)
        if end_wear > 25 and next_stint_laps:
            need = wear_per_lap * next_stint_laps
            if end_wear - need > 15:
                return [self.msg("double_stint")]
        if end_wear < 12:
            return [self.msg("new_tyres")]
        return [self.msg("tyres_to_end")]

    # ────────────────────────────────────────────────────────────────────
    #  METEO  (previsione REST: lista slot con rain 0..1 e minuti)
    # ────────────────────────────────────────────────────────────────────
    def weather(self, forecast, wet_now=False):
        """forecast: lista di dict {minutes, rain} ordinata nel tempo.
        rain ~ probabilità/intensità 0..1.
        """
        out = []
        if wet_now:
            if self._once("rainnow"):
                out.append(self.msg("rain_now"))
            return [m for m in out if m]
        self._clear_once("rainnow")
        if not forecast:
            return out
        for slot in forecast:
            if (slot.get("rain") or 0) >= 0.5 and (slot.get("minutes") or 999) <= 15:
                if self._once("rainin"):
                    out.append(self.msg("rain_in", minutes=int(slot["minutes"])))
                break
        return [m for m in out if m]


def _fmt_lap(s):
    try:
        s = float(s)
        m = int(s // 60)
        return "%d:%06.3f" % (m, s - m * 60)
    except Exception:
        return str(s)


def session_kind(m_session):
    """mSession -> 'practice' | 'qualy' | 'race'.
    rF2/LMU: 0 test, 1-4 practice, 5-8 qualify, 9 warmup, 10-13 race."""
    try:
        s = int(m_session)
    except Exception:
        return "race"
    if 5 <= s <= 8:
        return "qualy"
    if s >= 10:
        return "race"
    return "practice"


# ── self-test (python core/engineer.py) ──
if __name__ == "__main__":
    for lang in ("it", "en"):
        print("\n===== LANG", lang, "=====")
        e = Engineer(lang)
        strat = {"plan_fuel": {"autonomy": 2.4}, "plan_ve": {"autonomy": 9},
                 "pit_lo": 16, "pit_hi": 19, "on_target": "over",
                 "delta_per_lap": 0.18, "save_a_stop": False}
        for m in e.strategy(strat, laps_done=17, lap_time=82.4, best_lap_time=81.6):
            print(" STRAT:", m["text"], "[%s]" % m["level"], "beep" if m["beep"] else "")
        an = {"zones": [
            {"d0": 1200, "lost": 0.22, "phase": "Braking", "cause": "Over-slowing", "sel_min": 112, "ref_min": 118},
            {"d0": 300,  "lost": 0.15, "phase": "Traction", "cause": "Wheelspin on exit", "sel_min": 90, "ref_min": 92},
            {"d0": 2400, "lost": 0.09, "phase": "Mid-corner", "cause": "Low mid-corner speed", "sel_min": 140, "ref_min": 146},
        ]}
        for m in e.driving(an):
            print(" DRIVE:", m["text"])
        for m in e.tyres(0.9, 1.3, 0.6, 0.7, 8):
            print(" TYRES:", m["text"])
        for m in e.weather([{"minutes": 8, "rain": 0.7}]):
            print(" WX:", m["text"])
        print(" PACE:", e.target_pace(81.6)["text"])
