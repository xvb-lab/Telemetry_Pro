"""Sessione di gara condivisa (modalita' squadra).

Chi guida esporta, a ogni giro chiuso, uno SNAPSHOT di quel giro (riga lap +
i suoi sectors + i suoi samples + meta sessione) come file JSON nella cartella
di gara dentro la cartella squadra. File piccolo, chiuso, completo: niente
SQLite condiviso (che si corromperebbe con la sincronizzazione).

Chi NON guida importa gli snapshot nuovi in un .lmtel ricostruito in locale,
che la tab Telemetry apre come una sessione normale (giri cliccabili, analisi
con la telemetria). Cosi' tutta la UI esistente viene riusata.
"""
import json
import sqlite3
import time
from pathlib import Path

from telemetry.db import _SCHEMA

# colonne (in ordine) delle tabelle, lette dallo schema una volta sola
_LAP_COLS = None
_SEC_COLS = None
_SAMP_COLS = None
_META_COLS = None


def _cols(con, table):
    return [r[1] for r in con.execute("PRAGMA table_info(%s)" % table).fetchall()]


def _load_cols(con):
    global _LAP_COLS, _SEC_COLS, _SAMP_COLS, _META_COLS
    if _LAP_COLS is None:
        _LAP_COLS = _cols(con, "laps")
        _SEC_COLS = _cols(con, "sectors")
        _SAMP_COLS = _cols(con, "samples")
        _META_COLS = _cols(con, "session_meta")


def _slug(s):
    return "".join(c if (c.isalnum() or c in "-_") else "_"
                   for c in str(s or "").strip()) or "team"


def race_dir(base, team, started_at=None):
    """Cartella della gara dentro la cartella squadra: race_<team>_<dataora>.
    started_at lega tutti i piloti alla STESSA gara (stesso nome cartella)."""
    stamp = started_at or time.strftime("%Y-%m-%d_%H%M")
    d = Path(base) / ("race_%s_%s" % (_slug(team), _slug(stamp)))
    d.mkdir(parents=True, exist_ok=True)
    return d


# ── identita' gara condivisa (marker nella cartella squadra) ──────────────
def _marker(base):
    return Path(base) / "current_race.json"


def current_race(base, max_age_h=3.0):
    """Nome cartella della gara in corso, se il marker e' fresco. Cosi' i tre
    piloti puntano alla STESSA gara. Vecchio/assente -> None (gara finita)."""
    try:
        d = json.loads(_marker(base).read_text(encoding="utf-8"))
        ts = d.get("ts")
        if ts is not None and (time.time() - ts) > max_age_h * 3600:
            return None
        name = d.get("race")
        rp = Path(base) / name if name else None
        return rp if (rp and rp.exists()) else None
    except Exception:
        return None


def touch_race(base, race_path):
    """Tiene fresco il marker (lo fa chi guida, a ogni giro)."""
    try:
        _marker(base).write_text(json.dumps(
            {"race": Path(race_path).name, "ts": time.time()}), encoding="utf-8")
    except Exception:
        pass


def join_or_start(base, team, driving):
    """Ritorna la cartella della gara da usare.
    - se c'e' una gara in corso (marker fresco): la usa (continuita' tra piloti)
    - altrimenti, SOLO chi guida ne avvia una nuova; chi guarda -> None."""
    cur = current_race(base)
    if cur is not None:
        return cur
    if not driving:
        return None
    rp = race_dir(base, team)
    touch_race(base, rp)
    return rp


# ── EXPORT (lato pilota in pista) ─────────────────────────────────────────
def export_lap(con, lap, out_dir, driver="", stint=1):
    """Esporta lo snapshot di un giro chiuso. Ritorna il path o None.
    con = connessione al .lmtel locale (sessione in corso)."""
    try:
        con.row_factory = sqlite3.Row
        _load_cols(con)
        lap_row = con.execute("SELECT * FROM laps WHERE lap=?", (lap,)).fetchone()
        if lap_row is None:
            return None
        secs = con.execute("SELECT * FROM sectors WHERE lap=? ORDER BY sector", (lap,)).fetchall()
        samps = con.execute("SELECT * FROM samples WHERE lap=? ORDER BY t", (lap,)).fetchall()
        meta = con.execute("SELECT * FROM session_meta WHERE id=1").fetchone()
        snap = {
            "v": 1,
            "driver": driver,
            "stint": int(stint or lap_row["stint"] or 1),
            "lap": int(lap),
            "ts": time.time(),
            "meta": (dict(meta) if meta else {}),
            "lap_row": dict(lap_row),
            "sectors": [dict(r) for r in secs],
            "samples": [dict(r) for r in samps],
        }
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        name = "lap_%03d_%05d.json" % (snap["stint"], lap)
        p = out_dir / name
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(snap, ensure_ascii=False), encoding="utf-8")
        tmp.replace(p)
        return str(p)
    except Exception:
        return None


# ── IMPORT (lato compagno che guarda) ─────────────────────────────────────
def _ensure_db(db_path):
    con = sqlite3.connect(str(db_path))
    con.executescript(_SCHEMA)
    con.row_factory = sqlite3.Row
    return con


def _insert_row(con, table, row, cols):
    keys = [k for k in cols if k in row]
    if not keys:
        return
    ph = ",".join("?" for _ in keys)
    con.execute("INSERT OR REPLACE INTO %s (%s) VALUES (%s)"
                % (table, ",".join(keys), ph), [row.get(k) for k in keys])


def import_new(snap_dir, db_path, seen=None):
    """Importa gli snapshot non ancora visti nel .lmtel ricostruito in db_path.
    seen = set di nomi file gia' importati (mutato in-place). Ritorna il numero
    di nuovi giri importati."""
    snap_dir = Path(snap_dir)
    if not snap_dir.exists():
        return 0
    if seen is None:
        seen = set()
    files = sorted(p for p in snap_dir.glob("lap_*.json") if p.name not in seen)
    if not files:
        return 0
    con = _ensure_db(db_path)
    _load_cols(con)
    added = 0
    try:
        for f in files:
            try:
                snap = json.loads(f.read_text(encoding="utf-8"))
            except Exception:
                continue                      # file ancora a meta' sync: riprova dopo
            meta = snap.get("meta") or {}
            if meta:
                meta = dict(meta); meta["id"] = 1
                _insert_row(con, "session_meta", meta, _META_COLS)
            lr = snap.get("lap_row") or {}
            if lr:
                _insert_row(con, "laps", lr, _LAP_COLS)
            con.execute("DELETE FROM sectors WHERE lap=?", (snap.get("lap"),))
            for s in snap.get("sectors") or []:
                _insert_row(con, "sectors", s, _SEC_COLS)
            con.execute("DELETE FROM samples WHERE lap=?", (snap.get("lap"),))
            for s in snap.get("samples") or []:
                _insert_row(con, "samples", s, _SAMP_COLS)
            seen.add(f.name)
            added += 1
        con.commit()
    finally:
        con.close()
    return added
