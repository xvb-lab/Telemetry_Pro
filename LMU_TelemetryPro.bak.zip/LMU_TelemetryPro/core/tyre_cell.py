"""
core/tyre_cell.py — Cella gomme: cerchio radiale con sigla mescola se le 4 ruote
sono uguali, oppure 4 dots 2x2 colorati se c'è mix (come LMU/TinyPedal).

Colori mescola: S=bianco, M=giallo, H=rosso, W=azzurro.
"""
from PySide6.QtWidgets import QWidget, QLabel, QGridLayout, QVBoxLayout
from PySide6.QtCore import Qt, QRectF, QPointF
from PySide6.QtGui import QPainter, QPen, QColor, QFont, QRadialGradient, QBrush

TYRE_COLORS = {
    "S": "#ffffff",   # soft  - bianco
    "M": "#ffe24d",   # medium - giallo
    "H": "#ff3b30",   # hard  - rosso
    "W": "#4aa3ff",   # wet   - azzurro
}


class TyreCircle(QLabel):
    """Cerchio radiale: bordo spesso colorato per mescola + lettera al centro."""
    def __init__(self, diam):
        super().__init__()
        self._diam = diam
        self._sigla = ""
        self._col = QColor("#555c66")
        self._new = True          # False = gomma usata a inizio stint -> bordo tratteggiato
        self.setFixedSize(diam, diam)

    def set_sigla(self, sigla):
        self._sigla = sigla or ""
        self._col = QColor(TYRE_COLORS.get(sigla, "#555c66"))
        self.update()

    def set_new(self, is_new):
        self._new = bool(is_new)
        self.update()

    def paintEvent(self, ev):
        if not self._sigla:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        d = self._diam
        m = max(1.0, d * 0.06)
        rect = QRectF(m, m, d - 2 * m, d - 2 * m)
        cx, cy = d / 2.0, d / 2.0
        r = (d - 2 * m) / 2.0
        # sfondo trasparente (nessun riempimento)
        # bordo spesso colorato
        pen = QPen(self._col, max(1.0, d * 0.08))
        if not self._new:
            pen.setStyle(Qt.CustomDashLine)
            pen.setDashPattern([2.4, 2.0])
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(rect)
        # lettera al centro
        f = QFont()
        f.setBold(True)
        f.setPixelSize(int(d * 0.5))
        p.setFont(f)
        p.setPen(QPen(self._col))
        p.drawText(self.rect(), Qt.AlignCenter, self._sigla)
        p.end()


class TyreCell(QWidget):
    """Mostra la mescola: cerchio radiale unico o 4 dots se mix."""

    def __init__(self, size=24, scale=1.0):
        super().__init__()
        self.setObjectName("tyreCell")
        self._w = round(size * scale)
        self._dot = max(4, round(7 * scale))
        self._diam = max(16, round(24 * scale))
        self.setFixedWidth(self._w)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        # cerchio radiale (sigla)
        self.circle = TyreCircle(self._diam)
        lay.addWidget(self.circle, 0, Qt.AlignCenter)

        # griglia 2x2 dots
        self._dots_box = QWidget()
        g = QGridLayout(self._dots_box)
        g.setContentsMargins(0, 0, 0, 0)
        g.setHorizontalSpacing(max(1, round(2 * scale)))
        g.setVerticalSpacing(max(1, round(2 * scale)))
        self._dots = []
        for r, c in [(0, 0), (0, 1), (1, 0), (1, 1)]:
            d = QLabel()
            d.setFixedSize(self._dot, self._dot)
            g.addWidget(d, r, c, Qt.AlignCenter)
            self._dots.append(d)
        lay.addWidget(self._dots_box, 0, Qt.AlignCenter)
        self._dots_box.hide()

    def set_new(self, is_new):
        self.circle.set_new(is_new)

    def _dot_css(self, sigla, is_new=True):
        col = TYRE_COLORS.get(sigla, "#555c66")
        r = self._dot // 2
        if is_new:
            return f"background:{col}; border-radius:{r}px;"
        # gomma usata -> dot vuoto (outline)
        return (f"background:transparent; border:1.5px solid {col}; "
                f"border-radius:{r}px;")

    def set_tyre(self, single, four, new4=None, single_new=True):
        """single: sigla principale (fallback). four: lista 4 ruote o None.
        new4: lista 4 bool (True=gomma nuova >=98%, False=usata->outline).
        single_new: per il cerchio unico (uniforme): pieno se nuova, tratteggiato
        se usata. Se new4 è None -> comportamento classico (tutte piene)."""
        valid4 = isinstance(four, (list, tuple)) and len(four) == 4 and all(four)
        mix = valid4 and len(set(four)) > 1
        if not (isinstance(new4, (list, tuple)) and len(new4) == 4):
            new4 = [True, True, True, True]
        if mix:
            self.circle.hide()
            for i, d in enumerate(self._dots):
                d.setStyleSheet(self._dot_css(four[i], bool(new4[i])))
            self._dots_box.show()
        else:
            self._dots_box.hide()
            sigla = (four[0] if valid4 else single) or ""
            self.circle.set_sigla(sigla)
            self.circle.set_new(bool(single_new))
            self.circle.show()
