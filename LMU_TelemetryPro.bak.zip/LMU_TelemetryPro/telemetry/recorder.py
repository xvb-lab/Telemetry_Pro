"""
telemetry/recorder.py — Campionatore live + registrazione su file evento.

Thread dedicato (~20 Hz): legge il reader, alimenta la strategia live,
registra tracce (per la mappa/guida) e aggregati per settore/giro su un
file .lmtel SQLite (uno per evento). Mai I/O sul thread grafico: qui si
accumula e si fa flush a lotti ogni ~1.5 s.

Espone latest() per il widget piccolo strategia (strategia + stint).
"""
import threading
import time
import traceback

from .reader import TelemetryReader
from . import db as _db
from . import strategy as _strat


def _diag(msg):
    """Scrive una riga di diagnostica in logs/recorder.log (per capire perché
    non registra). Non lancia mai."""
    try:
        _db.LOGS_DIR.mkdir(parents=True, exist_ok=True)
        with open(_db.LOGS_DIR / "recorder.log", "a", encoding="utf-8") as f:
            f.write(time.strftime("%H:%M:%S ") + msg + "\n")
    except Exception:
        pass


class TelemetryRecorder:
    def __init__(self, sample_hz=50, margin_laps=2.0, window=3, record=True):
        self._reader = TelemetryReader()
        from core.shared_memory import SharedMemory
        self._mem = SharedMemory.instance()
        self._tracker = _strat.StintTracker(window=window)
        self._margin = margin_laps
        self._record = record
        self._dt = 1.0 / max(5, sample_hz)
        self._dt_game = 1.0 / 10        # gioco aperto, non in registrazione
        self._dt_idle = 0.25           # gioco chiuso / fuori sessione
        self._has_data = False

        self._lock = threading.Lock()
        self._latest = {"strat": {}, "stint": {}, "raw": {}}

        self._db = None
        self._evt_track = None
        self._evt_session = None
        self._evt_car = None
        self._was_active = False
        self._file_stint = 1       # stint corrente nel file (1 = primo)
        self._stint_lap_count = 0  # giri validi/registrati nello stint corrente (per il banner)
        self._stint_started = False
        self._garage_seen = False
        self._last_num_pit = None  # rileva il pit (num_pit che sale) = fine stint

        # stato giro/settore
        self._prev_sector = None
        self._prev_laps = None
        self._cur_lap_id = None
        self._lap_start_fuel = None
        self._lap_start_ve = None
        self._sec_start_fuel = None
        self._sec_start_ve = None
        self._sec_start_wear = [None] * 4
        self._sec_t_sum = [0.0] * 4
        self._sec_ts_sum = [0.0] * 4
        self._sec_ti_sum = [0.0] * 4
        self._sec_p_sum = [0.0] * 4
        self._sec_b_sum = [0.0] * 4
        self._sec_regen_sum = 0.0
        self._sec_spd_sum = 0.0
        self._sec_spd_max = 0.0
        self._sec_n = 0
        # energia elettrica (integrali kWh, firmati per recupero/deploy)
        self._prev_et = None
        self._prev_soc = None
        self._sec_regen_pos = 0.0    # recuperata (regen_kw>0) nel settore
        self._sec_boost = 0.0        # spesa/deploy (regen_kw<0) nel settore
        self._sec_soc_start = None
        self._lap_regen_pos = 0.0
        self._lap_boost = 0.0
        self._lap_soc_start = None
        self._last_flush = 0.0

        self._running = False
        self._armed = False        # registrazione MANUALE: parte solo con arm()
        self._ever_active = False   # True dopo la prima volta in pista (per il no-data)
        self._wait_green = False    # in gara: armato ma in attesa del verde
        self._writing = False      # True solo quando registra davvero (in pista)
        self._arm_sig = None       # (track, session_type) di quando si è armato
        self._nodata_t0 = None     # da quando manca il dato (uscita sessione)
        self._offtrack_t0 = None   # da quando sei uscito dalla pista (menu/fine)
        self.start()

    # ── controllo manuale (AVVIA / STOP) ───────────────────────────────
    def arm(self):
        """AVVIA: abilita la registrazione (nuovo file alla prima attività)."""
        self._reset_session_state()
        self._arm_sig = None
        self._nodata_t0 = None
        self._armed = True
        _diag("START (manual recording)")

    def disarm(self):
        """STOP manuale: ferma e chiude il file (liberandolo)."""
        self._auto_disarm("STOP (manual)")

    def is_armed(self):
        return self._armed

    def is_recording(self):
        """True solo se armato E sta scrivendo (auto in pista)."""
        return self._armed and self._writing

    def current_file(self):
        """Path del file .lmtel attualmente in scrittura (None se nessuno)."""
        db = self._db
        try:
            return str(db.path) if db is not None else None
        except Exception:
            return None

    def banner(self):
        """Stato per il banner UI: (kind, testo inglese).
        kind in: idle | wait | rec."""
        if not self._armed:
            return ("idle", "Press START to begin telemetry analysis")
        if self._writing:
            return ("rec", "Recording \u2014 " + (self._evt_track or "track"))
        st = getattr(self, "_status", "") or ""
        if getattr(self, "_wait_green", False):
            return ("wait", "Armed \u00b7 waiting for green light\u2026")
        if st.startswith("garage"):
            nxt = self._file_stint + (1 if self._stint_lap_count >= 1 else 0)
            return ("wait", "Garage \u00b7 waiting for stint %d" % nxt)
        if st.startswith("no_data"):
            return ("wait", "Waiting for the game\u2026")
        return ("wait", "Waiting for session\u2026")

    def _auto_disarm(self, reason):
        self._armed = False
        self._writing = False
        self._arm_sig = None
        self._nodata_t0 = None
        self._offtrack_t0 = None
        if self._db is not None:
            try:
                self._db.close()
            except Exception:
                pass
            self._db = None
        self._reset_session_state()
        _diag("stop: " + reason)

    def _reset_session_state(self):
        self._evt_track = None
        self._evt_session = None
        self._evt_car = None
        self._was_active = False
        self._ever_active = False
        self._file_stint = 1
        self._stint_lap_count = 0
        self._stint_started = False
        self._garage_seen = False
        self._last_num_pit = None
        self._prev_sector = None

    # ── ciclo ──────────────────────────────────────────────────────────
    def start(self):
        if self._running:
            return
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()
        _diag("recorder avviato (record=%s)" % self._record)

    def stop(self):
        self._running = False
        if self._db:
            try:
                self._db.close()
            except Exception:
                pass
            self._db = None

    def _loop(self):
        self._last_err = None
        while self._running:
            t0 = time.monotonic()
            try:
                self._tick()
            except Exception:
                tb = traceback.format_exc()
                if tb != self._last_err:      # evita spam: logga solo errori nuovi
                    self._last_err = tb
                    _diag("ERRORE _tick:\n" + tb)
            # frequenza adattiva: piena solo durante la registrazione in pista;
            # altrimenti rallenta per non rubare CPU/GIL alla UI (app fluida)
            if getattr(self, "_writing", False):
                target = self._dt
            elif self._has_data:
                target = self._dt_game
            else:
                target = self._dt_idle
            dt = target - (time.monotonic() - t0)
            if dt > 0:
                time.sleep(dt)

    # ── un campione ────────────────────────────────────────────────────
    def _st(self, s):
        if getattr(self, "_status", None) != s:
            self._status = s
            _diag("stato: " + s)

    def _tick(self):
        d = self._reader.read()
        self._has_data = bool(d)
        if not d:
            # nessun dato = gioco fuori sessione. Disarma SOLO se avevi già
            # iniziato a girare (sessione finita). Se sei armato in attesa del
            # via (prep/allineamento), resta armato: niente disarm.
            if self._armed and self._ever_active:
                now = time.monotonic()
                if self._nodata_t0 is None:
                    self._nodata_t0 = now
                elif now - self._nodata_t0 > 2.0:
                    self._auto_disarm("session ended / left the session")
            else:
                self._nodata_t0 = None
            self._st("no_data (gioco/shared memory non leggibile)")
            return
        self._nodata_t0 = None

        # auto-chiusura: dato presente ma sei USCITO dalla pista (menu/garage).
        # NON usiamo game_phase==8: il flag finale la mette a 8 mentre sei ancora
        # sull'ultimo giro, e chiuderebbe un giro prima del traguardo.
        # mInRealtime resta True finche' sei in pista (anche in pausa e all'ultimo
        # giro), quindi disarma solo quando torni davvero ai menu.
        if self._armed and self._ever_active:
            now = time.monotonic()
            try:
                rt = self._mem.in_realtime()
            except Exception:
                rt = None
            if rt is False:
                if self._offtrack_t0 is None:
                    self._offtrack_t0 = now
                elif now - self._offtrack_t0 > 5.0:
                    self._auto_disarm("session ended / back to menu")
                    return
            else:
                self._offtrack_t0 = None

        # strategia live (sempre, anche senza registrazione)
        self._tracker.update(d)
        measured = self._tracker.measured(d)
        strat = _strat.compute(measured, self._margin)
        stint = self._tracker.stint_info(d)
        # stato pista (per overlay automatico: in pista mostra, menu/pausa nascondi)
        try:
            _ot = self._mem.is_on_track()
        except Exception:
            _ot = True
        # temperature medie per ruota (gomma = media 3 zone superficie; freno)
        def _avg4(arr):
            out = []
            for x in (arr or []):
                if isinstance(x, (list, tuple)):
                    v = [z for z in x if z is not None]
                    out.append(sum(v) / len(v) if v else None)
                else:
                    out.append(x)
            return (out + [None, None, None, None])[:4]
        _tyre_c = _avg4(d.get("tyre_carcass"))
        _brake_c = _avg4(d.get("brake_temp"))
        _press = _avg4(d.get("tyre_press"))
        # track limits del pilota (per avviso preventivo)
        _tl_steps = _tl_pen = None
        try:
            _tl = self._mem.player_track_limits()
            if _tl:
                _tl_steps = _tl.get("steps"); _tl_pen = _tl.get("per_penalty")
        except Exception:
            pass
        # rivali (nomi/gap/pit/gialla), aggiornati al massimo ogni ~1s
        _riv = None
        try:
            now = time.monotonic()
            if now - getattr(self, "_riv_ts", 0.0) >= 1.0:
                self._riv_cache = self._mem.rivals()
                self._riv_ts = now
            _riv = getattr(self, "_riv_cache", None)
        except Exception:
            _riv = None
        # danni/flat gomme (cache ~1s)
        _dmg = None
        try:
            now2 = time.monotonic()
            if now2 - getattr(self, "_dmg_ts", 0.0) >= 1.0:
                self._dmg_cache = self._mem.tyre_damage()
                self._dmg_ts = now2
            _dmg = getattr(self, "_dmg_cache", None)
        except Exception:
            _dmg = None
        with self._lock:
            self._latest = {
                "strat": strat,
                "stint": stint,
                "raw": {**{k: d.get(k) for k in (
                    "fuel", "fuel_max", "ve_pct", "soc", "regen_kw", "boost_state",
                    "lift_coast", "in_pits", "num_pit", "laps_completed",
                    "car_class", "track", "wetness", "garage", "session_type")},
                    "on_track": _ot, "ts": time.monotonic(),
                    "tyre_temp": _tyre_c, "brake_temp": _brake_c,
                    "tyre_press": _press,
                    "tl_steps": _tl_steps, "tl_pen": _tl_pen,
                    "rivals": _riv, "damage": _dmg},
                "measured": measured,
            }

        if not self._armed:
            self._st("stopped (press START)")
            return

        # cambio sessione (tipo o pista) mentre si registra = fine sessione -> stop
        sig = (d.get("track"), d.get("session_type"))
        if self._arm_sig is None:
            self._arm_sig = sig
        elif d.get("track") and sig != self._arm_sig:
            if self._ever_active:
                # cambio sessione DOPO aver girato = sessione finita -> stop
                self._auto_disarm("session changed")
                return
            # ancora in attesa del via (la prep si chiude e parte la gara):
            # NON disarmare, riallinea l'armamento alla nuova sessione.
            self._arm_sig = sig
            self._reset_session_state()

        # registra SOLO quando giri davvero: in pista e non fermo in garage.
        # (la strategia live sopra gira comunque sempre)
        on_track = False
        try:
            on_track = self._mem.is_on_track()
        except Exception:
            on_track = True
        active = on_track and not bool(d.get("garage"))
        # in GARA (session_type >= 10): aspetta il VERDE. Durante prep/gridwalk/
        # formation/countdown (fasi 0-4) resta armato in WAIT e parte da solo al
        # via (mGamePhase 5 verde, 6 full-course yellow). Pratica/Qualify invariati.
        try:
            _styp = int(d.get("session_type") or 0)
        except Exception:
            _styp = 0
        self._wait_green = False
        if _styp >= 10:
            ph = None
            try:
                ph = self._mem.game_phase()
            except Exception:
                ph = None
            if ph is not None and ph < 5 and not self._ever_active:
                active = False           # ancora in preparazione: non scrivere
                self._wait_green = True
        if not active:
            self._writing = False
            self._st("garage" if bool(d.get("garage")) else
                     ("not_on_track (is_on_track=False)" if not on_track else "inattivo"))
            if self._db is not None:
                self._db.flush()      # salva quel che c'è, ma non aprire nuovi file
            if bool(d.get("garage")):
                self._garage_seen = True
            self._was_active = False
            return

        # transizione inattivo->attivo: nuovo stint SOLO se si è usciti dal garage
        if not self._was_active:
            if not self._stint_started:
                self._stint_started = True            # primo stint del file
            elif self._db is not None and self._garage_seen:
                self._file_stint += 1                 # uscita dal box = stint successivo
                self._stint_lap_count = 0
                self._prev_sector = None              # reinit pulito per il nuovo stint
            self._garage_seen = False
        self._was_active = True
        self._ever_active = True

        # PIT STOP (gara): num_pit che sale = fine stint, senza passare dal garage.
        # In pit l'auto resta "attiva", quindi va rilevato qui, non sulla
        # transizione attivo/inattivo.
        np = int(d.get("num_pit", 0) or 0)
        if (self._last_num_pit is not None and np > self._last_num_pit
                and self._stint_started and self._db is not None):
            self._file_stint += 1
            self._stint_lap_count = 0
            self._prev_sector = None
            self._garage_seen = False     # evita doppio incremento se segue il garage
        self._last_num_pit = np

        # nuovo evento? (cambio pista o auto) -> nuovo file
        self._maybe_new_event(d)
        if self._db is None:
            self._st("db_none (track='%s' car='%s' -> file non creato)"
                     % (d.get("track") or "", d.get("car_class") or ""))
            return
        self._writing = True
        self._st("recording %s" % (self._evt_track or ""))

        sector = int(d.get("sector", 0) or 0)
        laps = int(d.get("laps_completed", 0) or 0)
        fuel = d.get("fuel")
        ve = d.get("ve_pct")

        # init contatori al primo campione utile
        if self._prev_sector is None:
            self._prev_sector = sector
            self._prev_laps = laps
            self._cur_lap_id = laps + 1
            self._lap_start_fuel = fuel
            self._lap_start_ve = ve
            self._prev_et = None
            self._prev_soc = d.get("soc")
            self._lap_regen_pos = 0.0
            self._lap_boost = 0.0
            self._lap_soc_start = d.get("soc")
            self._reset_sector_acc(d)

        # accumula per il settore corrente
        carc = d.get("tyre_carcass") or [None] * 4
        surf = d.get("tyre_surf") or [None] * 4     # battistrada (3 punti L/C/R)
        inner = d.get("tyre_inner") or [None] * 4   # strato interno (3 punti L/C/R)
        press = d.get("tyre_press") or [None] * 4   # pressione (kPa)
        brk = d.get("brake_temp") or [None] * 4
        for i in range(4):
            if carc[i] is not None:
                self._sec_t_sum[i] += carc[i]
            sv = self._mean3(surf[i])
            if sv is not None:
                self._sec_ts_sum[i] += sv
            iv = self._mean3(inner[i])
            if iv is not None:
                self._sec_ti_sum[i] += iv
            if press[i] is not None:
                self._sec_p_sum[i] += press[i]
            if brk[i] is not None:
                self._sec_b_sum[i] += brk[i]
        self._sec_regen_sum += float(d.get("regen_kw", 0.0) or 0.0)
        # integrale energia: regen_kw firmato (+recupero / -deploy) * dt
        et = d.get("elapsed")
        if et is not None and self._prev_et is not None:
            dt = et - self._prev_et
            if 0.0 < dt < 0.5:
                rk = float(d.get("regen_kw", 0.0) or 0.0)
                e = abs(rk) * dt / 3600.0
                if rk > 0:
                    self._sec_regen_pos += e; self._lap_regen_pos += e
                elif rk < 0:
                    self._sec_boost += e; self._lap_boost += e
        self._prev_et = et
        self._prev_soc = d.get("soc")
        sp = d.get("speed")
        if sp is not None:
            self._sec_spd_sum += sp
            if sp > self._sec_spd_max:
                self._sec_spd_max = sp
        self._sec_n += 1

        # traccia (campione alta frequenza, taggato per giro)
        samp = {
            "lap": self._cur_lap_id,
            "t": float(d.get("elapsed", 0)) - float(d.get("lap_start_et", 0)),
            "lapdist": d.get("lapdist"),
            "pos_x": d.get("pos_x"), "pos_y": d.get("pos_y"), "pos_z": d.get("pos_z"),
            "speed": d.get("speed"),
            "throttle": d.get("throttle"), "brake": d.get("brake"), "steer": d.get("steer"),
            "g_long": d.get("g_long"), "g_lat": d.get("g_lat"),
            "tc_active": d.get("tc_active"), "abs_active": d.get("abs_active"),
            "brake_bias": d.get("brake_bias"),
            "tc_map": d.get("tc_map"), "abs_map": d.get("abs_map"),
            "tc_slip": d.get("tc_slip"), "tc_cut": d.get("tc_cut"),
            "gear": d.get("gear"), "rpm": d.get("rpm"),
            "soc": d.get("soc"), "regen_kw": d.get("regen_kw"),
            "boost_state": d.get("boost_state"),
            "fuel": d.get("fuel"), "ve": d.get("ve_pct"),
            "tyre_t": self._mean4(carc),
            "tyre_ts": self._mean4([self._mean3(surf[i]) for i in range(4)]),
            "tyre_ti": self._mean4([self._mean3(inner[i]) for i in range(4)]),
            "tyre_p": self._mean4(press),
            "brake_t": self._mean4(brk),
        }
        # canali PER RUOTA (FL/FR/RL/RR) per i grafici gomma dedicati
        wear_s = d.get("tyre_wear") or [None] * 4
        sdefl_s = d.get("susp_defl") or [None] * 4
        rideh_s = d.get("ride_h") or [None] * 4
        bpress_s = d.get("brake_press") or [None] * 4
        for i, wn in enumerate(("fl", "fr", "rl", "rr")):
            samp["tyre_t_" + wn] = carc[i]
            samp["tyre_ts_" + wn] = self._mean3(surf[i])
            samp["tyre_ti_" + wn] = self._mean3(inner[i])
            samp["tyre_p_" + wn] = press[i]
            samp["brake_t_" + wn] = brk[i]
            samp["susp_d_" + wn] = sdefl_s[i]
            samp["ride_h_" + wn] = rideh_s[i]
            samp["brake_p_" + wn] = bpress_s[i]
            samp["tyre_w_" + wn] = wear_s[i]
        self._db.add_sample(samp)

        # cambio settore -> scrivi aggregato del settore appena chiuso
        if sector != self._prev_sector:
            self._write_sector(d, self._prev_sector, self._cur_lap_id)
            self._prev_sector = sector
            self._reset_sector_acc(d)

        # giro completato -> scrivi riga giro
        if self._prev_laps is not None and laps > self._prev_laps:
            self._write_lap(d, laps)
            self._prev_laps = laps
            self._cur_lap_id = laps + 1
            self._lap_start_fuel = fuel
            self._lap_start_ve = ve
            self._lap_regen_pos = 0.0
            self._lap_boost = 0.0
            self._lap_soc_start = d.get("soc")

        # flush periodico
        now = time.monotonic()
        if now - self._last_flush > 1.5:
            self._db.flush()
            self._last_flush = now

    # ── eventi/file ────────────────────────────────────────────────────
    def _maybe_new_event(self, d):
        track = d.get("track") or ""
        car = d.get("car_class") or ""
        session = d.get("session_type")
        if not track:
            return
        # stesso evento = stessa pista + stessa auto + stessa sessione. Pausa e
        # garage NON aprono un nuovo file (oscillano realtime/garage, non la
        # sessione): proseguono lo stesso file, nuovo stint. Nuovo file solo se
        # cambia pista, auto, o il tipo di sessione (Practice->Quali->Race, cioè
        # quando il tempo di sessione finisce e ne parte un'altra).
        if (self._db is not None and track == self._evt_track
                and (car == self._evt_car or not car)
                and session == self._evt_session):
            return
        # chiudi il precedente
        if self._db is not None:
            try:
                self._db.close()
            except Exception:
                pass
            self._db = None
        # apri il nuovo
        try:
            fn = _db.LOGS_DIR / _db.make_filename(track, car, session)
            self._db = _db.TelemetryDB(fn)
            self._db.write_meta({
                "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "started_et": d.get("cur_et"),
                "session_len": d.get("race_total"),
                "track": track,
                "track_logo": None,
                "vehicle": d.get("vehicle"),
                "car_class": car,
                "session_type": session,
                "fuel_max": d.get("fuel_max"),
                "ve_max": 100.0,
                "app_version": "v0.1 beta",
                "car_num": self._player_num(),
                "driver": d.get("driver"),
                "team": d.get("team"),
                "fuel_start": d.get("fuel"),
                "air_temp": d.get("air_temp"),
                "track_temp": d.get("track_temp"),
                "wetness": d.get("wetness"),
                "compound_f": d.get("compound_front"),
                "compound_r": d.get("compound_rear"),
                "compounds4": ",".join(d.get("tyre_compound4") or []),
            })
            _diag("FILE CREATO: %s" % fn)
            self._evt_track = track
            self._evt_session = session
            self._evt_car = car
            self._prev_sector = None      # forza re-init contatori
            self._file_stint = 1
            self._stint_lap_count = 0
            self._stint_started = True
            self._garage_seen = False
            self._last_num_pit = None
            try:
                self._tracker.reset_all()  # stint riparte da 1 sul nuovo evento
            except Exception:
                pass
        except Exception:
            _diag("ERROR creating file:\n" + traceback.format_exc())
            self._db = None

    def _reset_sector_acc(self, d):
        self._sec_start_fuel = d.get("fuel")
        self._sec_start_ve = d.get("ve_pct")
        wear = d.get("tyre_wear") or [None] * 4
        self._sec_start_wear = list(wear)
        self._sec_t_sum = [0.0] * 4
        self._sec_ts_sum = [0.0] * 4
        self._sec_ti_sum = [0.0] * 4
        self._sec_p_sum = [0.0] * 4
        self._sec_b_sum = [0.0] * 4
        self._sec_regen_sum = 0.0
        self._sec_spd_sum = 0.0
        self._sec_spd_max = 0.0
        self._sec_n = 0
        self._sec_regen_pos = 0.0
        self._sec_boost = 0.0
        self._sec_soc_start = d.get("soc")

    def _write_sector(self, d, sec_idx, lap):
        n = max(1, self._sec_n)
        wear = d.get("tyre_wear") or [None] * 4
        row = {"lap": lap, "sector": int(sec_idx), "s_time": None,
               "fuel_used": self._delta(self._sec_start_fuel, d.get("fuel")),
               "ve_used": self._delta(self._sec_start_ve, d.get("ve_pct")),
               "regen_kwh": self._sec_regen_sum / n,
               "spd_avg": self._sec_spd_sum / n,
               "spd_max": self._sec_spd_max,
               "regen_gain_kwh": self._sec_regen_pos,
               "boost_kwh": self._sec_boost,
               "soc_used": self._delta(self._sec_soc_start, d.get("soc"))}
        keys = ("fl", "fr", "rl", "rr")
        for i, k in enumerate(keys):
            row["t_" + k] = self._sec_t_sum[i] / n
            row["ts_" + k] = self._sec_ts_sum[i] / n
            row["ti_" + k] = self._sec_ti_sum[i] / n
            row["p_" + k] = self._sec_p_sum[i] / n
            row["b_" + k] = self._sec_b_sum[i] / n
            sw = self._sec_start_wear[i]
            row["w_" + k] = self._delta(sw, wear[i]) if (sw is not None and wear[i] is not None) else None
        self._db.add_sector(row)

    def _write_lap(self, d, lap):
        s1 = d.get("last_s1") or 0.0
        s2sum = d.get("last_s2") or 0.0
        lt = d.get("last_lap") or 0.0
        sec1 = s1
        sec2 = (s2sum - s1) if s2sum and s1 else None
        sec3 = (lt - s2sum) if lt and s2sum else None
        carc = d.get("tyre_carcass") or [None] * 4
        surf = d.get("tyre_surf") or [None] * 4
        inner = d.get("tyre_inner") or [None] * 4
        press = d.get("tyre_press") or [None] * 4
        wear = d.get("tyre_wear") or [None] * 4
        brk = d.get("brake_temp") or [None] * 4
        row = {"lap": lap, "stint": self._file_stint,
               "lap_time": lt, "s1": sec1, "s2": sec2, "s3": sec3,
               "invalid": 1 if d.get("lap_invalid") else 0,
               "fuel_used": self._delta(self._lap_start_fuel, d.get("fuel")),
               "ve_used": self._delta(self._lap_start_ve, d.get("ve_pct")),
               "fuel_end": d.get("fuel"), "ve_end": d.get("ve_pct"),
               "regen_gain_kwh": self._lap_regen_pos, "boost_kwh": self._lap_boost,
               "soc_start": self._lap_soc_start, "soc_end": d.get("soc")}
        keys = ("fl", "fr", "rl", "rr")
        for i, k in enumerate(keys):
            row["t_" + k] = carc[i]
            row["ts_" + k] = self._mean3(surf[i])
            row["ti_" + k] = self._mean3(inner[i])
            row["p_" + k] = press[i]
            row["w_" + k] = wear[i]
            row["b_" + k] = brk[i]
        self._db.add_lap(row)
        self._stint_lap_count += 1
        # auto-reference: se il giro è valido e batte il record (classe+pista+meteo)
        if not d.get("lap_invalid") and lt and lt > 0:
            try:
                self._db.flush()              # committa samples del giro per lo snapshot
                _newref = _db.update_reference_if_better(
                    self._db._con, lap, d.get("car_class"), d.get("track"), d.get("wetness"))
                if _newref:                   # nuovo best salvato -> condividi online
                    self._upload_online_best(d, lt, sec1, sec2, sec3, wear)
            except Exception:
                pass

    def _upload_online_best(self, d, lt, sec1, sec2, sec3, wear):
        """Invia il best appena salvato al Worker (POST /ref, async). Stessa
        chiave della lettura: CLASSE_pista_DRY|WET. Degrada in sicurezza."""
        try:
            from core import online
            from core.classes import class_tag
        except Exception:
            return
        wet = (d.get("wetness") or 0.0) > 0.10
        key = online.make_key(class_tag(d.get("car_class") or ""), d.get("track"), wet)
        if not key:
            return
        c4 = ""; fmax = None
        try:
            r = self._db._con.execute(
                "SELECT compounds4, fuel_max FROM session_meta WHERE id=1").fetchone()
            if r:
                c4 = (r[0] or ""); fmax = r[1]
        except Exception:
            pass
        four = [x.strip() for x in c4.split(",") if x.strip()]
        single = four[0] if (four and all(x == four[0] for x in four)) else None
        ws = [x for x in (wear or []) if x is not None]
        state = (sum(ws) / len(ws)) if ws else None
        fuel_pct = None
        fu = d.get("fuel")
        if fu is not None and fmax:
            try:
                fuel_pct = fu / fmax * 100.0
            except Exception:
                fuel_pct = None
        team = None
        try:
            import json
            import pathlib
            pf = pathlib.Path(__file__).resolve().parent.parent / "settings" / "profile.json"
            team = (json.loads(pf.read_text(encoding="utf-8")).get("team") or None)
        except Exception:
            team = None
        payload = {
            "key": key,
            "lap_ms": int(round(lt * 1000)),
            "s1_ms": int(round(sec1 * 1000)) if sec1 else None,
            "s2_ms": int(round(sec2 * 1000)) if sec2 else None,
            "s3_ms": int(round(sec3 * 1000)) if sec3 else None,
            "car": d.get("vehicle"),
            "compound": single,
            "compounds4": c4 or None,
            "tyre_state_pct": state,
            "ve_pct": d.get("ve_pct"),
            "fuel_pct": fuel_pct,
            "fuel_l": self._lap_start_fuel,
            "session_type": d.get("session_type"),
            "team": team,
            "player": d.get("driver"),
            "game_ver": d.get("game_ver"),
        }
        online.submit_async(payload)

    def _player_num(self):
        """Numero mostrato sul dot = posizione in classe del pilota (come il
        widget mappa). Calcolato una volta alla creazione del file."""
        try:
            sim = self._mem._get_sim()
            si = sim.scoring.scoringInfo
            from pyLMUSharedMemory.lmu_data import MAX_MAPPED_VEHICLES as _MAX
            from core.classes import class_tag
            n = int(si.mNumVehicles)
            counter = {}
            pnum = ""
            for i in range(min(n, _MAX)):
                v = sim.scoring.vehScoringInfo[i]
                cls = bytes(v.mVehicleClass).split(b"\x00")[0].decode("utf-8", "ignore")
                tag = class_tag(cls)
                counter[tag] = counter.get(tag, 0) + 1
                if bool(v.mIsPlayer):
                    pnum = str(counter[tag])
            return pnum
        except Exception:
            return ""

    @staticmethod
    def _mean4(v):
        xs = [x for x in (v or []) if x is not None]
        return sum(xs) / len(xs) if xs else None

    @staticmethod
    def _mean3(v):
        if not v:
            return None
        xs = [x for x in v if x is not None]
        return sum(xs) / len(xs) if xs else None

    @staticmethod
    def _delta(a, b):
        if a is None or b is None:
            return None
        return a - b

    # ── per il widget ──────────────────────────────────────────────────
    def latest(self):
        with self._lock:
            return dict(self._latest)
