"""
engineer_overlay.py — Race Engineer overlay (stile TinyPedal).

Card frameless trasparente, sempre in primo piano, TRASCINABILE:
  - simbolo ingegnere a sinistra
  - messaggio a destra che compare in FADE a ogni giro chiuso
  - bip radio quando appare il messaggio

Codici messaggio (colorati):
  GOMME:   T++ / T+  = rosso (consumi troppa gomma)   ·  T- / T-- = verde (gestione ok)
  ENERGIA: E++ / E+  = rosso (troppa energia)          ·  E- / E-- = verde (gestione ok)
  (neutro = non mostrato)

USO:
  python engineer_overlay.py
  - trascina la card con il mouse per posizionarla
  - tasto destro sulla card = menu (Demo on/off, Esci)
  - ESC = esci

NOTE: parte in modalità DEMO (cicla messaggi di esempio) così puoi posizionarla
e vedere il fade + il bip. Il collegamento ai dati veri del giro (shared memory
LMU / DB TelemetryPro) è il passo successivo: basta chiamare overlay.push(t_code,
e_code, lap) a ogni giro chiuso.
"""
import sys
from pathlib import Path

from PySide6.QtCore import (Qt, QTimer, QPoint, QByteArray, QPropertyAnimation,
                            QEasingCurve, Property, QUrl)
from PySide6.QtGui import QPainter, QColor, QFont, QAction
from PySide6.QtWidgets import (QApplication, QWidget, QLabel, QHBoxLayout,
                               QVBoxLayout, QFrame, QMenu, QGraphicsOpacityEffect)

try:
    from PySide6.QtSvg import QSvgRenderer
except Exception:
    QSvgRenderer = None

try:
    from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
except Exception:
    QMediaPlayer = QAudioOutput = None

_RADIO_MP3 = Path(__file__).resolve().parent / "assets" / "radio.mp3"


# ── palette ───────────────────────────────────────────────────────────────
_CARD_BG = QColor(18, 20, 24, 235)      # grafite semitrasparente
_CARD_BORDER = QColor(54, 194, 168, 180)  # teal
_RED = "#ff5b5b"
_GREEN = "#55ff7f"
_DIM = "#9aa0aa"
_FG = "#f2f4f7"

# livelli messaggio: colore accento (icona/bordo) per tipo
_LEVELS = {
    "critical": "#ff3b3b",   # BOX BOX BOX, no fuel
    "warn":     "#ffb020",   # fuel pochi giri, lift&coast
    "info":     "#1c9fe0",   # strategia / consumi
}

# icona ingegnere: cuffia + microfono (headset) in SVG
_ENG_SVG = (
    b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' "
    b"fill='none' stroke='%s' stroke-width='1.8' stroke-linecap='round' "
    b"stroke-linejoin='round'>"
    b"<path d='M4 13v-1a8 8 0 0 1 16 0v1'/>"
    b"<rect x='2.5' y='13' width='3.5' height='6' rx='1.4'/>"
    b"<rect x='18' y='13' width='3.5' height='6' rx='1.4'/>"
    b"<path d='M20 19v1a3 3 0 0 1-3 3h-3'/>"
    b"<circle cx='12' cy='23' r='1'/>"
    b"</svg>"
)


def _code_color(code):
    if not code:
        return _DIM
    return _RED if code[1:2] == "+" else _GREEN     # T+/T++/E+/E++ rosso, T-/.. verde


class _EngIcon(QWidget):
    """Render dell'icona ingegnere (SVG) con colore."""
    def __init__(self, color="#1c9fe0", size=34):
        super().__init__()
        self._sz = size
        self.setFixedSize(size, size)
        self._r = None
        if QSvgRenderer is not None:
            try:
                self._r = QSvgRenderer(QByteArray(_ENG_SVG % color.encode()))
                if not self._r.isValid():
                    self._r = None
            except Exception:
                self._r = None

    def set_color(self, color):
        if QSvgRenderer is None:
            return
        try:
            r = QSvgRenderer(QByteArray(_ENG_SVG % color.encode()))
            self._r = r if r.isValid() else self._r
            self.update()
        except Exception:
            pass

    def paintEvent(self, e):
        if self._r is None:
            return
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        self._r.render(p)
        p.end()


class EngineerOverlay(QWidget):
    def __init__(self, standalone=True):
        super().__init__()
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setWindowTitle("Race Engineer")
        self._drag = None
        self._standalone = standalone
        self._st = {}          # stato fire-once (no spam dello stesso messaggio)
        self._feed = None      # feed dati live (lazy)
        self._live_timer = None

        # suono radio (assets/radio.mp3)
        self._player = None
        if QMediaPlayer is not None and _RADIO_MP3.exists():
            try:
                self._player = QMediaPlayer(self)
                self._audio = QAudioOutput(self)
                self._audio.setVolume(1.0)
                self._player.setAudioOutput(self._audio)
                self._player.setSource(QUrl.fromLocalFile(str(_RADIO_MP3)))
            except Exception:
                self._player = None

        # ── card ──
        self.card = QFrame(self)
        self.card.setObjectName("engCard")
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(self.card)

        row = QHBoxLayout(self.card)
        row.setContentsMargins(14, 10, 16, 10)
        row.setSpacing(12)

        self.icon = _EngIcon("#1c9fe0", 34)
        row.addWidget(self.icon, 0, Qt.AlignVCenter)

        col = QVBoxLayout()
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(1)
        self.title = QLabel("ENGINEER")
        self.title.setStyleSheet("color:#7e828c;font-size:9px;font-weight:800;"
                                 "letter-spacing:2px;background:transparent;")
        col.addWidget(self.title)
        self.msg = QLabel("")
        self.msg.setTextFormat(Qt.RichText)
        self.msg.setStyleSheet("color:%s;font-size:17px;font-weight:800;"
                               "letter-spacing:1px;background:transparent;" % _FG)
        col.addWidget(self.msg)
        row.addLayout(col, 1)

        self.card.setStyleSheet(
            "#engCard{background:rgba(18,20,24,235);"
            "border:1px solid rgba(54,194,168,180);border-radius:14px;}")

        # fade SOLO sul testo del messaggio (la card resta sempre visibile)
        self._msg_fx = QGraphicsOpacityEffect(self.msg)
        self._msg_fx.setOpacity(0.0)
        self.msg.setGraphicsEffect(self._msg_fx)
        self._anim = QPropertyAnimation(self._msg_fx, b"opacity")
        self._anim.setDuration(280)
        self._anim.setEasingCurve(QEasingCurve.InOutQuad)
        self._hold = QTimer(self); self._hold.setSingleShot(True)
        self._hold.timeout.connect(self._fade_msg_out)

        self.resize(self.sizeHint())
        self._move_default()

    def _move_default(self):
        scr = QApplication.primaryScreen().availableGeometry()
        self.move(scr.center().x() - self.width() // 2, int(scr.height() * 0.18))

    # ── core: mostra un messaggio (testo già formattato) con livello ──
    def show_msg(self, body, level="info", beep=True):
        accent = _LEVELS.get(level, _LEVELS["info"])
        self.icon.set_color(accent)
        self.card.setStyleSheet(
            "#engCard{background:rgba(18,20,24,235);"
            "border:1px solid %s;border-radius:14px;}" % accent)
        self.msg.setText(body)
        self.msg.setVisible(True)
        self.resize(self.sizeHint())
        if beep:
            self._play_radio()           # suono radio (assets/radio.mp3)
        self._fade_msg_in()

    # ── scorciatoie tipiche da ingegnere ──
    def box(self):
        """Carburante < 1 giro: rientro obbligato."""
        self.show_msg("<span style='color:%s'>BOX BOX BOX</span>" % _LEVELS["critical"],
                      "critical")

    def fuel_laps(self, laps):
        """Avviso carburante: giri rimanenti stimati."""
        if laps < 1.0:
            self.box()
            return
        self.show_msg("<span style='color:%s'>FUEL %.1f LAPS</span>" % (_LEVELS["warn"], laps),
                      "warn")

    def lift(self, pct):
        """Lift & coast: alza il piede per risparmiare carburante."""
        self.show_msg("<span style='color:%s'>LIFT %d%%</span>" % (_LEVELS["warn"], int(pct)),
                      "warn")

    def strategy(self, text):
        """Messaggio strategia generico."""
        self.show_msg("<span style='color:%s'>%s</span>" % (_LEVELS["info"], text), "info")

    def consumption(self, t_code=None, e_code=None, lap=None):
        """Consumi gomme/energia: mostra solo i codici forti (++ o --)."""
        important = (t_code in ("T++", "T--")) or (e_code in ("E++", "E--"))
        if not important:
            return
        parts = []
        if t_code:
            parts.append("<span style='color:%s'>%s</span>" % (_code_color(t_code), t_code))
        if e_code:
            parts.append("<span style='color:%s'>%s</span>" % (_code_color(e_code), e_code))
        body = "&nbsp;&nbsp;".join(parts)
        if lap is not None:
            body = ("<span style='color:#6e727b;font-size:12px'>L%d</span>&nbsp;&nbsp;" % lap) + body
        self.show_msg(body, "info")

    # compat: vecchia firma push(t_code, e_code, lap)
    def push(self, t_code=None, e_code=None, lap=None, beep=True):
        self.consumption(t_code, e_code, lap)

    # ── feed dati LIVE (riusa reader + strategy del progetto) ──
    def start_live(self, margin=2.0, hz=1.0):
        """Avvia la lettura live dalla shared memory LMU. Se i moduli del
        progetto non sono importabili (es. fuori dall'app), resta in idle e
        funziona solo il menu Test."""
        try:
            import os
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from telemetry.reader import TelemetryReader
            from telemetry import strategy as _strat
            self._feed = {
                "reader": TelemetryReader(),
                "tracker": _strat.StintTracker(window=3),
                "compute": _strat.compute,
                "margin": margin,
            }
        except Exception:
            self._feed = None
            return False
        self._live_timer = QTimer(self)
        self._live_timer.timeout.connect(self._live_tick)
        self._live_timer.start(int(1000 / max(0.2, hz)))
        return True

    def feed_latest(self, latest, in_pits=None):
        """Alimentazione alternativa: passa direttamente recorder.latest()
        (dict con 'strat' e 'raw'). Usala se integri l'overlay nel processo
        principale invece del feed live autonomo."""
        strat = (latest or {}).get("strat") or {}
        raw = (latest or {}).get("raw") or {}
        self._eval(strat, raw.get("in_pits") if in_pits is None else in_pits)

    def _live_tick(self):
        if not self._feed:
            return
        try:
            d = self._feed["reader"].read()
            if not d:
                self._st = {}            # fuori sessione: azzera fire-once
                return
            self._feed["tracker"].update(d)
            measured = self._feed["tracker"].measured(d)
            strat = self._feed["compute"](measured, self._feed["margin"])
        except Exception:
            return
        self._eval(strat, d.get("in_pits"))

    # ── decide quale messaggio (importante) mostrare, una volta sola ──
    def _eval(self, strat, in_pits):
        if in_pits:
            self._st = {}                # ai box: niente avvisi, reset
            return
        pf = (strat or {}).get("plan_fuel") or {}
        auto = pf.get("autonomy")        # giri residui col carburante attuale
        save = bool((strat or {}).get("save_a_stop"))
        over = (strat or {}).get("on_target") == "over"

        def once(key):
            if self._st.get(key):
                return False
            self._st[key] = True
            return True

        # carburante < 1 giro -> BOX BOX BOX
        if auto is not None and auto < 1.0:
            if once("box"):
                self.box()
            return
        self._st["box"] = False

        # carburante basso (<= 3 giri) -> FUEL n LAPS
        if auto is not None and auto <= 3.0:
            if once("low"):
                self.fuel_laps(auto)
            return
        self._st["low"] = False

        # consumi troppo / puoi salvare una sosta -> LIFT & COAST
        if over or save:
            if once("lift"):
                self.lift(8 if over else 4)
            return
        self._st["lift"] = False

    def _play_radio(self):
        if self._player is not None:
            try:
                self._player.stop()
                self._player.setPosition(0)
                self._player.play()
                return
            except Exception:
                pass
        QApplication.beep()              # fallback se mp3/multimedia non disponibili

    def _fade_msg_in(self):
        self._hold.stop()
        self._anim.stop()
        self._anim.setStartValue(self._msg_fx.opacity())
        self._anim.setEndValue(1.0)
        self._anim.start()
        self._hold.start(4000)           # resta 4s poi svanisce

    def _fade_msg_out(self):
        self._anim.stop()
        self._anim.setStartValue(self._msg_fx.opacity())
        self._anim.setEndValue(0.0)
        self._anim.start()

    # ── trascinamento ──
    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()
            e.accept()

    def mouseMoveEvent(self, e):
        if self._drag is not None and (e.buttons() & Qt.LeftButton):
            self.move(e.globalPosition().toPoint() - self._drag)
            e.accept()

    def mouseReleaseEvent(self, e):
        self._drag = None

    def contextMenuEvent(self, e):
        m = QMenu(self)
        sub = m.addMenu("Test message")
        for label, fn in (
            ("BOX BOX BOX", lambda: self.box()),
            ("FUEL 2.0 LAPS", lambda: self.fuel_laps(2.0)),
            ("LIFT 5%", lambda: self.lift(5)),
            ("PIT WINDOW", lambda: self.strategy("PIT WINDOW")),
            ("T-- E+", lambda: self.consumption("T--", "E+")),
            ("E++", lambda: self.consumption(None, "E++")),
        ):
            a = QAction(label, self); a.triggered.connect(fn); sub.addAction(a)
        a_quit = QAction("Quit" if self._standalone else "Hide", self)
        a_quit.triggered.connect(self._close)
        m.addAction(a_quit)
        m.exec(e.globalPos())

    def _close(self):
        if self._standalone:
            QApplication.quit()
        else:
            self.hide()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Escape:
            self._close()


def main():
    app = QApplication(sys.argv)
    w = EngineerOverlay(standalone=True)
    w.start_live()                 # legge live dalla shared memory LMU (se disponibile)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
