"""
telemetry/window.py — Finestra telemetria (review).

Navigazione compatta a menu a cascata, tutto in una barra:
    Sessione ▾ · Stint ▾ · Giro ▾        (+ ↻  🗑)
Sotto: un solo set di tab  Tempi · Gomme · Energia · Guida · Mappa.

Cascata:
  Sessione  -> carica i giri, riempie il menu Stint (Stint 1, 2, ...)
  Stint     -> riempie il menu Giro coi giri dello stint (default: più veloce);
               aggiorna Tempi (tabella stint) ed Energia (consumi stint)
  Giro      -> aggiorna Gomme / Guida / Mappa sul giro scelto;
               Tempi evidenzia la riga del giro.

Grafici in QPainter, nessuna dipendenza esterna.
"""
import os
import sqlite3
import time
import math

from PySide6.QtWidgets import (QWidget, QMainWindow, QTabWidget, QTabBar, QVBoxLayout,
                               QHBoxLayout, QComboBox, QPushButton, QLabel,
                               QTableWidget, QTableWidgetItem, QHeaderView,
                               QAbstractItemView, QStyledItemDelegate, QMessageBox,
                               QColorDialog, QStackedWidget, QGridLayout, QSizePolicy,
                               QLineEdit, QFrame, QCheckBox)
from PySide6.QtCore import Qt, QRectF, QPointF, QTimer, QSize
from pathlib import Path
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QPolygonF, QFont, QPainterPath, QLinearGradient, QPixmap
try:
    from PySide6.QtSvgWidgets import QSvgWidget
except Exception:
    QSvgWidget = None
try:
    from PySide6.QtSvg import QSvgRenderer
except Exception:
    QSvgRenderer = None
from PySide6.QtCore import QByteArray

from . import db as _db
from .reader import TelemetryReader
try:                                  # widget mappa vero (stessa grafica, tutte le auto)
    from widgets.map.widget import MapCanvas as _RealMapCanvas
    from widgets.map.reader import MapReader as _RealMapReader
except Exception:
    _RealMapCanvas = None
    _RealMapReader = None
from core.classes import class_tag

# colori classe (allineati al widget mappa)
_CLASS_COL = {
    "HY":  "#bd1016", "P2": "#1e3163", "P3": "#411c52",
    "GT3": "#01824d", "GTE": "#ff9100",
}

_BG = "#111114"          # grafite neutro (niente blu)
_FG = "#f5f5f5"
_GRID = "#2c2e33"
_ACCENT = "#1c9fe0"      # blu pista LMU (tab attiva)

# Link supporto allo sviluppo (modificabili)
_DONATE_URL = "https://paypal.me/Jonathanuk"     # link donazioni
_GITHUB_URL = "https://github.com/xvb-lab"
_APP_VERSION = "v0.1 beta"
_FUCHSIA = "#ff48cf"
_SEL_COL = "#55ff7f"     # giro Selected (verde)
_CMP_COL = "#8b7bff"     # giro Compare (viola)
_GOLD = "#f5c542"        # Compare = REF (record): oro
_TRK_COL = "#2a2c31"     # pista (scuro, pickabile)


# ogni categoria = una tab a sé (comparazione Selected vs Compare)
_TAB_GROUPS = [
    ("Pedals", []),
    ("Speed",  ["S1 speed (km/h)", "S2 speed (km/h)", "S3 speed (km/h)"]),
    ("VE",     ["VE used (%)"] + [f"S{s} VE (%)" for s in (1, 2, 3)]),
    ("Fuel",   ["Fuel used (L)"] + [f"S{s} fuel (L)" for s in (1, 2, 3)]),
    ("Hybrid", ["SOC start (%)", "SOC end (%)", "Regen gained (kWh)", "Boost used (kWh)"]
               + [f"S{s} regen (kWh)" for s in (1, 2, 3)]
               + [f"S{s} boost (kWh)" for s in (1, 2, 3)]
               + [f"S{s} SOC \u0394 (%)" for s in (1, 2, 3)]),
    ("Tyres",  [f"S{s} tyre \u00b0C" for s in (1, 2, 3)]
               + [f"S{s} press kPa" for s in (1, 2, 3)]
               + [f"S{s} wear %" for s in (1, 2, 3)]),
    ("Brakes", [f"S{s} brake \u00b0C" for s in (1, 2, 3)]),
    ("Suspension", []),
    ("Gear", []),
    ("Steering", []),
    ("RPM", []),
    ("Aids", []),
    ("G-G", []),
]

_HYBRID_HINTS = ("HY", "HYPER", "LMH", "LMDH", "LMP1")


def _is_hybrid(car_class):
    c = (car_class or "").upper()
    return any(h in c for h in _HYBRID_HINTS)


def _heat(v, lo, hi):
    if v is None:
        return QColor("#3d4046")
    f = max(0.0, min(1.0, (v - lo) / (hi - lo))) if hi > lo else 0.0
    stops = [(0.0, (74, 144, 226)), (0.5, (0, 230, 118)),
             (0.8, (255, 226, 77)), (1.0, (255, 59, 48))]
    for i in range(len(stops) - 1):
        f0, c0 = stops[i]; f1, c1 = stops[i + 1]
        if f0 <= f <= f1:
            t = (f - f0) / (f1 - f0) if f1 > f0 else 0
            return QColor(int(c0[0] + (c1[0] - c0[0]) * t),
                          int(c0[1] + (c1[1] - c0[1]) * t),
                          int(c0[2] + (c1[2] - c0[2]) * t))
    return QColor("#3d4046")


def _rows(con, sql, args=()):
    cur = con.execute(sql, args)
    cols = [c[0] for c in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def _fmt(s):
    if not s or s <= 0:
        return "\u2014"
    m = int(s) // 60; sec = s - m * 60
    return f"{m}:{sec:06.3f}" if m else f"{sec:.3f}"


_MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
           "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _date_human(s):
    """ISO '2026-06-23T04:25' / '2026-06-23 04:25' -> '23 Jun 2026, 04:25'."""
    s = (s or "")[:16].replace("T", " ")
    try:
        d, t = s.split(" ")
        y, mo, da = d.split("-")
        return "%d %s %s, %s" % (int(da), _MONTHS[int(mo) - 1], y, t)
    except Exception:
        return s


def _f2(v):
    return "\u2014" if v is None else f"{v:.2f}"


def _dur(secs):
    secs = int(secs or 0)
    h = secs // 3600; m = (secs % 3600) // 60
    return f"{h}h{m:02d}min" if h else f"{m}min"


_FUX = "#ff3bd4"   # fuxia: migliore (tempo/settore)
_SEL_IS_BEST = False   # True quando il giro selezionato è il best -> fuxia


def _sel_col():
    """Colore del giro SELEZIONATO: fuxia se è il best, altrimenti verde.
    (Il confronto è gestito da _cmp_col: oro REF / fuxia best / verde normale.)"""
    return _FUX if _SEL_IS_BEST else _SEL_COL


_CMP_IS_BEST = False   # True quando il giro di CONFRONTO è il best


def _cmp_col(gold=False):
    """Colore del giro di CONFRONTO: oro se REF, fuxia se è il best,
    altrimenti verde. (Niente più viola.)"""
    if gold:
        return _GOLD
    return _FUX if _CMP_IS_BEST else _SEL_COL


def _is_b(v, b):
    return b is not None and v is not None and abs(v - b) < 1e-6


def _best_color(v, best, normal="#ffffff"):
    """Fuxia se v è il migliore di stint, altrimenti colore normale."""
    return _FUX if _is_b(v, best) else normal


def _faster_colors(la, lb):
    """Colore (Selected, Compare): il più veloce dei due in fuxia."""
    if la and lb:
        return (_FUX, "#979aa1") if la <= lb else ("#979aa1", _FUX)
    if la:
        return (_FUX, "#979aa1")
    if lb:
        return ("#979aa1", _FUX)
    return ("#dcdddf", "#dcdddf")


def _draw_lap_legend(p, x0, y, items):
    """items: (dashed, label, time_str, time_color). Linea + 'Lap N' + tempo."""
    x = float(x0)
    for dashed, label, tstr, tcol in items:
        pen = QPen(QColor("#dcdddf"), 2)
        if dashed:
            pen.setStyle(Qt.DashLine)
        p.setPen(pen); p.drawLine(int(x), y, int(x) + 18, y)
        x += 24
        p.setPen(QColor("#dcdddf")); p.drawText(QPointF(x, y + 4), label)
        x += p.fontMetrics().horizontalAdvance(label) + 7
        if tstr:
            p.setPen(QColor(tcol)); p.drawText(QPointF(x, y + 4), tstr)
            x += p.fontMetrics().horizontalAdvance(tstr) + 18
        else:
            x += 14


def _draw_sector_times(p, Xf, bounds, sel_secs, cmp_secs, best_secs, xmin, xmax, y):
    """Per ogni settore: tempo Selected (sopra) e Compare (sotto). Il più veloce
    dei due settori mostrati è in fuxia."""
    for i in range(3):
        if i + 1 >= len(bounds):
            break
        cx = (bounds[i] + bounds[i + 1]) / 2.0
        if not (xmin <= cx <= xmax):
            continue
        sv = sel_secs[i] if i < len(sel_secs) else None
        cv = cmp_secs[i] if i < len(cmp_secs) else None
        bv = best_secs[i] if i < len(best_secs) else None
        sx = Xf(cx); yy = y
        if sv:
            col = _FUX if _is_b(sv, bv) else "#ffffff"
            s = _fmt(sv); tw = p.fontMetrics().horizontalAdvance(s)
            p.setPen(QColor(col)); p.drawText(QPointF(sx - tw / 2, yy), s); yy += 11
        if cv:
            col = _FUX if _is_b(cv, bv) else "#ffffff"
            s = _fmt(cv); tw = p.fontMetrics().horizontalAdvance(s)
            p.setPen(QColor(col)); p.drawText(QPointF(sx - tw / 2, yy), s)


def _fastest_lap(laps):
    valid = [L for L in laps if (L["lap_time"] or 0) > 0 and not L["invalid"]]
    if not valid:
        valid = [L for L in laps if (L["lap_time"] or 0) > 0]
    if not valid:
        return laps[0]["lap"] if laps else None
    return min(valid, key=lambda L: L["lap_time"])["lap"]


def _two_best_laps(laps):
    """Ritorna (miglior_giro, secondo_giro) validi per lap_time crescente."""
    valid = [L for L in laps if (L["lap_time"] or 0) > 0 and not L["invalid"]]
    if len(valid) < 2:
        valid = [L for L in laps if (L["lap_time"] or 0) > 0]
    order = sorted(valid, key=lambda L: L["lap_time"])
    best = order[0]["lap"] if len(order) >= 1 else (laps[0]["lap"] if laps else None)
    second = order[1]["lap"] if len(order) >= 2 else best
    return best, second


# ── grafici ───────────────────────────────────────────────────────────────
class LineChart(QWidget):
    def __init__(self):
        super().__init__()
        self._xs = []; self._series = []
        self.setMinimumHeight(170)

    def set_data(self, xs, series):
        self._xs = xs or []; self._series = series or []
        self.update()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(_BG))
        m = 30
        x0, y0, x1, y1 = m, 8, w - 8, h - m
        p.setPen(QPen(QColor(_GRID), 1)); p.drawRect(QRectF(x0, y0, x1 - x0, y1 - y0))
        if not self._xs or not self._series:
            p.setPen(QColor("#878a93")); p.drawText(self.rect(), Qt.AlignCenter, "no data"); return
        xmin, xmax = min(self._xs), max(self._xs)
        allv = [v for _, ys, _ in self._series for v in ys if v is not None]
        if not allv or xmax <= xmin:
            return
        vmin, vmax = min(allv), max(allv)
        if vmax <= vmin:
            vmax = vmin + 1
        px = lambda x: x0 + (x - xmin) / (xmax - xmin) * (x1 - x0)
        py = lambda v: y1 - (v - vmin) / (vmax - vmin) * (y1 - y0)
        for name, ys, col in self._series:
            p.setPen(QPen(col, 1.6)); poly = QPolygonF()
            for x, v in zip(self._xs, ys):
                if v is None:
                    continue
                poly.append(QPointF(px(x), py(v)))
            p.drawPolyline(poly)
        lx, ly = x0 + 6, y0 + 12
        for name, ys, col in self._series:
            p.setPen(QPen(col, 2)); p.drawLine(lx, ly, lx + 14, ly)
            p.setPen(QColor(_FG)); p.drawText(lx + 18, ly + 4, name)
            lx += 18 + p.fontMetrics().horizontalAdvance(name) + 18


class TrajectoryView(QWidget):
    def __init__(self):
        super().__init__()
        self._pts = []; self.setMinimumHeight(260)

    def set_path(self, pts):
        self._pts = pts or []; self.update()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(_BG))
        if len(self._pts) < 2:
            p.setPen(QColor("#878a93")); p.drawText(self.rect(), Qt.AlignCenter, "no trajectory"); return
        xs = [pt[0] for pt in self._pts]; zs = [pt[1] for pt in self._pts]
        vs = [pt[2] for pt in self._pts if pt[2] is not None] or [0, 1]
        xmin, xmax = min(xs), max(xs); zmin, zmax = min(zs), max(zs)
        vmin, vmax = min(vs), max(vs)
        sx = (xmax - xmin) or 1; sz = (zmax - zmin) or 1
        m = 16; scale = min((w - 2 * m) / sx, (h - 2 * m) / sz)
        ox = (w - sx * scale) / 2 - xmin * scale
        oz = (h - sz * scale) / 2 - zmin * scale
        P = lambda x, z: QPointF(ox + x * scale, h - (oz + z * scale))
        for i in range(1, len(self._pts)):
            x0, z0, _ = self._pts[i - 1]; x1, z1, v1 = self._pts[i]
            p.setPen(QPen(_heat(v1, vmin, vmax), 2.2)); p.drawLine(P(x0, z0), P(x1, z1))


# ── viste (persistenti, aggiornate via set_stint / set_lap) ────────────────
def _wheel_widget(spec):
    """Valori per-ruota in griglia 2x2 (FL FR / RL RR), sfondo trasparente.
    Temperature heat-colorate; usura in bianco."""
    from PySide6.QtWidgets import QGridLayout
    w = QWidget()
    w.setStyleSheet("background:transparent;")
    w.setAttribute(Qt.WA_TransparentForMouseEvents, True)
    g = QGridLayout(w)
    g.setContentsMargins(8, 2, 8, 2)
    g.setHorizontalSpacing(18); g.setVerticalSpacing(1)
    lo, hi, heat, dec = spec["lo"], spec["hi"], spec["heat"], spec["dec"]
    cells = list(zip(spec["wheels"], ("FL", "FR", "RL", "RR")))
    for idx, (val, pos) in enumerate(cells):
        if val is None:
            txt = "\u2014"; col = "#6b6f78"
        else:
            txt = f"{val:.{dec}f}"
            col = _heat(val, lo, hi).name() if heat else _FG
        lbl = QLabel(txt)
        lbl.setStyleSheet(f"color:{col};background:transparent;")
        g.addWidget(lbl, idx // 2, idx % 2)
    return w


class _LapData:
    """Motore dati condiviso fra le tab categoria.
    Calcola i valori di un giro (e i migliori dello stint) una volta sola."""
    def __init__(self):
        self.con = None
        self.car_class = ""
        self.sample_cols = set()
        self.tyre_mode = "t_"       # t_=carcass, ts_=tread, ti_=layer
        self._by_id = {}
        self._first = None
        self._best = {}
        self._stint_total = 0
        self._stint_laps = 0
        self.lap_ids = []
        # reference lap (confrontabile fra sessioni)
        self.ref_con = None
        self.ref_lap = None
        self.ref_on = False
        self.ref_label = ""
        self.ref_time = None
        self.ref_secs = [None, None, None]
        self.ref_driver = ""; self.ref_team = ""; self.ref_vehicle = ""
        self.ref_started = ""; self.ref_session = None
        self.ref_compounds4 = ""; self.ref_tyre_state = None
        self.ref_load_pct = None; self.ref_load_kind = ""
        self.ref_wear4 = []; self.ref_fuel_l = None

    def set_con(self, con):
        self.con = con
        self.sample_cols = set()
        if con is not None:
            try:
                self.sample_cols = {c[1] for c in con.execute("PRAGMA table_info(samples)")}
            except Exception:
                self.sample_cols = set()

    def set_stint(self, laps):
        self._by_id = {L["lap"]: L for L in laps}
        self._first = laps[0]["lap"] if laps else None
        self.lap_ids = [L["lap"] for L in laps]

        def _minpos(key, valid_only=False):
            vals = [L[key] for L in laps
                    if L[key] and L[key] > 0 and (not valid_only or not L["invalid"])]
            return min(vals) if vals else None
        self._best = {"lap_time": _minpos("lap_time", True),
                      "s1": _minpos("s1", True), "s2": _minpos("s2", True), "s3": _minpos("s3", True)}
        timed = [L["lap_time"] for L in laps if L["lap_time"] and L["lap_time"] > 0]
        self._stint_total = sum(timed)
        self._stint_laps = len(laps)

    def best_dict(self):
        """Best assoluto dello stint dai giri validi (stesso calcolo della lista
        Stint). Unica fonte per Times/grafici/Stint."""
        laps = list(self._by_id.values())

        def _b(key):
            vals = [L.get(key) for L in laps
                    if (L.get(key) or 0) > 0 and not L.get("invalid")]
            return min(vals) if vals else None
        return {"lap_time": _b("lap_time"), "s1": _b("s1"),
                "s2": _b("s2"), "s3": _b("s3")}

    def load_reference(self, path):
        """Apre un file .lmref (un solo giro) come riferimento confrontabile."""
        import os
        self.clear_reference()
        if not path or not os.path.exists(path):
            return False
        try:
            con = sqlite3.connect(path)
            row = con.execute(
                "SELECT lap, lap_time, s1, s2, s3 FROM laps ORDER BY lap LIMIT 1").fetchone()
            if not row:
                con.close(); return False
            self.ref_con = con
            self.ref_lap = row[0]
            self.ref_time = row[1]
            self.ref_secs = [row[2], row[3], row[4]]
            self.ref_label = ("REF " + (_fmt(row[1]) if row[1] else "")).strip()
            try:
                mr = con.execute("SELECT driver, team, vehicle, started_at, "
                                 "session_type FROM session_meta WHERE id=1").fetchone()
                self.ref_driver = (mr[0] if mr else "") or ""
                self.ref_team = (mr[1] if mr else "") or ""
                self.ref_vehicle = (mr[2] if mr else "") or ""
                self.ref_started = (mr[3] if mr else "") or ""
                self.ref_session = (mr[4] if mr else None)
            except Exception:
                self.ref_driver = self.ref_team = self.ref_vehicle = ""
                self.ref_started = ""; self.ref_session = None
            try:
                lr = con.execute(
                    "SELECT w_fl,w_fr,w_rl,w_rr,ve_end,fuel_end,fuel_used FROM laps WHERE lap=?",
                    (self.ref_lap,)).fetchone()
                mr2 = con.execute(
                    "SELECT compounds4, fuel_max FROM session_meta WHERE id=1").fetchone()
                self.ref_compounds4 = (mr2[0] if mr2 else "") or ""
                fmax = (mr2[1] if mr2 else None)
                if lr:
                    self.ref_wear4 = [lr[0], lr[1], lr[2], lr[3]]
                    ws = [x for x in lr[0:4] if x is not None]
                    self.ref_tyre_state = (sum(ws) / len(ws)) if ws else None
                    ve = lr[4]; fu = lr[5]; fuse = lr[6]
                    self.ref_fuel_l = (((fu or 0) + (fuse or 0))
                                       if (fu is not None or fuse is not None) else None)
                    if ve is not None:
                        self.ref_load_pct = ve; self.ref_load_kind = "VE"
                    elif fu is not None and fmax:
                        self.ref_load_pct = fu / fmax * 100.0; self.ref_load_kind = "FUEL"
            except Exception:
                self.ref_compounds4 = ""; self.ref_tyre_state = None
                self.ref_load_pct = None; self.ref_load_kind = ""
                self.ref_wear4 = []; self.ref_fuel_l = None
            return True
        except Exception:
            self.clear_reference(); return False

    def clear_reference(self):
        if self.ref_con is not None:
            try:
                self.ref_con.close()
            except Exception:
                pass
        self.ref_con = None; self.ref_lap = None
        self.ref_time = None; self.ref_secs = [None, None, None]; self.ref_label = ""
        self.ref_driver = ""; self.ref_team = ""; self.ref_vehicle = ""
        self.ref_started = ""; self.ref_session = None
        self.ref_compounds4 = ""; self.ref_tyre_state = None
        self.ref_load_pct = None; self.ref_load_kind = ""
        self.ref_wear4 = []; self.ref_fuel_l = None
        self.ref_on = False

    def cmp_source(self):
        """(con, lap, label, time, secs) del Compare se il reference è attivo, altrimenti None."""
        if self.ref_on and self.ref_con is not None and self.ref_lap is not None:
            return (self.ref_con, self.ref_lap, self.ref_label or "REF",
                    self.ref_time, self.ref_secs)
        return None

    def _elec_from_samples(self, lap):
        """Totali-giro ibrido integrati dai samples (per file senza colonne energia)."""
        rg = bo = 0.0
        soc0 = soc1 = None
        prev_t = None
        for r in _rows(self.con,
                       "SELECT t, regen_kw, soc FROM samples WHERE lap=? ORDER BY t", (lap,)):
            if soc0 is None:
                soc0 = r["soc"]
            soc1 = r["soc"]
            rk = r["regen_kw"] or 0.0
            if prev_t is not None:
                dt = r["t"] - prev_t
                if 0.0 < dt < 0.5:
                    e = abs(rk) * dt / 3600.0
                    if rk > 0:
                        rg += e
                    elif rk < 0:
                        bo += e
            prev_t = r["t"]
        return rg, bo, soc0, soc1

    def values(self, lap):
        L = self._by_id.get(lap)
        if not L:
            return None
        mx = av = None
        if self.con is not None:
            s = _rows(self.con,
                      "SELECT MAX(speed) mx, AVG(speed) av FROM samples WHERE lap=?", (lap,))
            if s:
                mx, av = s[0]["mx"], s[0]["av"]
        hyb = _is_hybrid(self.car_class)
        soc_s, soc_e = L.get("soc_start"), L.get("soc_end")
        rg_gain, bo_kwh = L.get("regen_gain_kwh"), L.get("boost_kwh")
        # file vecchi senza colonne energia: ricava i totali-giro dai samples
        if hyb and rg_gain is None and self.con is not None:
            rg_gain, bo_kwh, soc_s, soc_e = self._elec_from_samples(lap)
        t = L["lap_time"]
        ttxt = _fmt(t) if (t and t > 0) else ("OUT" if lap == self._first else "IN")
        fu, vu = L["fuel_used"], L["ve_used"]
        ftxt = "PIT" if (fu is not None and fu < 0) else _f2(fu)
        vtxt = "PIT" if (vu is not None and vu < 0) else _f2(vu)

        def _is_best(key, val, valid_req=False):
            b = self._best.get(key)
            if b is None or not val or val <= 0:
                return False
            if valid_req and L["invalid"]:
                return False
            return abs(val - b) < 1e-6

        vals = {"Stint": f"{_dur(self._stint_total)}  ({self._stint_laps} laps)",
                "Lap": str(lap), "Time": ttxt,
                "Sector 1": _fmt(L["s1"]), "Sector 2": _fmt(L["s2"]), "Sector 3": _fmt(L["s3"]),
                "Fuel used (L)": ftxt, "VE used (%)": vtxt,
                "SOC start (%)": "\u2014" if (not hyb or soc_s is None) else f"{soc_s:.1f}",
                "SOC end (%)": "\u2014" if (not hyb or soc_e is None) else f"{soc_e:.1f}",
                "Regen gained (kWh)": "\u2014" if (not hyb or rg_gain is None) else f"{rg_gain:.2f}",
                "Boost used (kWh)": "\u2014" if (not hyb or bo_kwh is None) else f"{bo_kwh:.2f}",
                "Top speed (km/h)": "\u2014" if mx is None else f"{mx:.1f}",
                "Avg speed (km/h)": "\u2014" if av is None else f"{av:.1f}",
                "Valid": "no" if L["invalid"] else "yes"}
        best = {"Time": _is_best("lap_time", t, True),
                "Sector 1": _is_best("s1", L["s1"]),
                "Sector 2": _is_best("s2", L["s2"]),
                "Sector 3": _is_best("s3", L["s3"])}

        secs = {}
        if self.con is not None:
            for sr in _rows(self.con, "SELECT * FROM sectors WHERE lap=? ORDER BY sector", (lap,)):
                secs[int(sr["sector"])] = sr

        def _w(sr, prefix):
            return [sr.get(prefix + k) for k in ("fl", "fr", "rl", "rr")]

        # PIT solo se il totale giro è davvero un rifornimento; altrimenti negativo = glitch -> "—"
        lap_fuel_pit = (fu is not None and fu < 0)
        lap_ve_pit = (vu is not None and vu < 0)

        def _sec_consumo(x, lap_pit):
            if x is None:
                return "\u2014"
            if x < 0:
                return "PIT" if lap_pit else "\u2014"
            return f"{x:.2f}"

        for s in (1, 2, 3):
            sr = secs.get(s - 1)
            if sr:
                sa, sm, sf = sr.get("spd_avg"), sr.get("spd_max"), sr.get("fuel_used")
                ve = sr.get("ve_used")
                rgs, bks, scu = sr.get("regen_gain_kwh"), sr.get("boost_kwh"), sr.get("soc_used")
                vals[f"S{s} speed avg (km/h)"] = "\u2014" if sa is None else f"{sa:.1f}"
                vals[f"S{s} speed max (km/h)"] = "\u2014" if sm is None else f"{sm:.1f}"
                vals[f"S{s} speed (km/h)"] = "\u2014" if sa is None else f"{sa:.1f}"
                vals[f"S{s} VE (%)"] = _sec_consumo(ve, lap_ve_pit)
                vals[f"S{s} fuel (L)"] = _sec_consumo(sf, lap_fuel_pit)
                vals[f"S{s} regen (kWh)"] = "\u2014" if (not hyb or rgs is None) else f"{rgs:.2f}"
                vals[f"S{s} boost (kWh)"] = "\u2014" if (not hyb or bks is None) else f"{bks:.2f}"
                vals[f"S{s} SOC \u0394 (%)"] = "\u2014" if (not hyb or scu is None) else f"{-scu:+.1f}"
                vals[f"S{s} tyre \u00b0C"] = {"wheels": _w(sr, self.tyre_mode), "lo": 60, "hi": 120, "heat": True, "dec": 0}
                vals[f"S{s} press kPa"] = {"wheels": _w(sr, "p_"), "lo": 120, "hi": 220, "heat": False, "dec": 0}
                vals[f"S{s} brake \u00b0C"] = {"wheels": _w(sr, "b_"), "lo": 100, "hi": 700, "heat": True, "dec": 0}
                vals[f"S{s} wear %"] = {"wheels": _w(sr, "w_"), "lo": 0, "hi": 100, "heat": False, "dec": 1}
            else:
                vals[f"S{s} speed avg (km/h)"] = "\u2014"
                vals[f"S{s} speed max (km/h)"] = "\u2014"
                vals[f"S{s} speed (km/h)"] = "\u2014"
                vals[f"S{s} VE (%)"] = "\u2014"
                vals[f"S{s} fuel (L)"] = "\u2014"
                vals[f"S{s} regen (kWh)"] = "\u2014"
                vals[f"S{s} boost (kWh)"] = "\u2014"
                vals[f"S{s} SOC \u0394 (%)"] = "\u2014"
                for nm, (lo, hi, ht, dec) in ((f"S{s} tyre \u00b0C", (60, 120, True, 0)),
                                              (f"S{s} press kPa", (120, 220, False, 0)),
                                              (f"S{s} brake \u00b0C", (100, 700, True, 0)),
                                              (f"S{s} wear %", (0, 100, False, 1))):
                    vals[nm] = {"wheels": [None, None, None, None], "lo": lo, "hi": hi, "heat": ht, "dec": dec}
        return vals, best


class _CmpChart(QWidget):
    """Confronto a linee Lap A vs Lap B del valore selezionato.
    Modalità 'trace' (continua sul giro) o 'points' (punti etichettati S1/S2/S3
    o FL/FR/RL/RR) con marker e valori. Colori configurabili dall'utente."""
    def __init__(self):
        super().__init__()
        self._title = ""
        self._unit = ""
        self._sa = []          # [(x, y)] giro Selected
        self._sb = []          # [(x, y)] giro Compare
        self._xlabels = None   # se valorizzato -> modalità 'points'
        self._groups = []      # [(label, A, B)] -> modalità 'bars'
        self._mode = "line"
        self._la = "A"
        self._lb = "B"
        self._dot_hit = {}        # {"sel"/"cmp": QRectF} hitbox dei dot legend
        self.color_cb = None      # callback(which) impostata dalla finestra
        self.setMinimumHeight(196)
        self.setMouseTracking(True)

    def mousePressEvent(self, e):
        if self.color_cb is not None:
            for which, rect in self._dot_hit.items():
                if rect.contains(e.position()):
                    self.color_cb(which); return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e):
        on_dot = any(r.contains(e.position()) for r in self._dot_hit.values())
        self.setCursor(Qt.PointingHandCursor if on_dot else Qt.ArrowCursor)
        super().mouseMoveEvent(e)

    def set_data(self, title, unit, sa, sb, la, lb, xlabels=None):
        self._mode = "line"
        self._title = title; self._unit = unit
        self._sa = sa or []; self._sb = sb or []
        self._xlabels = xlabels
        self._la = la; self._lb = lb
        self.update()

    def set_bars(self, title, unit, groups, la, lb):
        self._mode = "bars"
        self._title = title; self._unit = unit
        self._groups = groups or []
        self._la = la; self._lb = lb
        self.update()

    def clear(self):
        self._sa = []; self._sb = []; self._xlabels = None; self._groups = []
        self.update()

    def _legend(self, p, W):
        f = p.font(); f.setBold(False); f.setPointSize(9); p.setFont(f)
        x = W - 12
        self._dot_hit = {}
        for which, label, col in (("cmp", self._lb, QColor(_cmp_col(getattr(self, "_cmp_gold", False)))),
                                  ("sel", self._la, QColor(_sel_col()))):
            tw = p.fontMetrics().horizontalAdvance(label)
            p.setPen(QColor("#dcdddf")); p.drawText(x - tw, 18, label)
            p.setBrush(col); p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(x - tw - 10, 14), 5, 5)
            self._dot_hit[which] = QRectF(x - tw - 18, 4, tw + 24, 20)  # dot+label cliccabile
            x -= tw + 26

    def _paint_bars(self, p, W, H):
        groups = [(l, a, b) for (l, a, b) in self._groups if a is not None or b is not None]
        if not groups:
            p.setPen(QColor("#60636c"))
            p.drawText(self.rect(), Qt.AlignCenter, "select a row")
            return
        ml, mr, mt, mb = 50, 14, 34, 28
        gw, gh = W - ml - mr, H - mt - mb
        allv = [v for _, a, b in groups for v in (a, b) if v is not None]
        vmax = max(allv + [0.0]); vmin = min(allv + [0.0])
        if vmax == vmin:
            vmax = vmin + 1.0
        pad = (vmax - vmin) * 0.12
        vmax += pad
        if vmin < 0:
            vmin -= pad

        def Y(v):
            return mt + gh * (1 - (v - vmin) / (vmax - vmin))

        f = p.font(); f.setBold(False); f.setPointSize(8); p.setFont(f)
        for i in range(5):
            yy = int(mt + gh * i / 4)
            p.setPen(QPen(QColor("#24252a"), 1)); p.drawLine(ml, yy, W - mr, yy)
            val = vmax - (vmax - vmin) * i / 4
            p.setPen(QColor("#7e828c")); p.drawText(6, yy + 4, f"{val:.0f}")
        p.setPen(QColor("#7e828c")); p.drawText(6, mt - 8, self._unit)
        n = len(groups)
        slot = gw / n
        barw = min(34.0, slot * 0.32)
        for i, (lab, a, b) in enumerate(groups):
            cx = ml + slot * (i + 0.5)
            for j, (val, col) in enumerate(((a, QColor(_sel_col())), (b, QColor(_cmp_col(getattr(self, "_cmp_gold", False)))))):
                if val is None:
                    continue
                bx = cx + (j - 1) * (barw + 3) + 1.5
                top = Y(max(val, 0.0)); bot = Y(min(val, 0.0))
                p.setBrush(col); p.setPen(Qt.NoPen)
                p.drawRect(QRectF(bx, top, barw, max(1.0, bot - top)))
                p.setPen(QColor("#dcdddf"))
                txt = f"{val:.0f}" if abs(val) >= 10 else f"{val:.1f}"
                tw = p.fontMetrics().horizontalAdvance(txt)
                p.drawText(QPointF(bx + barw / 2 - tw / 2, top - 4), txt)
                p.setPen(Qt.NoPen)
            p.setPen(QColor("#989ba2"))
            tw = p.fontMetrics().horizontalAdvance(lab)
            p.drawText(QPointF(cx - tw / 2, H - 9), lab)

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#0d0e0f"))
        W, H = self.width(), self.height()
        f = p.font(); f.setBold(True); f.setPointSize(10); p.setFont(f)
        p.setPen(QColor("#f2f2f3")); p.drawText(12, 18, self._title)
        self._legend(p, W)
        if self._mode == "bars":
            self._paint_bars(p, W, H); p.end(); return
        pts = self._sa + self._sb
        if not pts:
            p.setPen(QColor("#60636c"))
            p.drawText(self.rect(), Qt.AlignCenter, "select a row")
            p.end(); return
        points_mode = self._xlabels is not None
        xmin = min(x for x, _ in pts); xmax = max(x for x, _ in pts)
        ymin = min(y for _, y in pts); ymax = max(y for _, y in pts)
        if xmax <= xmin:
            xmin -= 0.5; xmax += 0.5
        if ymax <= ymin:
            ymax = ymin + 1.0
        pad = (ymax - ymin) * 0.15
        ymax += pad; ymin -= pad
        ml, mr, mt = 50, 14, 34
        mb = 30 if points_mode else 20
        gw, gh = W - ml - mr, H - mt - mb

        def X(x):
            return ml + gw * (x - xmin) / (xmax - xmin)

        def Y(y):
            return mt + gh * (1 - (y - ymin) / (ymax - ymin))

        f.setBold(False); f.setPointSize(8); p.setFont(f)
        for i in range(5):
            yy = int(mt + gh * i / 4)
            p.setPen(QPen(QColor("#24252a"), 1)); p.drawLine(ml, yy, W - mr, yy)
            val = ymax - (ymax - ymin) * i / 4
            p.setPen(QColor("#7e828c")); p.drawText(6, yy + 4, f"{val:.0f}")
        p.setPen(QColor("#7e828c")); p.drawText(6, mt - 8, self._unit)
        if ymin < 0 < ymax:
            y0 = int(Y(0.0))
            p.setPen(QPen(QColor("#383a40"), 1)); p.drawLine(ml, y0, W - mr, y0)

        for series, col in ((self._sa, QColor(_sel_col())), (self._sb, QColor(_cmp_col(getattr(self, "_cmp_gold", False))))):
            if not series:
                continue
            poly = QPolygonF([QPointF(X(x), Y(y)) for x, y in series])
            p.setPen(QPen(col, 2)); p.setBrush(Qt.NoBrush)
            p.drawPolyline(poly)
            if points_mode:
                p.setBrush(col); p.setPen(Qt.NoPen)
                for x, y in series:
                    p.drawEllipse(QPointF(X(x), Y(y)), 3.2, 3.2)
                    txt = f"{y:.1f}" if abs(y) >= 10 else f"{y:.2f}"
                    p.setPen(QColor("#dcdddf"))
                    p.drawText(QPointF(X(x) + 5, Y(y) - 5), txt)
                    p.setPen(Qt.NoPen)
        if points_mode:
            p.setPen(QColor("#989ba2"))
            for i, lab in enumerate(self._xlabels):
                tw = p.fontMetrics().horizontalAdvance(lab)
                p.drawText(QPointF(X(i) - tw / 2, H - 10), lab)
        p.end()


class _PedalChart(QWidget):
    """Tracce pedali (throttle verde / brake rosso) vs distanza.
    Selected pieno, Compare tratteggiato. Throttle/brake attesi in 0..1."""
    _THR = "#37d67a"
    _BRK = "#ff5b5b"

    def __init__(self, scrub_cb=None):
        super().__init__()
        self._sel = []      # [(lapdist, throttle, brake)]
        self._cmp = []
        self._sec_dist = []
        self._cursor = None     # lapdist del cursore scrub (review)
        self._la = "Selected"
        self._lb = "Compare"
        self._la_time = None; self._lb_time = None
        self._la_secs = []; self._lb_secs = []
        self._best_time = None; self._best_secs = []
        self._scrub_cb = scrub_cb
        self._xmap = None       # (ml, gw, xmin, xmax) per invertire il mouse->lapdist
        self._view = None       # (vx0, vx1) finestra di zoom; None = tutto il giro
        self._pan = None        # (mouse_x, vx0, vx1) durante il pan col tasto destro
        self.setMinimumHeight(150)
        if scrub_cb is not None:
            self.setMouseTracking(True)
            self.setCursor(Qt.CrossCursor)

    def set_laps(self, sel, cmp, la="Selected", lb="Compare", sec_dist=None,
                 la_time=None, lb_time=None, la_secs=None, lb_secs=None,
                 best_time=None, best_secs=None):
        self._sel = sel or []
        self._cmp = cmp or []
        self._sec_dist = [d for d in (sec_dist or []) if d]
        self._la = la; self._lb = lb
        self._la_time = la_time; self._lb_time = lb_time
        self._la_secs = la_secs or []; self._lb_secs = lb_secs or []
        self._best_time = best_time; self._best_secs = best_secs or []
        self.update()

    def set_live(self, pts, sec_dist=None):
        """Live: una sola traccia (giro corrente)."""
        self._sel = pts or []
        self._cmp = []
        self._sec_dist = [d for d in (sec_dist or []) if d]
        self._la = "Lap"; self._lb = ""
        self.update()

    def set_cursor(self, lapdist):
        self._cursor = lapdist
        self.update()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#0d0e0f"))
        W, H = self.width(), self.height()
        ml, mr, mt, mb = 40, 14, 26, 22
        gw, gh = W - ml - mr, H - mt - mb
        f = p.font(); f.setPointSize(8); p.setFont(f)
        allpts = self._sel + self._cmp
        if len(allpts) < 2:
            p.setPen(QColor("#60636c"))
            p.drawText(self.rect(), Qt.AlignCenter, "select/record a lap")
            p.end(); return
        xs = [pt[0] for pt in allpts]
        xmin, xmax = min(xs), max(xs)
        if xmax <= xmin:
            xmax = xmin + 1.0
        self._data_x = (xmin, xmax)
        if self._view is not None:
            v0, v1 = self._view
            xmin = max(xmin, v0); xmax = min(xmax, v1)
            if xmax <= xmin:
                xmax = xmin + 1.0

        def X(v):
            return ml + gw * (v - xmin) / (xmax - xmin)

        self._xmap = (ml, gw, xmin, xmax)

        def Y(pct):
            return mt + gh * (1.0 - max(0.0, min(1.0, pct)))

        for i in range(5):
            yy = int(mt + gh * i / 4)
            p.setPen(QPen(QColor("#24252a"), 1)); p.drawLine(ml, yy, W - mr, yy)
            p.setPen(QColor("#7e828c")); p.drawText(6, yy + 4, f"{100 - i * 25}")
        p.setPen(QColor("#7e828c")); p.drawText(6, mt - 8, "%")

        # marker settori (come nello Speed) + etichette S1/S2/S3
        for d in self._sec_dist:
            if xmin <= d <= xmax:
                xx = int(X(d))
                p.setPen(QPen(QColor("#3a3d43"), 1, Qt.DashLine))
                p.drawLine(xx, mt, xx, mt + gh)
        bounds = [xmin] + list(self._sec_dist) + [xmax]
        p.setPen(QColor("#6d717b"))
        for i, lab in enumerate(("S1", "S2", "S3")):
            if i + 1 < len(bounds):
                cx = (bounds[i] + bounds[i + 1]) / 2.0
                if xmin <= cx <= xmax:
                    tw = p.fontMetrics().horizontalAdvance(lab)
                    p.drawText(QPointF(X(cx) - tw / 2, mt + 11), lab)
        f2 = p.font(); f2.setPointSize(7); p.setFont(f2)
        _draw_sector_times(p, X, bounds, self._la_secs, self._lb_secs, self._best_secs, xmin, xmax, mt + 22)
        p.setFont(f)

        def draw(pts, dashed):
            if len(pts) < 2:
                return
            for ch, col in ((1, self._THR), (2, self._BRK)):
                pen = QPen(QColor(col), 2)
                if dashed:
                    pen.setStyle(Qt.DashLine); pen.setWidthF(1.4)
                p.setPen(pen); p.setBrush(Qt.NoBrush)
                poly = QPolygonF([QPointF(X(pt[0]), Y(pt[ch] or 0.0)) for pt in pts])
                p.drawPolyline(poly)

        p.save(); p.setClipRect(QRectF(ml, mt, gw, gh))
        draw(self._cmp, True)
        draw(self._sel, False)
        p.restore()

        # legend giri: linea + 'Lap N' + tempo (più veloce in fuxia), in alto a sx
        cs = _best_color(self._la_time, self._best_time)
        cc = _best_color(self._lb_time, self._best_time)
        items = []
        if self._sel:
            items.append((False, self._la, _fmt(self._la_time) if self._la_time else "", cs))
        if self._cmp and self._lb:
            items.append((True, self._lb, _fmt(self._lb_time) if self._lb_time else "", cc))
        _draw_lap_legend(p, ml + 2, mt - 14, items)

        # cursore scrub (review): linea verticale + valori al punto
        if self._cursor is not None and xmin <= self._cursor <= xmax:
            xx = X(self._cursor)
            p.setPen(QPen(QColor("#f5f5f5"), 1))
            p.drawLine(int(xx), mt, int(xx), mt + gh)
            if self._sel:
                near = min(self._sel, key=lambda pt: abs(pt[0] - self._cursor))
                thr = (near[1] or 0.0) * 100; brk = (near[2] or 0.0) * 100
                p.setPen(QColor(self._THR)); p.drawText(QPointF(xx + 4, mt + 12), f"T {thr:.0f}%")
                p.setPen(QColor(self._BRK)); p.drawText(QPointF(xx + 4, mt + 26), f"B {brk:.0f}%")

        # legenda
        items = [("Brake", self._BRK), ("Throttle", self._THR)]
        x = W - 14
        for label, col in reversed(items):
            tw = p.fontMetrics().horizontalAdvance(label)
            p.setPen(QColor("#dcdddf")); p.drawText(x - tw, 16, label)
            p.setBrush(QColor(col)); p.setPen(Qt.NoPen)
            p.drawEllipse(QPointF(x - tw - 9, 12), 4, 4)
            x -= tw + 24
        p.end()

    # ── scrub sul grafico (review): muovi il cursore qui, la mappa segue ──
    def _ld_at(self, mx):
        if not self._xmap:
            return None
        ml, gw, xmin, xmax = self._xmap
        if gw <= 0:
            return None
        frac = max(0.0, min(1.0, (mx - ml) / gw))
        return xmin + frac * (xmax - xmin)

    def _do_scrub(self, pos):
        if self._scrub_cb is None:
            return
        ld = self._ld_at(pos.x())
        if ld is None:
            return
        self.set_cursor(ld)
        self._scrub_cb(ld)

    def wheelEvent(self, e):
        if self._scrub_cb is None or not getattr(self, "_data_x", None):
            return
        dmin, dmax = self._data_x
        v0, v1 = self._view if self._view else (dmin, dmax)
        span = v1 - v0
        if span <= 0:
            return
        ld = self._ld_at(e.position().x())
        if ld is None:
            ld = (v0 + v1) / 2.0
        factor = 0.82 if e.angleDelta().y() > 0 else 1.0 / 0.82
        nspan = max((dmax - dmin) * 0.04, min(dmax - dmin, span * factor))
        frac = (ld - v0) / span
        n0 = ld - frac * nspan
        n1 = n0 + nspan
        if n0 < dmin: n0 = dmin; n1 = n0 + nspan
        if n1 > dmax: n1 = dmax; n0 = n1 - nspan
        self._view = None if nspan >= (dmax - dmin) - 1e-6 else (max(dmin, n0), min(dmax, n1))
        self.update()

    def mouseMoveEvent(self, e):
        if self._pan is not None:
            mx0, v0, v1 = self._pan
            ml, gw, _, _ = self._xmap or (40, max(1, self.width() - 54), 0, 1)
            dmin, dmax = self._data_x
            span = v1 - v0
            dx = (e.position().x() - mx0) / max(1, gw) * span
            n0 = v0 - dx; n1 = v1 - dx
            if n0 < dmin: n0 = dmin; n1 = n0 + span
            if n1 > dmax: n1 = dmax; n0 = n1 - span
            self._view = (n0, n1)
            self.update()
        else:
            self._do_scrub(e.position())
        super().mouseMoveEvent(e)

    def mousePressEvent(self, e):
        if e.button() == Qt.RightButton and self._view is not None:
            self._pan = (e.position().x(), self._view[0], self._view[1])
        else:
            self._do_scrub(e.position())
        super().mousePressEvent(e)

    def mouseReleaseEvent(self, e):
        self._pan = None
        super().mouseReleaseEvent(e)

    def mouseDoubleClickEvent(self, e):
        self._view = None
        self.update()
        super().mouseDoubleClickEvent(e)


class _FitTable(QTableWidget):
    """Tabella che chiede esattamente l'altezza del suo contenuto: niente scroll,
    così il grafico sotto resta sempre completamente visibile."""
    def _content_h(self):
        h = self.horizontalHeader().height() + self.frameWidth() * 2 + 2
        for r in range(self.rowCount()):
            h += self.rowHeight(r)
        return h

    def sizeHint(self):
        return QSize(super().sizeHint().width(), self._content_h())

    def minimumSizeHint(self):
        return QSize(super().minimumSizeHint().width(), self._content_h())


def _load_track_svg(track):
    """Carica gli STESSI SVG del widget mappa (settings/trackmap): coordinate reali
    mPos (z negata) + indici settore in <desc>. -> (path[(x,z)], secs)."""
    import re
    from pathlib import Path
    if not track:
        return None, []
    base = Path(__file__).resolve().parent.parent / "settings" / "trackmap"
    if not base.exists():
        return None, []
    f = None
    for sv in base.glob("*.svg"):
        name = re.sub(r"#U([0-9a-fA-F]{4})", lambda m: chr(int(m.group(1), 16)), sv.stem)
        if name == track:
            f = sv; break
    if f is None:
        return None, []
    try:
        txt = f.read_text(encoding="utf-8", errors="ignore")
        m = re.search(r'points="([^"]+)"', txt)
        if not m:
            return None, []
        path = []
        for tok in m.group(1).split():
            if "," in tok:
                a, b = tok.split(",")[:2]
                path.append((float(a), -float(b)))   # z invertita come TinyPedal
        secs = []
        dm = re.search(r"<desc>([\d,\s]+)</desc>", txt)
        if dm:
            secs = [int(x) for x in re.findall(r"\d+", dm.group(1))][:2]
        return (path if len(path) > 10 else None), secs
    except Exception:
        return None, []


class _LiveMap(QWidget):
    """Mini-mappa col tracciato SVG vero (settings/trackmap). Marker posizione
    (live) o scrub (review): muovendo il mouse evidenzia il punto -> scrub_cb(lapdist)."""
    def __init__(self, scrub_cb=None):
        super().__init__()
        self._outline = []      # [(x, z)] tracciato disegnato (SVG preferito)
        self._secs = []         # indici confine settore in _outline
        self._scrub_pts = []    # [(x, z, lapdist)] campioni registrati (review)
        self._marker = None     # (x, z) posizione live
        self._hi = None         # punto evidenziato (scrub)
        self._scrub_cb = scrub_cb
        self._track = ""
        self._drv_col = None     # QColor anello classe del pilota
        self._drv_num = ""       # numero mostrato nel dot
        # ── review/confronto ──
        self._review = False
        self._cmp_pts = []       # [(x,z,lapdist)] traiettoria giro Compare
        self._cur_ld = None      # lapdist corrente dello scrub
        self._la = "Selected"
        self._lb = "Compare"
        self._cmp_gold = False   # Compare = REF -> dot/traiettoria oro
        self._dot_hit = {}       # {"sel"/"cmp": QRectF} legend cliccabile
        self.color_cb = None     # callback(which) per il pick-color
        self._gps = True         # vista GPS (centrata+ruotata) come il widget
        self._zoom_mult = 1.0    # zoom rotella
        self.setMinimumHeight(150)
        self.setMinimumWidth(120)
        if scrub_cb is not None:
            self.setMouseTracking(True)
            self.setCursor(Qt.CrossCursor)

    def _zoom_step(self, factor):
        self._zoom_mult = max(0.5, min(12.0, self._zoom_mult * factor))
        self.update()

    def set_svg(self, track):
        """Carica l'outline SVG vero per la pista (se disponibile)."""
        track = track or ""
        if track == self._track:
            return
        self._track = track
        path, secs = _load_track_svg(track)
        if path and len(path) > 10:
            self._outline = list(path)
            self._secs = list(secs)
        else:
            self._outline = []   # niente SVG: si usa il path registrato
            self._secs = []
        self.update()

    def set_scrub_pts(self, pts):
        self._scrub_pts = pts or []
        self._hi = None
        self.update()

    def set_path(self, pts):
        """Fallback outline da posizioni registrate/accumulate (se manca lo SVG)."""
        if not self._outline:
            self._fallback = pts or []
        else:
            self._fallback = []
        self.update()

    def set_marker(self, xz):
        self._marker = xz
        self.update()

    def set_driver(self, cls_tag, num):
        """Colore classe + numero del pilota per disegnare il dot stile widget."""
        self._drv_col = QColor(_CLASS_COL.get(cls_tag or "", "#a7aaaf"))
        self._drv_num = str(num or "")
        self.update()

    def set_review(self, sel_pts, cmp_pts, la="Selected", lb="Compare"):
        """Modalità confronto: due traiettorie + due dot (colori _SEL_COL/_CMP_COL)."""
        self._review = True
        self._scrub_pts = sel_pts or []
        self._cmp_pts = cmp_pts or []
        self._la = la; self._lb = lb
        self._hi = None
        self.setMouseTracking(True)
        self.update()

    def set_hi_by_lapdist(self, ld):
        """Evidenzia il campione più vicino a una lapdist (entrambe le tracce)."""
        self._cur_ld = ld
        self._hi = self._nearest_ld(self._scrub_pts, ld)
        self.update()

    @staticmethod
    def _nearest_ld(pts, ld):
        if ld is None or not pts:
            return None
        best = None; bd = 1e18
        for i, pt in enumerate(pts):
            if len(pt) > 2 and pt[2] is not None:
                dd = abs(pt[2] - ld)
                if dd < bd:
                    bd = dd; best = i
        return best

    def _draw_pts(self):
        if self._outline:
            return self._outline
        if getattr(self, "_fallback", None):
            return [(p[0], p[1]) for p in self._fallback]
        if self._scrub_pts:
            return [(p[0], p[1]) for p in self._scrub_pts]
        return []

    def _xform(self, pts):
        if len(pts) < 2:
            return None
        xs = [p[0] for p in pts]; zs = [p[1] for p in pts]
        xmin, xmax = min(xs), max(xs); zmin, zmax = min(zs), max(zs)
        sx = (xmax - xmin) or 1.0; sz = (zmax - zmin) or 1.0
        w, h = self.width(), self.height()
        m = 14
        scale = min((w - 2 * m) / sx, (h - 2 * m) / sz)
        ox = (w - sx * scale) / 2 - xmin * scale
        oz = (h - sz * scale) / 2 - zmin * scale
        return ox, oz, scale, h

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#0d0e0f"))
        if self._review:
            self._paint_review(p)
        else:
            self._paint_live(p)
        p.end()

    # ── confronto (review): due traiettorie + due dot, vista GPS ──────────
    def _paint_review(self, p):
        sel = self._scrub_pts
        cmp = self._cmp_pts
        if len(sel) < 2:
            p.setPen(QColor("#60636c"))
            p.drawText(self.rect(), Qt.AlignCenter, "map\nwaiting")
            return
        hi_sel = self._hi if self._hi is not None else self._nearest_ld(sel, self._cur_ld)
        hi_cmp = self._nearest_ld(cmp, self._cur_ld) if cmp else None

        w, h = self.width(), self.height()
        allp = [(q[0], q[1]) for q in sel] + [(q[0], q[1]) for q in cmp]
        xs = [q[0] for q in allp]; zs = [q[1] for q in allp]
        sx = (max(xs) - min(xs)) or 1.0; sz = (max(zs) - min(zs)) or 1.0
        fit = min((w - 28) / sx, (h - 28) / sz)

        if self._gps:
            fi = hi_sel if hi_sel is not None else 0
            fx, fz = sel[fi][0], sel[fi][1]
            k = max(2, len(sel) // 80)
            a0 = sel[max(0, fi - k)]; a1 = sel[min(len(sel) - 1, fi + k)]
            ang = math.atan2(a1[1] - a0[1], a1[0] - a0[0])
            zoom = fit * 6.0 * self._zoom_mult
            ca = math.cos(-ang + math.pi / 2.0); sa = math.sin(-ang + math.pi / 2.0)
            cx, cy = w / 2.0, h * 0.62

            def P(x, z):
                u = (x - fx); v = (z - fz)
                ru = u * ca - v * sa; rv = u * sa + v * ca
                return QPointF(cx + ru * zoom, cy - rv * zoom)
        else:
            z = fit * self._zoom_mult
            cxm = (min(xs) + max(xs)) / 2.0
            czm = (min(zs) + max(zs)) / 2.0
            cx, cy = w / 2.0, h / 2.0

            def P(x, z2=None, _z=z, _cx=cx, _cy=cy, _cxm=cxm, _czm=czm):
                return QPointF(_cx + (x - _cxm) * _z, _cy - (z2 - _czm) * _z)

        def line(pts, col, width):
            if len(pts) < 2:
                return
            path = QPainterPath(); path.moveTo(P(pts[0][0], pts[0][1]))
            for q in pts[1:]:
                path.lineTo(P(q[0], q[1]))
            p.setBrush(Qt.NoBrush)
            p.setPen(QPen(col, width)); p.drawPath(path)

        sel_c = QColor(_sel_col()); cmp_c = QColor(_cmp_col(self._cmp_gold)); trk_c = QColor(_TRK_COL)
        zm = self._zoom_mult
        trk_w = max(8.0, min(200.0, 17.0 * zm))
        ln_w = max(1.4, min(16.0, 2.2 * zm))
        dot_r = max(4.5, min(30.0, 6.0 * zm))

        # pista larga (colore scuro pickabile) usando il giro Selected come tracciato
        # decima i punti SOLO per il disegno (cursore/dot usano i punti pieni)
        def _decim(pts, maxn=1500):
            n = len(pts)
            if n <= maxn:
                return pts
            st = n // maxn
            d = pts[::st]
            if d[-1] is not pts[-1]:
                d = d + [pts[-1]]
            return d
        sel_draw = _decim(sel)
        cmp_draw = _decim(cmp) if cmp else cmp

        base = QPainterPath(); base.moveTo(P(sel_draw[0][0], sel_draw[0][1]))
        for q in sel_draw[1:]:
            base.lineTo(P(q[0], q[1]))
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(0, 0, 0, 180), trk_w + 5)); p.drawPath(base)   # bordo
        p.setPen(QPen(trk_c, trk_w)); p.drawPath(base)                      # asfalto

        # traiettorie: linee colorate sopra la pista
        if cmp:
            line(cmp_draw, cmp_c, ln_w)
        line(sel_draw, sel_c, ln_w)

        def dot(pt, col):
            c = P(pt[0], pt[1])
            p.setPen(QPen(QColor("#09090b"), 1.4)); p.setBrush(col)
            p.drawEllipse(c, dot_r, dot_r)

        if hi_cmp is not None and 0 <= hi_cmp < len(cmp):
            dot(cmp[hi_cmp], cmp_c)
        if hi_sel is not None and 0 <= hi_sel < len(sel):
            dot(sel[hi_sel], sel_c)

        # legend cliccabile in alto a SINISTRA (pick-color).
        # anello tratteggiato = linea tratteggiata nel grafico (Compare),
        # anello continuo = linea piena (Selected); Track = dot pieno.
        self._dot_hit = {}
        f = p.font(); f.setBold(False); f.setPointSize(8); p.setFont(f)
        x = 12
        items = [("sel", self._la, sel_c)]
        if cmp:
            items.append(("cmp", self._lb, cmp_c))
        items.append(("track", "Track", trk_c))
        for which, label, col in items:
            cxp, cyp = x + 6, 12
            p.setPen(QPen(QColor("#09090b"), 1)); p.setBrush(col)
            p.drawEllipse(QPointF(cxp, cyp), 5.5, 5.5)
            tw = p.fontMetrics().horizontalAdvance(label)
            p.setPen(QColor("#09090b")); p.drawText(QPointF(x + 15, 17), label)
            p.setPen(QColor("#f5f5f5")); p.drawText(QPointF(x + 14, 16), label)
            self._dot_hit[which] = QRectF(x - 2, 2, tw + 22, 20)
            x += tw + 30

    def _paint_live(self, p):
        pts = self._draw_pts()
        tf = self._xform(pts)
        if tf is None:
            p.setPen(QColor("#60636c"))
            p.drawText(self.rect(), Qt.AlignCenter, "map\nwaiting")
            return
        ox, oz, scale, h = tf

        def P(x, z):
            return QPointF(ox + x * scale, h - (oz + z * scale))

        # ── tracciato stile widget: alone nero + linea chiara, path chiuso ──
        path = QPainterPath()
        path.moveTo(P(*pts[0]))
        for x, z in pts[1:]:
            path.lineTo(P(x, z))
        path.closeSubpath()
        lw = 5.5
        p.setBrush(Qt.NoBrush)
        p.setPen(QPen(QColor(0, 0, 0, 150), lw + 3.5)); p.drawPath(path)   # alone nero
        p.setPen(QPen(QColor("#f3f4f8"), lw)); p.drawPath(path)            # pista chiara

        # tacche settore (blu) + traguardo (rosso), come nel widget
        def _tick(i, color, length, width):
            n = len(pts)
            if n < 3:
                return
            i = max(1, min(i, n - 2))
            A = P(*pts[i - 1]); B = P(*pts[i + 1])
            dx, dy = B.x() - A.x(), B.y() - A.y()
            ln = (dx * dx + dy * dy) ** 0.5 or 1.0
            nx, ny = -dy / ln, dx / ln
            C = P(*pts[i]); half = length / 2.0
            p.setPen(QPen(color, width))
            p.drawLine(QPointF(C.x() - nx * half, C.y() - ny * half),
                       QPointF(C.x() + nx * half, C.y() + ny * half))

        if self._outline and len(self._secs) >= 2:
            for si in self._secs[:2]:
                _tick(si, QColor("#00aaff"), 11, 2.2)
        _tick(0, QColor("#ff3b30"), 13, 2.6)

        # ── dot pilota: bianco con anello classe (pulito) ──
        dot = None
        if self._hi is not None and 0 <= self._hi < len(self._scrub_pts):
            dot = P(self._scrub_pts[self._hi][0], self._scrub_pts[self._hi][1])
        elif self._marker is not None:
            dot = P(self._marker[0], self._marker[1])
        if dot is not None:
            fill = QColor(_sel_col()) if _SEL_IS_BEST else (self._drv_col or QColor(_SEL_COL))
            rr = 6.5
            p.setPen(Qt.NoPen); p.setBrush(QColor(0, 0, 0, 110))
            p.drawEllipse(QPointF(dot.x() + 1.2, dot.y() + 1.2), rr + 1.4, rr + 1.4)
            p.setPen(QPen(QColor("#ffffff"), 2.0)); p.setBrush(fill)
            p.drawEllipse(dot, rr, rr)

    def _nearest(self, pos):
        pts = self._scrub_pts
        if len(pts) < 2:
            return None
        tf = self._xform(self._draw_pts())
        if tf is None:
            return None
        ox, oz, scale, h = tf
        mx, my = pos.x(), pos.y()
        best = None; bd = 1e18
        for i, pt in enumerate(pts):
            sxp = ox + pt[0] * scale
            syp = h - (oz + pt[1] * scale)
            dd = (sxp - mx) ** 2 + (syp - my) ** 2
            if dd < bd:
                bd = dd; best = i
        return best

    def _scrub(self, pos):
        if self._scrub_cb is None:
            return
        i = self._nearest(pos)
        if i is None:
            return
        self._hi = i
        self.update()
        ld = self._scrub_pts[i][2] if len(self._scrub_pts[i]) > 2 else None
        self._scrub_cb(ld)

    def wheelEvent(self, e):
        if not self._review:
            return
        self._zoom_mult *= 1.25 if e.angleDelta().y() > 0 else 1.0 / 1.25
        self._zoom_mult = max(0.5, min(12.0, self._zoom_mult))
        self.update()
        e.accept()

    def mouseMoveEvent(self, e):
        if self._review and self.color_cb is not None:
            on = any(r.contains(e.position()) for r in self._dot_hit.values())
            self.setCursor(Qt.PointingHandCursor if on else Qt.ArrowCursor)
        self._scrub(e.position()); super().mouseMoveEvent(e)

    def mousePressEvent(self, e):
        if self._review and self.color_cb is not None:
            for which, rect in self._dot_hit.items():
                if rect.contains(e.position()):
                    self.color_cb(which); return
        self._scrub(e.position()); super().mousePressEvent(e)


class _TraceChart(QWidget):
    """Traccia di una singola metrica vs distanza giro. Selected pieno,
    Compare tratteggiato. Scrub (cursore), zoom rotella, pan tasto destro,
    doppio click reset. Legend cliccabile -> pick-color."""
    def __init__(self, scrub_cb=None):
        super().__init__()
        self._sel = []      # [(lapdist, val)]
        self._cmp = []
        self._sec_dist = []
        self._cursor = None
        self._cur_a = None; self._cur_b = None   # cursori A/B (shift-click)
        self._ab_cb = None                        # callback per sincronizzare A/B (1b)
        self._zoom_cb = None                      # callback per sincronizzare lo zoom (1b)
        self._cmp_gold = False                    # Compare = REF -> linea/legenda oro
        self._la = "Selected"; self._lb = "Compare"
        self._unit = ""
        self._la_time = None; self._lb_time = None
        self._la_secs = []; self._lb_secs = []
        self._best_time = None; self._best_secs = []
        self._scrub_cb = scrub_cb
        self._xmap = None
        self.baseline = None          # se valorizzata, disegna una linea di riferimento (es. 0)
        self.yfmt = "{:.0f}"          # formato etichette asse Y (Delta usa secondi)
        self._view = None
        self._pan = None
        self._data_x = None
        self._dot_hit = {}
        self.color_cb = None
        self.setMinimumHeight(180)
        if scrub_cb is not None:
            self.setMouseTracking(True)
            self.setCursor(Qt.CrossCursor)

    def set_laps(self, sel, cmp, la, lb, unit, sec_dist=None,
                 la_time=None, lb_time=None, la_secs=None, lb_secs=None,
                 best_time=None, best_secs=None):
        self._sel = sel or []; self._cmp = cmp or []
        self._la = la; self._lb = lb; self._unit = unit
        self._sec_dist = [d for d in (sec_dist or []) if d]
        self._la_time = la_time; self._lb_time = lb_time
        self._la_secs = la_secs or []; self._lb_secs = lb_secs or []
        self._best_time = best_time; self._best_secs = best_secs or []
        self.update()

    def set_cursor(self, ld):
        self._cursor = ld; self.update()

    def set_ab(self, a, b):
        self._cur_a = a; self._cur_b = b; self.update()

    def set_view(self, view):
        """Imposta la finestra di zoom SENZA richiamare il callback (anti-echo)."""
        self._view = view; self.update()

    def clear_ab(self):
        self._cur_a = None; self._cur_b = None; self.update()

    @staticmethod
    def _val_at(series, ld):
        if not series or ld is None:
            return None
        return min(series, key=lambda q: abs(q[0] - ld))[1]

    def _ld_at(self, mx):
        if not self._xmap:
            return None
        ml, gw, xmin, xmax = self._xmap
        if gw <= 0:
            return None
        frac = max(0.0, min(1.0, (mx - ml) / gw))
        return xmin + frac * (xmax - xmin)

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#0d0e0f"))
        W, H = self.width(), self.height()
        ml, mr, mt, mb = 46, 14, 28, 22
        gw, gh = W - ml - mr, H - mt - mb
        f = p.font(); f.setPointSize(8); p.setFont(f)
        allp = self._sel + self._cmp
        if len(allp) < 2:
            p.setPen(QColor("#60636c"))
            p.drawText(self.rect(), Qt.AlignCenter, "select a lap")
            p.end(); return
        xs = [q[0] for q in allp]
        xmin, xmax = min(xs), max(xs)
        if xmax <= xmin:
            xmax = xmin + 1.0
        self._data_x = (xmin, xmax)
        if self._view:
            v0, v1 = self._view
            xmin = max(xmin, v0); xmax = min(xmax, v1)
            if xmax <= xmin:
                xmax = xmin + 1.0
        ys = [q[1] for q in allp if q[1] is not None]
        if not ys:
            ys = [0.0, 1.0]
        ymin, ymax = min(ys), max(ys)
        if ymax <= ymin:
            ymax = ymin + 1.0
        pad = (ymax - ymin) * 0.08; ymin -= pad; ymax += pad

        def X(v):
            return ml + gw * (v - xmin) / (xmax - xmin)

        def Y(v):
            return mt + gh * (1.0 - (v - ymin) / (ymax - ymin))

        self._xmap = (ml, gw, xmin, xmax)
        for i in range(5):
            yy = mt + gh * i / 4
            p.setPen(QPen(QColor("#24252a"), 1)); p.drawLine(ml, int(yy), W - mr, int(yy))
            val = ymax - (ymax - ymin) * i / 4
            p.setPen(QColor("#7e828c")); p.drawText(4, int(yy) + 4, self.yfmt.format(val))
        if self.baseline is not None and ymin <= self.baseline <= ymax:
            yb = Y(self.baseline)
            p.setPen(QPen(QColor("#60636c"), 1, Qt.DashLine))
            p.drawLine(ml, int(yb), W - mr, int(yb))
        p.setPen(QColor("#7e828c")); p.drawText(4, mt - 8, self._unit)
        for d in self._sec_dist:
            if xmin <= d <= xmax:
                xx = int(X(d))
                p.setPen(QPen(QColor("#3a3d43"), 1, Qt.DashLine)); p.drawLine(xx, mt, xx, mt + gh)
        bounds = [xmin] + list(self._sec_dist) + [xmax]
        p.setPen(QColor("#6d717b"))
        for i, lab in enumerate(("S1", "S2", "S3")):
            if i + 1 < len(bounds):
                cx = (bounds[i] + bounds[i + 1]) / 2.0
                if xmin <= cx <= xmax:
                    tw = p.fontMetrics().horizontalAdvance(lab)
                    p.drawText(QPointF(X(cx) - tw / 2, mt + 11), lab)
        f2 = p.font(); f2.setPointSize(7); p.setFont(f2)
        _draw_sector_times(p, X, bounds, self._la_secs, self._lb_secs, self._best_secs, xmin, xmax, mt + 22)
        p.setFont(f)

        p.save(); p.setClipRect(QRectF(ml, mt, gw, gh))

        def draw(pts, col, dashed):
            if len(pts) < 2:
                return
            pen = QPen(QColor(col), 2)
            if dashed:
                pen.setStyle(Qt.DashLine); pen.setWidthF(1.6)
            p.setPen(pen); p.setBrush(Qt.NoBrush)
            p.drawPolyline(QPolygonF([QPointF(X(x), Y(v)) for x, v in pts if v is not None]))

        if self.baseline is not None and len([1 for _, v in self._sel if v is not None]) >= 2:
            base = self.baseline; yb = Y(base)
            red = QLinearGradient(0, mt, 0, yb)           # rosso: intenso in alto, sfuma allo zero
            red.setColorAt(0.0, QColor(255, 76, 76, 135))
            red.setColorAt(1.0, QColor(255, 76, 76, 18))
            grn = QLinearGradient(0, yb, 0, mt + gh)       # verde: sfuma dallo zero, intenso in basso
            grn.setColorAt(0.0, QColor(40, 224, 120, 18))
            grn.setColorAt(1.0, QColor(40, 224, 120, 135))
            pts = [(x, v) for x, v in self._sel if v is not None]
            p.setPen(Qt.NoPen)
            for i in range(len(pts) - 1):
                x0, v0 = pts[i]; x1, v1 = pts[i + 1]
                if (v0 - base) * (v1 - base) < 0:        # attraversa lo zero: spezza
                    t = (base - v0) / (v1 - v0)
                    xc = x0 + t * (x1 - x0)
                    segs = [(x0, v0, xc, base), (xc, base, x1, v1)]
                else:
                    segs = [(x0, v0, x1, v1)]
                for sx0, sv0, sx1, sv1 in segs:
                    p.setBrush(red if (sv0 + sv1) * 0.5 > base else grn)
                    p.drawPolygon(QPolygonF([
                        QPointF(X(sx0), Y(sv0)), QPointF(X(sx1), Y(sv1)),
                        QPointF(X(sx1), yb), QPointF(X(sx0), yb)]))

        _cmpc = _cmp_col(self._cmp_gold)
        draw(self._cmp, _cmpc, True)
        draw(self._sel, _sel_col(), False)
        p.restore()

        if self._cursor is not None and xmin <= self._cursor <= xmax:
            xx = X(self._cursor)
            p.setPen(QPen(QColor("#f5f5f5"), 1)); p.drawLine(int(xx), mt, int(xx), mt + gh)
            yv = mt + 12
            if self._sel:
                ns = min(self._sel, key=lambda q: abs(q[0] - self._cursor))
                p.setPen(QColor(_sel_col())); p.drawText(QPointF(xx + 4, yv), f"{ns[1]:.1f}"); yv += 14
            if self._cmp:
                nc = min(self._cmp, key=lambda q: abs(q[0] - self._cursor))
                p.setPen(QColor(_cmpc)); p.drawText(QPointF(xx + 4, yv), f"{nc[1]:.1f}")

        # cursori A/B (shift-click): linee + readout del delta tra A e B
        def _ab_line(ld, col, tag):
            if ld is None or not (xmin <= ld <= xmax):
                return
            xx2 = X(ld)
            p.setPen(QPen(QColor(col), 1, Qt.DashLine))
            p.drawLine(int(xx2), mt, int(xx2), mt + gh)
            p.setPen(QColor(col)); p.drawText(QPointF(xx2 + 3, mt + gh - 5), tag)
        _ab_line(self._cur_a, "#f0a23a", "A")
        _ab_line(self._cur_b, "#36c5d0", "B")
        if self._cur_a is not None and self._cur_b is not None:
            va = self._val_at(self._sel, self._cur_a)
            vb = self._val_at(self._sel, self._cur_b)
            txt = f"\u0394X {self._cur_b - self._cur_a:+.0f} m"
            if va is not None and vb is not None:
                u = (" " + self._unit) if self._unit else ""
                txt += f"   \u0394{u.strip()} {vb - va:+.2f}"
            p.setPen(QColor("#f5f5f5"))
            tw = p.fontMetrics().horizontalAdvance(txt)
            p.drawText(QPointF(W - mr - tw, mt - 8), txt)
        elif self._cur_a is None and self._cur_b is None:
            p.setPen(QColor("#60636c"))
            p.drawText(QPointF(ml + 2, mt + gh + 16), "shift-click: A/B")

        # legend cliccabile (pick-color) + tempo giro (più veloce in fuxia)
        self._dot_hit = {}
        x = ml + 2
        cs = _best_color(self._la_time, self._best_time)
        cc = _best_color(self._lb_time, self._best_time)
        items = [("sel", self._la, QColor(_sel_col()), False,
                  _fmt(self._la_time) if self._la_time else "", cs)]
        if self._cmp:
            items.append(("cmp", self._lb, QColor(_cmpc), True,
                          _fmt(self._lb_time) if self._lb_time else "", cc))
        for which, label, col, dashed, tstr, tcol in items:
            pen = QPen(col, 2)
            if dashed:
                pen.setStyle(Qt.DashLine)
            p.setPen(pen); p.drawLine(int(x), 12, int(x) + 16, 12)
            xx = x + 21
            p.setPen(QColor("#dcdddf")); p.drawText(QPointF(xx, 16), label)
            xx += p.fontMetrics().horizontalAdvance(label) + 7
            if tstr:
                p.setPen(QColor(tcol)); p.drawText(QPointF(xx, 16), tstr)
                xx += p.fontMetrics().horizontalAdvance(tstr)
            self._dot_hit[which] = QRectF(x - 2, 2, (xx - x) + 6, 18)
            x = xx + 22
        p.end()

    def wheelEvent(self, e):
        if self._scrub_cb is None or not self._data_x:
            return
        dmin, dmax = self._data_x
        v0, v1 = self._view if self._view else (dmin, dmax)
        span = v1 - v0
        if span <= 0:
            return
        ld = self._ld_at(e.position().x())
        if ld is None:
            ld = (v0 + v1) / 2.0
        factor = 0.82 if e.angleDelta().y() > 0 else 1.0 / 0.82
        nspan = max((dmax - dmin) * 0.04, min(dmax - dmin, span * factor))
        frac = (ld - v0) / span
        n0 = ld - frac * nspan; n1 = n0 + nspan
        if n0 < dmin: n0 = dmin; n1 = n0 + nspan
        if n1 > dmax: n1 = dmax; n0 = n1 - nspan
        self._view = None if nspan >= (dmax - dmin) - 1e-6 else (max(dmin, n0), min(dmax, n1))
        if self._zoom_cb:
            self._zoom_cb(self._view)
        self.update()

    def _do_scrub(self, pos):
        if self._scrub_cb is None:
            return
        ld = self._ld_at(pos.x())
        if ld is None:
            return
        self.set_cursor(ld); self._scrub_cb(ld)

    def mouseMoveEvent(self, e):
        if self.color_cb is not None:
            on = any(r.contains(e.position()) for r in self._dot_hit.values())
            self.setCursor(Qt.PointingHandCursor if on else Qt.CrossCursor)
        if self._pan is not None:
            mx0, v0, v1 = self._pan
            ml, gw, _, _ = self._xmap or (46, max(1, self.width() - 60), 0, 1)
            dmin, dmax = self._data_x; span = v1 - v0
            dx = (e.position().x() - mx0) / max(1, gw) * span
            n0 = v0 - dx; n1 = v1 - dx
            if n0 < dmin: n0 = dmin; n1 = n0 + span
            if n1 > dmax: n1 = dmax; n0 = n1 - span
            self._view = (n0, n1)
            if self._zoom_cb:
                self._zoom_cb(self._view)
            self.update()
        else:
            self._do_scrub(e.position())
        super().mouseMoveEvent(e)

    def mousePressEvent(self, e):
        if self.color_cb is not None:
            for which, rect in self._dot_hit.items():
                if rect.contains(e.position()):
                    self.color_cb(which); return
        if e.button() == Qt.LeftButton and (e.modifiers() & Qt.ShiftModifier):
            ld = self._ld_at(e.position().x())
            if ld is not None:
                if self._cur_a is None:
                    self._cur_a = ld
                elif self._cur_b is None:
                    self._cur_b = ld
                else:
                    self._cur_a = ld; self._cur_b = None
                if self._ab_cb:
                    self._ab_cb(self._cur_a, self._cur_b)
                self.update()
            return
        if e.button() == Qt.RightButton and self._view is not None:
            self._pan = (e.position().x(), self._view[0], self._view[1])
        else:
            self._do_scrub(e.position())
        super().mousePressEvent(e)

    def mouseReleaseEvent(self, e):
        self._pan = None; super().mouseReleaseEvent(e)

    def mouseDoubleClickEvent(self, e):
        self._view = None
        if self._zoom_cb:
            self._zoom_cb(None)
        self.update(); super().mouseDoubleClickEvent(e)

    def recolor(self):
        self.update()


def _spd_series(con, lap):
    """[(lapdist, speed_kmh)] crescente per distanza, deduplicato."""
    if lap is None or con is None:
        return []
    try:
        rs = _rows(con, "SELECT lapdist, speed FROM samples WHERE lap=? ORDER BY t", (lap,))
    except Exception:
        return []
    xy = [(r["lapdist"], r["speed"]) for r in rs
          if r["lapdist"] is not None and r["speed"] is not None]
    xy.sort(key=lambda q: q[0])
    out = []; last = None
    for x, v in xy:
        if last is None or x > last + 1e-6:
            out.append((x, v)); last = x
    return out


def _resample(series, grid):
    """Interpola linearmente i valori di `series` (ordinata per x) sui punti `grid`."""
    out = []; j = 0; n = len(series)
    for x in grid:
        if x <= series[0][0]:
            out.append(series[0][1]); continue
        while j < n - 1 and series[j + 1][0] < x:
            j += 1
        if j >= n - 1:
            out.append(series[-1][1]); continue
        x0, v0 = series[j]; x1, v1 = series[j + 1]
        out.append(v0 if x1 <= x0 else v0 + (v1 - v0) * (x - x0) / (x1 - x0))
    return out


def _t_series(con, lap):
    """[(lapdist, t_dall_inizio_giro)] crescente per distanza, deduplicato."""
    if lap is None or con is None:
        return []
    try:
        rs = _rows(con, "SELECT lapdist, t FROM samples WHERE lap=? ORDER BY t", (lap,))
    except Exception:
        return []
    xy = [(r["lapdist"], r["t"]) for r in rs
          if r["lapdist"] is not None and r["t"] is not None]
    xy.sort(key=lambda q: q[0])
    out = []; last = None
    for x, t in xy:
        if last is None or x > last + 1e-6:
            out.append((x, t)); last = x
    return out


def _delta_series(con, sel, cmp, step=2.0, con_cmp=None):
    """Delta-T cumulato vs distanza fra Compare e Selected.
    Usa il TEMPO REALE per campione (colonna t). Se con_cmp è dato, il giro
    Compare è letto da QUEL database (reference cross-session)."""
    a = _t_series(con, sel); b = _t_series(con_cmp or con, cmp)
    if len(a) < 2 or len(b) < 2:
        return []
    d0 = max(a[0][0], b[0][0], 0.0)
    d1 = min(a[-1][0], b[-1][0])
    if d1 <= d0:
        return []
    grid = []; x = d0
    while x <= d1:
        grid.append(x); x += step
    if len(grid) < 2:
        return []
    ta = _resample(a, grid); tb = _resample(b, grid)
    a0 = ta[0]; b0 = tb[0]
    # Δ = Selected - Compare (TUO giro - REF): >0 = stai perdendo sul REF.
    return [(grid[i], (ta[i] - a0) - (tb[i] - b0)) for i in range(len(grid))]


class _DeltaTab(QWidget):
    """Delta-T vs distanza: curva singola (Compare - Selected) con linea zero,
    riusa _TraceChart per scrub/zoom/pan. La mappa mostra le due traiettorie."""
    def __init__(self, data):
        super().__init__()
        self.data = data
        self._sel = None; self._cmp = None
        self._la = "Selected"; self._lb = "Compare"
        root = QVBoxLayout(self)
        self._read = QLabel(""); self._read.setStyleSheet("color:#dcdddf;padding:4px 10px;")
        root.addWidget(self._read)
        self._info = QLabel(""); self._info.setTextFormat(Qt.RichText)
        self._info.setStyleSheet("padding:0 10px 4px 10px;font-size:13px;")
        root.addWidget(self._info)
        roww = QWidget(); rowl = QHBoxLayout(roww); rowl.setContentsMargins(0, 0, 0, 0)
        self.chart = _TraceChart(scrub_cb=self._on_scrub)
        self.chart.baseline = 0.0
        self.chart.yfmt = "{:+.2f}"
        self.map_w = _LiveMap()
        rowl.addWidget(self.chart, 2)
        rowl.addWidget(self.map_w, 1)
        root.addWidget(roww, 1)

    def _xz(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con,
                       "SELECT pos_x, pos_z, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        return [(r["pos_x"], r["pos_z"], r["lapdist"]) for r in rs
                if r["pos_x"] is not None and r["pos_z"] is not None]

    def _sec_dist(self, lap):
        if lap is None or self.data.con is None:
            return []
        L = self.data._by_id.get(lap, {})
        s1 = L.get("s1") or 0.0; s2 = L.get("s2") or 0.0
        if not s1:
            return []
        try:
            rs = _rows(self.data.con,
                       "SELECT t, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        b1 = b2 = None
        for r in rs:
            if r["t"] is None or r["lapdist"] is None:
                continue
            if b1 is None and r["t"] >= s1:
                b1 = r["lapdist"]
            if b2 is None and s2 and r["t"] >= s1 + s2:
                b2 = r["lapdist"]; break
        return [d for d in (b1, b2) if d is not None]

    def _lap_info(self, lap, con=None):
        """(lap_time, [s1, s2, s3]) per un giro. None se assente."""
        con = con or self.data.con
        if lap is None or con is None:
            return (None, [None, None, None])
        try:
            r = _rows(con, "SELECT lap_time, s1, s2, s3 FROM laps WHERE lap=?", (lap,))
        except Exception:
            return (None, [None, None, None])
        if not r:
            return (None, [None, None, None])
        return (r[0]["lap_time"], [r[0]["s1"], r[0]["s2"], r[0]["s3"]])

    def _set_info(self, sel_t, sel_s, cmp_t, cmp_s, cmp_name):
        def fmt_t(v):
            return _fmt(v) if v else "\u2014"

        def fmt_d(v):
            if v is None:
                return "<span style='color:#838790'>\u2014</span>"
            col = "#ff6b6b" if v > 0.0005 else ("#55ff7f" if v < -0.0005 else "#dcdddf")
            return "<span style='color:%s'>%+.2f</span>" % (col, v)

        ds = []
        for i in range(3):
            a = sel_s[i] if i < len(sel_s) else None
            b = cmp_s[i] if i < len(cmp_s) else None
            ds.append((a - b) if (a is not None and b is not None) else None)
        dtot = (sel_t - cmp_t) if (sel_t and cmp_t) else None
        html = (
            "<span style='color:#8fe9c0'>%s</span> <b style='color:#f5f5f5'>%s</b>"
            "&nbsp;&nbsp;\u00b7&nbsp;&nbsp;"
            "<span style='color:#c9a23a'>%s</span> <b style='color:#f5f5f5'>%s</b>"
            "&nbsp;&nbsp;&nbsp;&nbsp;"
            "S1 %s&nbsp;&nbsp; S2 %s&nbsp;&nbsp; S3 %s"
            "&nbsp;&nbsp;&nbsp;&nbsp;\u0394 %s"
            % (self._la, fmt_t(sel_t), cmp_name, fmt_t(cmp_t),
               fmt_d(ds[0]), fmt_d(ds[1]), fmt_d(ds[2]), fmt_d(dtot)))
        self._info.setText(html)

    def _refresh(self):
        self._la = f"Lap {self._sel}" if self._sel is not None else "Selected"
        self.chart.set_cursor(None)
        ref = self.data.cmp_source()
        self.map_w._cmp_gold = bool(ref)
        if ref:
            rcon, rlap, rlabel, rtime, rsecs = ref
            self._lb = rlabel
            delta = _delta_series(self.data.con, self._sel, rlap, con_cmp=rcon) \
                if self._sel is not None else []
            cmp_xz = self._xz(rlap, con=rcon)
            cmp_t = rtime; cmp_s = list(rsecs or [None, None, None])
        else:
            self._lb = f"Lap {self._cmp}" if self._cmp is not None else "Compare"
            delta = _delta_series(self.data.con, self._sel, self._cmp) \
                if (self._sel is not None and self._cmp is not None) else []
            cmp_xz = self._xz(self._cmp)
            cmp_t, cmp_s = self._lap_info(self._cmp)
        sel_t, sel_s = self._lap_info(self._sel)
        self.chart.set_laps(delta, [], "\u0394t (You \u2212 Compare)", "", "s",
                            sec_dist=self._sec_dist(self._sel))
        self.map_w.set_review(self._xz(self._sel), cmp_xz, self._la, self._lb)
        if delta:
            self._set_info(sel_t, sel_s, cmp_t, cmp_s, self._lb)
        else:
            self._info.setText("")
        self._update_read(None)

    def _update_read(self, ld):
        d = self.chart._sel
        parts = ["\u0394t  (You \u2212 Compare)   >0 = you are slower (losing)"]
        if d:
            parts.append(f"final {d[-1][1]:+.3f}s")
            if ld is not None:
                cur = min(d, key=lambda q: abs(q[0] - ld))[1]
                parts.append(f"@cursor {cur:+.3f}s")
        self._read.setText("        ".join(parts))

    def _on_scrub(self, ld):
        self.chart.set_cursor(ld)
        self.map_w.set_hi_by_lapdist(ld)
        self._update_read(ld)

    def set_lap(self, lap):
        self._sel = lap; self._refresh()

    def set_compare(self, lap):
        self._cmp = lap; self._refresh()

    def recolor(self):
        self.chart.update(); self.map_w.update()


class _WorksheetTab(QWidget):
    """Worksheet multi-canale: piu' canali impilati (Speed/Throttle/Brake/
    Steering/Gear) con asse distanza condiviso e UN cursore unico che li scorre
    tutti. Zoom e cursori A/B sincronizzati col resto via _charts del parent."""
    # (label, colonna, unita', scala, yfmt)
    _CHANS = [
        ("Speed",    "speed",    "km/h", 1.0,   "{:.0f}"),
        ("Throttle", "throttle", "%",    100.0, "{:.0f}"),
        ("Brake",    "brake",    "%",    100.0, "{:.0f}"),
        ("Steering", "steer",    "\u00b0", 1.0, "{:.0f}"),
        ("Gear",     "gear",     "",     1.0,   "{:.0f}"),
    ]

    def __init__(self, data):
        super().__init__()
        self.data = data
        self._sel = None; self._cmp = None
        self._la = "Selected"; self._lb = "Compare"
        root = QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)
        self._read = QLabel(""); self._read.setTextFormat(Qt.RichText)
        self._read.setStyleSheet("color:#dcdddf;padding:5px 10px;font-size:12px;")
        root.addWidget(self._read)
        from PySide6.QtWidgets import QScrollArea
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        host = QWidget(); col = QVBoxLayout(host)
        col.setContentsMargins(8, 2, 8, 8); col.setSpacing(6)
        self.charts = []
        for name, c, unit, scale, yf in self._CHANS:
            lab = QLabel(name); lab.setObjectName("wsChanLbl")
            lab.setStyleSheet("color:#989ba2;font-size:11px;font-weight:700;"
                              "padding:2px 0 0 2px;background:transparent;")
            col.addWidget(lab)
            ch = _TraceChart(scrub_cb=self._on_scrub)
            ch.setMinimumHeight(86); ch.setMaximumHeight(120)
            ch.yfmt = yf
            ch._ws = (name, c, unit, scale)        # metadati canale sul chart
            self.charts.append(ch)
            col.addWidget(ch)
        col.addStretch()
        scroll.setWidget(host)
        self.map_w = _LiveMap()
        row = QWidget(); rl = QHBoxLayout(row)
        rl.setContentsMargins(0, 0, 0, 0); rl.setSpacing(8)
        rl.addWidget(scroll, 3)
        rl.addWidget(self.map_w, 1)
        root.addWidget(row, 1)

    def _series(self, lap, col, scale, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con, f"SELECT lapdist, {col} v FROM samples "
                            "WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        xy = [(r["lapdist"], r["v"] * scale) for r in rs
              if r["lapdist"] is not None and r["v"] is not None]
        xy.sort(key=lambda q: q[0])
        out = []; last = None
        for x, v in xy:
            if last is None or x > last + 1e-6:
                out.append((x, v)); last = x
        return out

    def _sec_dist(self, lap):
        if lap is None or self.data.con is None:
            return []
        L = self.data._by_id.get(lap, {})
        s1 = L.get("s1") or 0.0; s2 = L.get("s2") or 0.0
        if not s1:
            return []
        try:
            rs = _rows(self.data.con, "SELECT t, lapdist FROM samples "
                                      "WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        b1 = b2 = None
        for r in rs:
            if r["t"] is None or r["lapdist"] is None:
                continue
            if b1 is None and r["t"] >= s1:
                b1 = r["lapdist"]
            if b2 is None and s2 and r["t"] >= s1 + s2:
                b2 = r["lapdist"]; break
        return [d for d in (b1, b2) if d is not None]

    def _xz(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con,
                       "SELECT pos_x, pos_z, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        return [(r["pos_x"], r["pos_z"], r["lapdist"]) for r in rs
                if r["pos_x"] is not None and r["pos_z"] is not None]

    def set_lap(self, lap):
        self._sel = lap; self._refresh()

    def set_compare(self, lap):
        self._cmp = lap; self._refresh()

    def _refresh(self):
        self._la = f"Lap {self._sel}" if self._sel is not None else "Selected"
        ref = self.data.cmp_source()
        if ref:
            rcon, rlap, rlabel, rtime, rsecs = ref
            self._lb = rlabel; cmp_lap = rlap; cmp_con = rcon; gold = True
        else:
            self._lb = f"Lap {self._cmp}" if self._cmp is not None else "Compare"
            cmp_lap = self._cmp; cmp_con = None; gold = False
        secd = self._sec_dist(self._sel)
        for ch in self.charts:
            name, c, unit, scale = ch._ws
            ch._cmp_gold = gold
            sel = self._series(self._sel, c, scale)
            cmp = self._series(cmp_lap, c, scale, con=cmp_con) \
                if cmp_lap is not None else []
            ch.set_laps(sel, cmp, self._la, self._lb, unit, sec_dist=secd)
        self.map_w._cmp_gold = gold
        self.map_w.set_review(self._xz(self._sel),
                              self._xz(cmp_lap, con=cmp_con) if cmp_lap is not None else [],
                              self._la, self._lb)
        self._update_read(None)

    def _on_scrub(self, ld):
        for ch in self.charts:
            ch.set_cursor(ld)
        self.map_w.set_hi_by_lapdist(ld)
        self._update_read(ld)

    def recolor(self):
        for ch in self.charts:
            ch.update()
        self.map_w.update()

    def _update_read(self, ld):
        if ld is None:
            self._read.setText(
                "<span style='color:#838790'>Hover a chart \u2014 one cursor "
                "scrubs all channels</span>")
            return
        parts = ["<b style='color:#f5f5f5'>%.0f m</b>" % ld]
        for ch in self.charts:
            name, c, unit, scale = ch._ws
            v = _TraceChart._val_at(ch._sel, ld)
            if v is not None:
                parts.append("%s <b style='color:#f5f5f5'>%.0f%s</b>"
                             % (name, v, unit))
        self._read.setText("&nbsp;&nbsp;\u00b7&nbsp;&nbsp;".join(parts))

    def recolor(self):
        for ch in self.charts:
            ch.update()


class _TraceTab(QWidget):
    """Tab metrica giro-intero: readout dati + grafico traccia + mappa (confronto).
    Stesso layout/funzioni per Speed/VE/Fuel/Hybrid: cambia solo metrica e dati."""
    def __init__(self, data, col, unit, label, modes=None):
        super().__init__()
        self.data = data
        self._col = col; self._unit = unit; self._label = label
        self._modes = modes or []          # [(testo, col)]
        self._sel = None; self._cmp = None
        self._la = "Selected"; self._lb = "Compare"
        root = QVBoxLayout(self)
        if self._modes:
            from PySide6.QtWidgets import QPushButton as _QPB
            bar = QHBoxLayout(); bar.setSpacing(6)
            lbl = QLabel("Layer:"); lbl.setStyleSheet("color:#989ba2;")
            bar.addWidget(lbl)
            self._mode_btns = {}
            for txt, mc in self._modes:
                b = _QPB(txt); b.setObjectName("modeBtn"); b.setCheckable(True)
                b.setCursor(Qt.PointingHandCursor)
                b.clicked.connect(lambda _=False, c=mc: self._set_mode(c))
                self._mode_btns[mc] = b; bar.addWidget(b)
            bar.addStretch()
            self._mode_btns[self._col].setChecked(True)
            root.addLayout(bar)
        self._read = QLabel(""); self._read.setStyleSheet("color:#dcdddf;padding:4px 10px;")
        root.addWidget(self._read)
        roww = QWidget(); rowl = QHBoxLayout(roww); rowl.setContentsMargins(0, 0, 0, 0)
        self.chart = _TraceChart(scrub_cb=self._on_scrub)
        self.map_w = _LiveMap()
        rowl.addWidget(self.chart, 2)
        rowl.addWidget(self.map_w, 1)
        root.addWidget(roww, 1)

    def _set_mode(self, col):
        self._col = col
        for c, b in self._mode_btns.items():
            b.setChecked(c == col)
        self._refresh()

    def _series(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con,
                       f"SELECT lapdist, {self._col} v FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        xy = [(r["lapdist"], r["v"]) for r in rs
              if r["lapdist"] is not None and r["v"] is not None]
        xy.sort(key=lambda q: q[0])
        out = []; last = None
        for x, v in xy:
            if last is None or x > last + 1e-6:
                out.append((x, v)); last = x
        return out

    def _xz(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con,
                       "SELECT pos_x, pos_z, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        return [(r["pos_x"], r["pos_z"], r["lapdist"]) for r in rs
                if r["pos_x"] is not None and r["pos_z"] is not None]

    def _sec_dist(self, lap):
        """Distanze (lapdist) ai confini settore del giro Selected, dai tempi s1/s2."""
        if lap is None or self.data.con is None:
            return []
        L = self.data._by_id.get(lap, {})
        s1 = L.get("s1") or 0.0
        s2 = L.get("s2") or 0.0
        if not s1:
            return []
        try:
            rs = _rows(self.data.con,
                       "SELECT t, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        b1 = b2 = None
        for r in rs:
            if r["t"] is None or r["lapdist"] is None:
                continue
            if b1 is None and r["t"] >= s1:
                b1 = r["lapdist"]
            if b2 is None and s2 and r["t"] >= s1 + s2:
                b2 = r["lapdist"]; break
        return [d for d in (b1, b2) if d is not None]

    def _refresh(self):
        self._la = f"Lap {self._sel}" if self._sel is not None else "Selected"
        self.chart.set_cursor(None)
        Ls = self.data._by_id.get(self._sel, {}) if self._sel is not None else {}
        ref = self.data.cmp_source()
        self.chart._cmp_gold = bool(ref)
        self.map_w._cmp_gold = bool(ref)
        if ref:
            rcon, rlap, rlabel, rtime, rsecs = ref
            cmp_series = self._series(rlap, con=rcon)
            cmp_xz = self._xz(rlap, con=rcon)
            self._lb = rlabel; lb_time = rtime; lb_secs = rsecs
        else:
            self._lb = f"Lap {self._cmp}" if self._cmp is not None else "Compare"
            Lc = self.data._by_id.get(self._cmp, {}) if self._cmp is not None else {}
            cmp_series = self._series(self._cmp)
            cmp_xz = self._xz(self._cmp)
            lb_time = Lc.get("lap_time")
            lb_secs = [Lc.get("s1"), Lc.get("s2"), Lc.get("s3")]
        self.chart.set_laps(self._series(self._sel), cmp_series,
                            self._la, self._lb, self._unit, sec_dist=self._sec_dist(self._sel),
                            la_time=Ls.get("lap_time"), lb_time=lb_time,
                            la_secs=[Ls.get("s1"), Ls.get("s2"), Ls.get("s3")],
                            lb_secs=lb_secs,
                            best_time=self.data.best_dict().get("lap_time"),
                            best_secs=[self.data.best_dict().get(k) for k in ("s1", "s2", "s3")])
        self.map_w.set_review(self._xz(self._sel), cmp_xz, self._la, self._lb)
        self._update_read(None)

    def _update_read(self, ld):
        def at(series):
            if not series or ld is None:
                return None
            return min(series, key=lambda q: abs(q[0] - ld))[1]
        sa = at(self.chart._sel); sb = at(self.chart._cmp)
        parts = [f"{self._label}  ({self._unit})"]
        if sa is not None:
            parts.append(f"{self._la}: {sa:.1f}")
        if sb is not None:
            parts.append(f"{self._lb}: {sb:.1f}")
            if sa is not None:
                parts.append(f"\u0394 {sa - sb:+.1f}")
        self._read.setText("      ".join(parts))

    def _on_scrub(self, ld):
        self.chart.set_cursor(ld)
        self.map_w.set_hi_by_lapdist(ld)
        self._update_read(ld)

    def set_lap(self, lap):
        self._sel = lap; self._refresh()

    def set_compare(self, lap):
        self._cmp = lap; self._refresh()

    def recolor(self):
        self.chart.update(); self.map_w.update()


class _TyreCorner(QWidget):
    """Simbolo mescola (cerchio S/M/H/W come standings/relative) cliccabile,
    con il valore medio del giro sotto. Evidenziato quando selezionato.
    kind: 'tyre' = mescola; 'brake' = disco freno; 'susp' = sospensione."""
    _BRAKE_SVG = (b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'>"
                  b"<circle cx='12' cy='12' r='9' fill='none' stroke='%s' stroke-width='1.6'/>"
                  b"<circle cx='12' cy='12' r='3.2' fill='none' stroke='%s' stroke-width='1.6'/>"
                  b"<g fill='%s'>"
                  b"<circle cx='12' cy='6.2' r='.8'/><circle cx='16.6' cy='9' r='.8'/>"
                  b"<circle cx='16.6' cy='15' r='.8'/><circle cx='12' cy='17.8' r='.8'/>"
                  b"<circle cx='7.4' cy='15' r='.8'/><circle cx='7.4' cy='9' r='.8'/></g>"
                  b"<rect x='15' y='9.4' width='4' height='5.2' rx='1' fill='%s'/></svg>")
    _SUSP_SVG = (b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'>"
                 b"<g fill='none' stroke='%s' stroke-width='1.6' stroke-linecap='round'"
                 b" stroke-linejoin='round'>"
                 b"<line x1='12' y1='3' x2='12' y2='5'/>"
                 b"<path d='M8 6 H16 L8 9 H16 L8 12 H16 L8 15 H16'/>"
                 b"<line x1='12' y1='16' x2='12' y2='21'/>"
                 b"<line x1='9' y1='21' x2='15' y2='21'/></g></svg>")

    def __init__(self, wheel, on_click, kind="tyre"):
        super().__init__()
        self._wheel = wheel; self._on_click = on_click; self._kind = kind
        self.setObjectName("tyreCorner")
        self.setCursor(Qt.PointingHandCursor)
        lay = QVBoxLayout(self); lay.setContentsMargins(6, 4, 6, 4); lay.setSpacing(1)
        self.name = QLabel(wheel.upper()); self.name.setAlignment(Qt.AlignCenter)
        self.name.setObjectName("tyreCornerName")
        lay.addWidget(self.name)
        if kind == "tyre":
            from core.tyre_cell import TyreCircle
            self.circle = TyreCircle(30); self._icon = None
            lay.addWidget(self.circle, 0, Qt.AlignCenter)
        else:
            self.circle = None
            self._icon = _SvgBox(); self._icon.setFixedSize(30, 30)
            lay.addWidget(self._icon, 0, Qt.AlignCenter)
        self.val = QLabel("\u2014"); self.val.setAlignment(Qt.AlignCenter)
        self.val.setObjectName("tyreCornerVal")
        lay.addWidget(self.val)
        self.setFixedSize(60, 72)
        self.set_selected(False)

    def _icon_svg(self, col):
        if self._kind == "brake":
            return self._BRAKE_SVG % (col, col, col, col)
        if self._kind == "susp":
            return self._SUSP_SVG % col
        return b""

    def set_sigla(self, s):
        if self.circle is not None:
            self.circle.set_sigla(s)

    def set_val(self, v):
        self.val.setText(f"{v:.0f}" if v is not None else "\u2014")

    def set_selected(self, on):
        self.setStyleSheet(
            "#tyreCorner{border:none;border-radius:8px;background:#16242a;}"
            "#tyreCornerName{color:#f6f6f6;font-size:11px;font-weight:700;}"
            "#tyreCornerVal{color:#f6f6f6;font-size:11px;font-weight:600;}"
            if on else
            "#tyreCorner{border:none;border-radius:8px;background:transparent;}"
            "#tyreCornerName{color:#a7aaaf;font-size:11px;font-weight:700;}"
            "#tyreCornerVal{color:#a7aaaf;font-size:11px;}")
        if self._icon is not None:
            col = _ACCENT if on else "#a7aaaf"
            self._icon.load(self._icon_svg(col.encode()))

    def mousePressEvent(self, e):
        self._on_click(self._wheel)


class _PedalsTab(QWidget):
    """Pedali (throttle/brake) vs distanza + mappa. Selected vs Compare/REF.
    Sostituisce la vecchia tab Times (i tempi/settori stanno nell'Overview)."""
    def __init__(self, data):
        super().__init__()
        self.data = data
        self._sel = None; self._cmp = None
        self._la = "Selected"; self._lb = "Compare"
        self.chart = None                     # escluso dalla sincro zoom/AB
        root = QVBoxLayout(self)
        self._read = QLabel(""); self._read.setStyleSheet("color:#dcdddf;padding:4px 10px;")
        root.addWidget(self._read)
        roww = QWidget(); rowl = QHBoxLayout(roww); rowl.setContentsMargins(0, 0, 0, 0)
        self.pedal = _PedalChart(scrub_cb=self._on_scrub)
        self.map_w = _LiveMap()
        rowl.addWidget(self.pedal, 2)
        rowl.addWidget(self.map_w, 1)
        root.addWidget(roww, 1)

    def _pts(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con, "SELECT lapdist, throttle, brake FROM samples "
                            "WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        xy = [(r["lapdist"], r["throttle"], r["brake"]) for r in rs
              if r["lapdist"] is not None]
        xy.sort(key=lambda p: p[0]); out = []; last = None
        for x, t, b in xy:
            if last is None or x > last + 1e-6:
                out.append((x, t, b)); last = x
        return out

    def _xz(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con, "SELECT pos_x, pos_z, lapdist FROM samples "
                            "WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        return [(r["pos_x"], r["pos_z"], r["lapdist"]) for r in rs
                if r["pos_x"] is not None and r["pos_z"] is not None]

    def _sec_dist(self, lap):
        if lap is None or self.data.con is None:
            return []
        L = self.data._by_id.get(lap, {})
        s1 = L.get("s1") or 0.0; s2 = L.get("s2") or 0.0
        if not s1:
            return []
        try:
            rs = _rows(self.data.con, "SELECT t, lapdist FROM samples "
                                      "WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        b1 = b2 = None
        for r in rs:
            if r["t"] is None or r["lapdist"] is None:
                continue
            if b1 is None and r["t"] >= s1:
                b1 = r["lapdist"]
            if b2 is None and s2 and r["t"] >= s1 + s2:
                b2 = r["lapdist"]; break
        return [d for d in (b1, b2) if d is not None]

    def _refresh(self):
        self._la = f"Lap {self._sel}" if self._sel is not None else "Selected"
        self.pedal.set_cursor(None)
        Ls = self.data._by_id.get(self._sel, {}) if self._sel is not None else {}
        ref = self.data.cmp_source()
        self.map_w._cmp_gold = bool(ref)
        if ref:
            rcon, rlap, rlabel, rtime, rsecs = ref
            cmp_pts = self._pts(rlap, con=rcon); cmp_xz = self._xz(rlap, con=rcon)
            self._lb = rlabel; lb_time = rtime; lb_secs = rsecs
        else:
            self._lb = f"Lap {self._cmp}" if self._cmp is not None else "Compare"
            Lc = self.data._by_id.get(self._cmp, {}) if self._cmp is not None else {}
            cmp_pts = self._pts(self._cmp); cmp_xz = self._xz(self._cmp)
            lb_time = Lc.get("lap_time")
            lb_secs = [Lc.get("s1"), Lc.get("s2"), Lc.get("s3")]
        self.pedal.set_laps(self._pts(self._sel), cmp_pts, self._la, self._lb,
                            sec_dist=self._sec_dist(self._sel),
                            la_time=Ls.get("lap_time"), lb_time=lb_time,
                            la_secs=[Ls.get("s1"), Ls.get("s2"), Ls.get("s3")],
                            lb_secs=lb_secs,
                            best_time=self.data.best_dict().get("lap_time"),
                            best_secs=[self.data.best_dict().get(k) for k in ("s1", "s2", "s3")])
        self.map_w.set_review(self._xz(self._sel), cmp_xz, self._la, self._lb)
        self._update_read(None)

    def _update_read(self, ld):
        def at(series):
            if not series or ld is None:
                return None
            return min(series, key=lambda q: abs(q[0] - ld))
        sa = at(self.pedal._sel); sb = at(self.pedal._cmp)
        parts = ["Pedals  (throttle / brake %)"]
        if sa is not None:
            parts.append(f"{self._la}: T {sa[1]*100:.0f}  B {sa[2]*100:.0f}")
        if sb is not None:
            parts.append(f"{self._lb}: T {sb[1]*100:.0f}  B {sb[2]*100:.0f}")
        self._read.setText("      ".join(parts))

    def _on_scrub(self, ld):
        self.pedal.set_cursor(ld)
        self.map_w.set_hi_by_lapdist(ld)
        self._update_read(ld)

    def set_lap(self, lap):
        self._sel = lap; self._refresh()

    def set_compare(self, lap):
        self._cmp = lap; self._refresh()

    def recolor(self):
        self.pedal.update(); self.map_w.update()


class _TyresTab(QWidget):
    """Vista gomme PER RUOTA: 4 angoli (FL/FR/RL/RR) cliccabili, ognuno col suo
    grafico. Selettore strato (Surface/Carcass/Inner/Press). Confronto sel/cmp."""
    _LAYERS = [("Surface", "ts"), ("Carcass", "t"), ("Inner", "ti"),
               ("Press", "p"), ("Wear", "w")]
    _WHEELS = [("FL", "fl"), ("FR", "fr"), ("RL", "rl"), ("RR", "rr")]

    def __init__(self, data):
        super().__init__()
        self.data = data
        self._sel = None; self._cmp = None
        self._wheel = "fl"; self._layer = "ts"
        root = QVBoxLayout(self)
        self.chart = _TraceChart(scrub_cb=self._on_scrub)
        self.map_w = _LiveMap()
        top = QHBoxLayout(); top.setSpacing(10)
        ch = QHBoxLayout(); ch.setSpacing(8)
        self._corner = {}
        for lab, w in self._WHEELS:
            cc = _TyreCorner(w, self._set_wheel, getattr(self, "_CORNER_KIND", "tyre"))
            ch.addWidget(cc); self._corner[w] = cc
        self._corner["fl"].set_selected(True)
        cwrap = QWidget(); cwrap.setLayout(ch); top.addWidget(cwrap)
        top.addStretch()
        self._read = QLabel(""); self._read.setObjectName("tyreRead")
        self._read.setStyleSheet("color:#dcdddf;padding:2px 4px;")
        self._read.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        top.addWidget(self._read)
        root.addLayout(top)
        # selettore strato come TAB eleganti sopra il grafico
        self._lbar = QTabBar(); self._lbar.setObjectName("layerTabs")
        self._lbar.setExpanding(False); self._lbar.setDrawBase(False)
        self._lbar.setCursor(Qt.PointingHandCursor)
        for lab, ly in self._LAYERS:
            self._lbar.addTab(lab)
        self._lbar.setStyleSheet(
            "QTabBar#layerTabs{qproperty-drawBase:0;}"
            "QTabBar#layerTabs::tab{background:transparent;color:#a6a9af;"
            "padding:4px 12px;margin-right:2px;border:0;font-size:12px;"
            "border-bottom:2px solid transparent;font-weight:400;}"
            "QTabBar#layerTabs::tab:hover{color:%s;}"
            "QTabBar#layerTabs::tab:selected{color:%s;border-bottom:2px solid %s;}"
            % (_FG, _FG, _ACCENT))
        self._lbar.currentChanged.connect(self._on_layer_idx)
        root.addWidget(self._lbar)
        roww = QWidget(); rowl = QHBoxLayout(roww); rowl.setContentsMargins(0, 0, 0, 0)
        rowl.addWidget(self.chart, 3); rowl.addWidget(self.map_w, 1)
        root.addWidget(roww, 1)
        self._lbar.setCurrentIndex(0)

    @property
    def _col(self):
        return f"tyre_{self._layer}_{self._wheel}"

    @property
    def _unit(self):
        return {"p": "kPa", "w": "%"}.get(self._layer, "\u00b0C")

    def _set_wheel(self, w):
        self._wheel = w
        for k, cc in self._corner.items():
            cc.set_selected(k == w)
        self._refresh()

    def _on_layer_idx(self, i):
        if 0 <= i < len(self._LAYERS):
            self._layer = self._LAYERS[i][1]
            self._refresh()

    def _series(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con,
                       f"SELECT lapdist, {self._col} v FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []                       # file vecchio senza canali per ruota
        xy = [(r["lapdist"], r["v"]) for r in rs
              if r["lapdist"] is not None and r["v"] is not None]
        xy.sort(key=lambda q: q[0])
        out = []; last = None
        for x, v in xy:
            if last is None or x > last + 1e-6:
                out.append((x, v)); last = x
        return out

    def _xz(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con,
                       "SELECT pos_x, pos_z, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        return [(r["pos_x"], r["pos_z"], r["lapdist"]) for r in rs
                if r["pos_x"] is not None and r["pos_z"] is not None]

    def _sec_dist(self, lap):
        if lap is None or self.data.con is None:
            return []
        L = self.data._by_id.get(lap, {})
        s1 = L.get("s1") or 0.0; s2 = L.get("s2") or 0.0
        if not s1:
            return []
        try:
            rs = _rows(self.data.con,
                       "SELECT t, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        b1 = b2 = None
        for r in rs:
            if r["t"] is None or r["lapdist"] is None:
                continue
            if b1 is None and r["t"] >= s1:
                b1 = r["lapdist"]
            if b2 is None and s2 and r["t"] >= s1 + s2:
                b2 = r["lapdist"]; break
        return [d for d in (b1, b2) if d is not None]

    def _refresh(self):
        la = f"Lap {self._sel}" if self._sel is not None else "Selected"
        self.chart.set_cursor(None)
        self.chart.baseline = None; self.chart.yfmt = "{:.0f}"
        ref = self.data.cmp_source()
        self.chart._cmp_gold = bool(ref)
        self.map_w._cmp_gold = bool(ref)
        if ref:
            rcon, rlap, rlabel, rtime, rsecs = ref
            lb = rlabel
            cmp_series = self._series(rlap, con=rcon)
            cmp_xz = self._xz(rlap, con=rcon)
        else:
            lb = f"Lap {self._cmp}" if self._cmp is not None else "Compare"
            cmp_series = self._series(self._cmp)
            cmp_xz = self._xz(self._cmp)
        self.chart.set_laps(self._series(self._sel), cmp_series,
                            la, lb, self._unit, sec_dist=self._sec_dist(self._sel))
        self.map_w.set_review(self._xz(self._sel), cmp_xz, la, lb)
        self._update_corners()
        self._update_read(None)

    def _compounds4(self):
        out = {"fl": "", "fr": "", "rl": "", "rr": ""}
        if self.data.con is None:
            return out
        try:
            rs = _rows(self.data.con, "SELECT compounds4 FROM session_meta WHERE id=1")
            parts = [x.strip() for x in ((rs[0]["compounds4"] if rs else "") or "").split(",")]
            for i, w in enumerate(("fl", "fr", "rl", "rr")):
                if i < len(parts):
                    out[w] = parts[i]
        except Exception:
            pass
        return out

    def _update_corners(self):
        comp = self._compounds4()
        for lab, w in self._WHEELS:
            self._corner[w].set_sigla(comp.get(w, ""))
            val = None
            if self._sel is not None and self.data.con is not None:
                try:
                    rs = _rows(self.data.con,
                               f"SELECT AVG(tyre_{self._layer}_{w}) a FROM samples WHERE lap=?",
                               (self._sel,))
                    val = rs[0]["a"] if rs else None
                except Exception:
                    val = None
            self._corner[w].set_val(val)
            self._corner[w].set_selected(w == self._wheel)

    def _update_read(self, ld):
        def at(series):
            if not series or ld is None:
                return None
            return min(series, key=lambda q: abs(q[0] - ld))[1]
        sa = at(self.chart._sel); sb = at(self.chart._cmp)
        name = dict(self._WHEELS)[self._wheel] if self._wheel in dict(self._WHEELS) else self._wheel.upper()
        lyr = dict((v, k) for k, v in self._LAYERS).get(self._layer, self._layer)
        parts = [f"{self._wheel.upper()} {lyr}  ({self._unit})"]
        if sa is not None:
            parts.append(f"Selected: {sa:.1f}")
        if sb is not None:
            parts.append(f"Compare: {sb:.1f}")
            if sa is not None:
                parts.append(f"\u0394 {sa - sb:+.1f}")
        self._read.setText("      ".join(parts))

    def _on_scrub(self, ld):
        self.chart.set_cursor(ld)
        self.map_w.set_hi_by_lapdist(ld)
        self._update_read(ld)

    def set_lap(self, lap):
        self._sel = lap; self._refresh()

    def set_compare(self, lap):
        self._cmp = lap; self._refresh()

    def recolor(self):
        self.chart.update(); self.map_w.update()


class _BrakesTab(_TyresTab):
    """Freni PER RUOTA (FL/FR/RL/RR): temperatura disco o pressione freno."""
    _LAYERS = [("Temp", "t"), ("Pressure", "p")]
    _COLMAP = {"t": "brake_t", "p": "brake_p"}
    _CORNER_KIND = "brake"

    def __init__(self, data):
        super().__init__(data)
        self._layer = "t"
        try:
            self._lbar.setCurrentIndex(0)
        except Exception:
            pass
        self._refresh()

    @property
    def _col(self):
        return f"{self._COLMAP.get(self._layer, 'brake_t')}_{self._wheel}"

    @property
    def _unit(self):
        return "%" if self._layer == "p" else "\u00b0C"

    def _update_corners(self):
        pref = self._COLMAP.get(self._layer, "brake_t")
        for lab, w in self._WHEELS:
            self._corner[w].set_sigla("")          # i freni non hanno mescola
            val = None
            if self._sel is not None and self.data.con is not None:
                try:
                    rs = _rows(self.data.con,
                               f"SELECT AVG({pref}_{w}) a FROM samples WHERE lap=?",
                               (self._sel,))
                    val = rs[0]["a"] if rs else None
                except Exception:
                    val = None
            self._corner[w].set_val(val)
            self._corner[w].set_selected(w == self._wheel)


class _SuspTab(_TyresTab):
    """Sospensioni PER RUOTA: altezza da terra (ride height) o deflessione (mm)."""
    _LAYERS = [("Ride height", "rh"), ("Deflection", "sd")]
    _COLMAP = {"rh": "ride_h", "sd": "susp_d"}
    _CORNER_KIND = "susp"

    def __init__(self, data):
        super().__init__(data)
        self._layer = "rh"
        try:
            self._lbar.setCurrentIndex(0)
        except Exception:
            pass
        self._refresh()

    @property
    def _col(self):
        return f"{self._COLMAP.get(self._layer, 'ride_h')}_{self._wheel}"

    @property
    def _unit(self):
        return "mm"

    def _update_corners(self):
        pref = self._COLMAP.get(self._layer, "ride_h")
        for lab, w in self._WHEELS:
            self._corner[w].set_sigla("")
            val = None
            if self._sel is not None and self.data.con is not None:
                try:
                    rs = _rows(self.data.con,
                               f"SELECT AVG({pref}_{w}) a FROM samples WHERE lap=?",
                               (self._sel,))
                    val = rs[0]["a"] if rs else None
                except Exception:
                    val = None
            self._corner[w].set_val(val)
            self._corner[w].set_selected(w == self._wheel)


class _GGCanvas(QWidget):
    """Diagramma G-G: g laterale (x) vs g longitudinale (y)."""
    def __init__(self):
        super().__init__()
        self._sel = []; self._cmp = []; self._cmp_gold = False
        self.setMinimumHeight(220)

    def set_points(self, sel, cmp, cmp_gold=False):
        self._sel = sel or []; self._cmp = cmp or []
        self._cmp_gold = bool(cmp_gold); self.update()

    def paintEvent(self, ev):
        from PySide6.QtCore import QPointF
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing)
        w = self.width(); h = self.height()
        cx = w / 2.0; cy = h / 2.0
        R = min(w, h) / 2.0 - 22
        if R <= 0:
            p.end(); return
        gmax = 4.0
        p.setPen(QPen(QColor("#282a2e"), 1))
        for g in (1, 2, 3, 4):
            r = R * g / gmax
            p.drawEllipse(QPointF(cx, cy), r, r)
        p.drawLine(int(cx - R), int(cy), int(cx + R), int(cy))
        p.drawLine(int(cx), int(cy - R), int(cx), int(cy + R))
        p.setPen(QColor("#6e727b"))
        p.drawText(int(cx + R - 8), int(cy - 4), "Lat")
        p.drawText(int(cx + 4), int(cy - R + 12), "Accel")
        p.drawText(int(cx + 4), int(cy + R - 2), "Brake")
        for g in (1, 2, 3, 4):
            p.drawText(int(cx + R * g / gmax - 6), int(cy + 12), f"{g}")

        def plot(pts, col):
            p.setPen(Qt.NoPen); p.setBrush(QColor(col))
            for glat, glong in pts:
                x = cx + R * max(-gmax, min(gmax, glat)) / gmax
                y = cy - R * max(-gmax, min(gmax, glong)) / gmax
                p.drawEllipse(QPointF(x, y), 1.7, 1.7)
        plot(self._cmp, _cmp_col(self._cmp_gold))
        plot(self._sel, _sel_col())
        p.end()


class _GGTab(QWidget):
    """Diagramma G-G (accelerazioni). Selected vs Compare/REF."""
    def __init__(self, data):
        super().__init__()
        self.data = data
        self._sel = None; self._cmp = None
        self.chart = None; self.map_w = None
        root = QVBoxLayout(self)
        self._read = QLabel("G-G  \u00b7  lateral vs longitudinal (g)")
        self._read.setStyleSheet("color:#989ba2;padding:4px 10px;")
        root.addWidget(self._read)
        self.canvas = _GGCanvas()
        root.addWidget(self.canvas, 1)

    def _pts(self, lap, con=None):
        con = con or self.data.con
        if lap is None or con is None:
            return []
        try:
            rs = _rows(con, "SELECT g_lat, g_long FROM samples "
                            "WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        return [(r["g_lat"], r["g_long"]) for r in rs
                if r["g_lat"] is not None and r["g_long"] is not None]

    def _refresh(self):
        ref = self.data.cmp_source()
        if ref:
            rcon, rlap = ref[0], ref[1]
            cmp = self._pts(rlap, con=rcon); gold = True
        else:
            cmp = self._pts(self._cmp); gold = False
        self.canvas.set_points(self._pts(self._sel), cmp, gold)

    def set_lap(self, lap):
        self._sel = lap; self._refresh()

    def set_compare(self, lap):
        self._cmp = lap; self._refresh()

    def recolor(self):
        self.canvas.update()


class _StintTab(QWidget):
    """Lista giri dello stint (come nella live): Lap/Time/S1/S2/S3/VE/Fuel.
    La riga Selected/Compare è evidenziata."""
    def __init__(self, data):
        super().__init__()
        self.data = data
        self._sel = None; self._cmp = None
        root = QVBoxLayout(self)
        self.tbl = QTableWidget(); self.tbl.setColumnCount(7)
        self.tbl.setHorizontalHeaderLabels(["Lap", "Time", "S1", "S2", "S3", "VE %", "Fuel L"])
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.setFocusPolicy(Qt.NoFocus)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tbl.setShowGrid(False); self.tbl.setAlternatingRowColors(True)
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        root.addWidget(self.tbl)
        self.theo = QLabel("Theoretical best  \u2014")
        self.theo.setObjectName("stintTheo")
        self.theo.setStyleSheet(
            "#stintTheo{color:#dcdddf;font-size:13px;font-weight:600;padding:8px 4px 2px;}")
        root.addWidget(self.theo)

    def _rebuild(self):
        ids = list(self.data.lap_ids or [])
        self.tbl.setRowCount(len(ids))

        def it(txt):
            w = QTableWidgetItem(txt); w.setTextAlignment(Qt.AlignCenter); return w

        for r, lap in enumerate(ids):
            L = self.data._by_id.get(lap, {})
            lt = L.get("lap_time") or 0
            self.tbl.setItem(r, 0, it(str(lap)))
            self.tbl.setItem(r, 1, it(_fmt(lt) if lt > 0 else "\u2014"))
            self.tbl.setItem(r, 2, it(_fmt(L.get("s1"))))
            self.tbl.setItem(r, 3, it(_fmt(L.get("s2"))))
            self.tbl.setItem(r, 4, it(_fmt(L.get("s3"))))
            self.tbl.setItem(r, 5, it(_f2(L.get("ve_used"))))
            self.tbl.setItem(r, 6, it(_f2(L.get("fuel_used"))))
        # best tempo e best settori in fuxia
        valid = [self.data._by_id.get(l, {}) for l in ids]

        def _best(key):
            vals = [L.get(key) for L in valid
                    if (L.get(key) or 0) > 0 and not L.get("invalid")]
            return min(vals) if vals else None
        bt = _best("lap_time"); b1 = _best("s1"); b2 = _best("s2"); b3 = _best("s3")
        if b1 and b2 and b3:
            theo = b1 + b2 + b3
            extra = ""
            if bt and theo < bt:
                extra = f"   ( -{_fmt(bt - theo)} vs best )"
            self.theo.setText(
                f"Theoretical best  {_fmt(theo)}   "
                f"=  {_fmt(b1)} + {_fmt(b2)} + {_fmt(b3)}{extra}")
        else:
            self.theo.setText("Theoretical best  \u2014")
        for r, lap in enumerate(ids):
            L = self.data._by_id.get(lap, {})
            for c, key, b in ((1, "lap_time", bt), (2, "s1", b1), (3, "s2", b2), (4, "s3", b3)):
                itm = self.tbl.item(r, c)
                if itm is not None and b is not None and (L.get(key) or 0) == b:
                    itm.setForeground(QBrush(QColor(_FUX)))
        self._highlight()

    def _highlight(self):
        ids = list(self.data.lap_ids or [])
        _best_id = None; _best_t = None
        for lap in ids:
            t = (self.data._by_id.get(lap, {}) or {}).get("lap_time")
            if t and (_best_t is None or t < _best_t):
                _best_t = t; _best_id = lap
        for r, lap in enumerate(ids):
            bg = None
            if lap == self._sel or lap == self._cmp:
                bg = QColor(_FUX if lap == _best_id else _SEL_COL)
            for c in range(self.tbl.columnCount()):
                itm = self.tbl.item(r, c)
                if itm is None:
                    continue
                if bg is not None:
                    b = QColor(bg); b.setAlpha(55); itm.setBackground(b)
                else:
                    itm.setBackground(QColor(0, 0, 0, 0))

    def set_lap(self, lap):
        self._sel = lap; self._rebuild()

    def set_compare(self, lap):
        self._cmp = lap; self._highlight()

    def recolor(self):
        self._highlight()


class _CatTable(QWidget):
    """Tab di una sola categoria: caption | Selected | Compare.
    Sfondo pulito, testo bianco; temperature heat; best stint in fuxia.
    Sotto la tabella un grafico di confronto Selected (rosso) vs Compare (viola):
    selezionando una riga si traccia quel dato (continuo sul giro per i canali
    campionati, 3 punti S1/S2/S3 per i dati per-settore)."""
    def __init__(self, data, metrics, show_chart=True, tyre_modes=False, pedal=False):
        super().__init__()
        self.data = data
        self.metrics = metrics
        root = QVBoxLayout(self)

        self._mode_btns = {}
        if tyre_modes:
            bar = QHBoxLayout(); bar.setSpacing(6)
            lbl = QLabel("Temp:"); lbl.setStyleSheet("color:#989ba2;")
            bar.addWidget(lbl)
            for key, txt in (("t_", "Carcass"), ("ti_", "Layer"), ("ts_", "Tread")):
                b = QPushButton(txt); b.setObjectName("modeBtn"); b.setCheckable(True)
                b.setCursor(Qt.PointingHandCursor)
                b.clicked.connect(lambda _=False, k=key: self._set_tyre_mode(k))
                self._mode_btns[key] = b; bar.addWidget(b)
            bar.addStretch()
            self._mode_btns[self.data.tyre_mode].setChecked(True)
            root.addLayout(bar)

        self.tbl = _FitTable() if pedal else QTableWidget()
        self.tbl.setColumnCount(3)
        self.tbl.setShowGrid(False)
        self.tbl.setHorizontalHeaderLabels(["", "Selected", "Compare"])
        self.tbl.verticalHeader().setVisible(False)
        hh = self.tbl.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        hh.setSectionResizeMode(1, QHeaderView.Stretch)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.setFocusPolicy(Qt.NoFocus)
        self.tbl.setAlternatingRowColors(True)
        self.tbl.setRowCount(len(metrics))
        for r, name in enumerate(metrics):
            ki = QTableWidgetItem(name)
            ki.setForeground(QBrush(QColor("#dcdddf")))
            if name in ("Stint", "Lap", "Valid"):
                ki.setFlags(ki.flags() & ~Qt.ItemIsSelectable)
            self.tbl.setItem(r, 0, ki)
        root.addWidget(self.tbl)

        # grafico di confronto sempre presente: selezionando una riga si traccia
        self.tbl.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tbl.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tbl.itemSelectionChanged.connect(self._on_row)
        if show_chart:
            self.chart = _CmpChart()
            root.addWidget(self.chart)
            root.setStretch(0, 3); root.setStretch(1, 2)
        else:
            self.chart = None
            # niente selezione riga nella tab Times: l'evidenziazione di Qt
            # sovrascriverebbe il colore della cella (il fuxia del best).
            self.tbl.setSelectionMode(QAbstractItemView.NoSelection)
        self.pedal = None
        self.map_w = None
        if pedal:
            self.tbl.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            self.tbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            cap = QLabel("Pedals (scrub on map)  ·  selected lap")
            cap.setStyleSheet("color:#989ba2;padding:6px 2px 0;")
            root.addWidget(cap)
            roww = QWidget(); rowl = QHBoxLayout(roww); rowl.setContentsMargins(0, 0, 0, 0)
            self.pedal = _PedalChart(scrub_cb=self._on_scrub)
            self.map_w = _LiveMap()              # solo display: dot guidato dal grafico
            rowl.addWidget(self.pedal, 2)        # pedali 2/3
            rowl.addWidget(self.map_w, 1)        # mappa 1/3
            root.addWidget(roww, 1)
        # riga di default = prima riga con un valore (non Stint/Lap/Valid)
        self._def_row = next((i for i, m in enumerate(metrics)
                              if m not in ("Stint", "Lap", "Valid")), -1)

        self._sel = None
        self._cmp = None

    def _pedal_pts(self, lap):
        if lap is None or self.data.con is None:
            return []
        try:
            rs = _rows(self.data.con,
                       "SELECT lapdist, throttle, brake FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        xy = [(r["lapdist"], r["throttle"], r["brake"]) for r in rs if r["lapdist"] is not None]
        xy.sort(key=lambda p: p[0])
        clean = []; last = None
        for x, t, b in xy:
            if last is None or x > last + 1e-6:
                clean.append((x, t, b)); last = x
        return clean

    def _sec_dist_for(self, lap):
        """Distanze (lapdist) ai confini settore del giro, dai tempi s1/s2."""
        if lap is None or self.data.con is None:
            return []
        L = self.data._by_id.get(lap, {})
        s1 = L.get("s1") or 0.0
        s2 = L.get("s2") or 0.0
        if not s1:
            return []
        try:
            rs = _rows(self.data.con,
                       "SELECT t, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        b1 = b2 = None
        for r in rs:
            if r["t"] is None or r["lapdist"] is None:
                continue
            if b1 is None and r["t"] >= s1:
                b1 = r["lapdist"]
            if b2 is None and s2 and r["t"] >= s1 + s2:
                b2 = r["lapdist"]; break
        return [d for d in (b1, b2) if d is not None]

    def _on_scrub(self, lapdist):
        if self.pedal is not None:
            self.pedal.set_cursor(lapdist)
        if self.map_w is not None:
            self.map_w.set_hi_by_lapdist(lapdist)

    def _track_xz(self, lap):
        if lap is None or self.data.con is None:
            return []
        try:
            rs = _rows(self.data.con,
                       "SELECT pos_x, pos_z, lapdist FROM samples WHERE lap=? ORDER BY t", (lap,))
        except Exception:
            return []
        return [(r["pos_x"], r["pos_z"], r["lapdist"]) for r in rs
                if r["pos_x"] is not None and r["pos_z"] is not None]

    def _refresh_pedal(self):
        if self.pedal is None:
            return
        self.tbl.updateGeometry()
        la = f"Lap {self._sel}" if self._sel is not None else "Selected"
        lb = f"Lap {self._cmp}" if self._cmp is not None else "Compare"
        self.pedal.set_cursor(None)
        Ls = self.data._by_id.get(self._sel, {}) if self._sel is not None else {}
        Lc = self.data._by_id.get(self._cmp, {}) if self._cmp is not None else {}
        self.pedal.set_laps(self._pedal_pts(self._sel), self._pedal_pts(self._cmp),
                            la, lb, sec_dist=self._sec_dist_for(self._sel),
                            la_time=Ls.get("lap_time"), lb_time=Lc.get("lap_time"),
                            la_secs=[Ls.get("s1"), Ls.get("s2"), Ls.get("s3")],
                            lb_secs=[Lc.get("s1"), Lc.get("s2"), Lc.get("s3")],
                            best_time=self.data.best_dict().get("lap_time"),
                            best_secs=[self.data.best_dict().get(k) for k in ("s1", "s2", "s3")])
        if self.map_w is not None:
            sel_pts = self._track_xz(self._sel)
            cmp_pts = self._track_xz(self._cmp) if self._cmp is not None else []
            self.map_w.set_review(sel_pts, cmp_pts, la, lb)

    def _driver_meta(self):
        """(class_tag, num) del pilota dai metadati sessione, per il dot."""
        if self.data.con is None:
            return "", ""
        try:
            r = _rows(self.data.con,
                      "SELECT car_class, car_num FROM session_meta WHERE id=1")
            if r:
                return class_tag(r[0]["car_class"] or ""), (r[0]["car_num"] or "")
        except Exception:
            pass
        return "", ""

    def _drv_color(self):
        tag, _ = self._driver_meta()
        return _CLASS_COL.get(tag, "#ff3bd4")

    def _track_name(self):
        if self.data.con is None:
            return ""
        try:
            r = _rows(self.data.con, "SELECT track FROM session_meta WHERE id=1")
            return (r[0]["track"] if r else "") or ""
        except Exception:
            return ""

    def set_lap(self, lap):
        self._sel = lap
        h = QTableWidgetItem(f"Lap {lap}" if lap is not None else "Selected")
        h.setForeground(QBrush(QColor(_sel_col())))
        self.tbl.setHorizontalHeaderItem(1, h)
        self._fill(1, lap)
        self._mark_fastest()
        self._refresh_pedal()
        if self.chart is not None:
            if self.tbl.currentRow() < 0 and self._def_row >= 0:
                self.tbl.selectRow(self._def_row)
            else:
                self._refresh_chart()

    def set_compare(self, lap):
        self._cmp = lap
        h = QTableWidgetItem(f"Lap {lap}" if lap is not None else "Compare")
        h.setForeground(QBrush(QColor(_cmp_col(getattr(self, "_cmp_gold", False)))))
        self.tbl.setHorizontalHeaderItem(2, h)
        self._fill(2, lap)
        self._mark_fastest()
        self._refresh_pedal()
        self._refresh_chart()

    def _set_tyre_mode(self, key):
        self.data.tyre_mode = key
        for k, b in self._mode_btns.items():
            b.setChecked(k == key)
        self._fill(1, self._sel)
        self._fill(2, self._cmp)
        self._refresh_chart()

    def _on_row(self):
        self._refresh_chart()

    def _cur_metric(self):
        rws = self.tbl.selectionModel().selectedRows()
        if rws:
            m = self.metrics[rws[0].row()]
            if m not in ("Stint", "Lap", "Valid"):
                return m
        return self.metrics[self._def_row] if self._def_row >= 0 else None

    def _sec_row(self, lap, sidx):
        rs = _rows(self.data.con,
                   "SELECT * FROM sectors WHERE lap=? AND sector=?", (lap, sidx))
        return rs[0] if rs else None

    @staticmethod
    def _wheels(sr, pre):
        if sr is None:
            return [(p.upper(), None) for p in ("fl", "fr", "rl", "rr")]
        return [(p.upper(), sr.get(pre + p)) for p in ("fl", "fr", "rl", "rr")]

    def _metric_vals(self, lap, metric):
        """(unit, [(label, value)]) sempre multi-punto: 4 ruote per gomme/freni/usura,
        profilo 3 settori per gli scalari. Le metriche a traccia continua sono gestite
        in _refresh_chart e non passano di qui."""
        if lap is None or self.data.con is None:
            return "", []
        m = metric.lower()
        sidx = int(metric[1]) - 1 if (metric[:1] == "S" and metric[1:2].isdigit()) else 0

        # per-ruota: 4 punti FL/FR/RL/RR del settore scelto (gomme, freni, usura -> torri)
        if "tyre" in m:
            return "\u00b0C", self._wheels(self._sec_row(lap, sidx), "t_")
        if "brake" in m:
            return "\u00b0C", self._wheels(self._sec_row(lap, sidx), "b_")
        if "wear" in m:
            return "%", self._wheels(self._sec_row(lap, sidx), "w_")

        # scalari: profilo sui 3 settori (linea S1·S2·S3)
        def secvals(col, nz=False):
            out = []
            for s in (1, 2, 3):
                sr = self._sec_row(lap, s - 1)
                v = sr.get(col) if sr else None
                if nz and v is not None and v < 0:
                    v = None
                out.append((f"S{s}", v))
            return out

        if "speed avg" in m:
            return "km/h", secvals("spd_avg")
        if "speed max" in m:
            return "km/h", secvals("spd_max")
        if "fuel" in m:
            return "L", secvals("fuel_used", nz=True)
        if m.startswith("ve ") or " ve " in m or m.startswith("ve("):
            return "%", secvals("ve_used", nz=True)
        if "regen" in m:
            return "kWh", secvals("regen_gain_kwh")
        if "boost" in m:
            return "kWh", secvals("boost_kwh")
        if "soc" in m:
            out = []
            for s in (1, 2, 3):
                sr = self._sec_row(lap, s - 1)
                v = sr.get("soc_used") if sr else None
                out.append((f"S{s}", (-v if v is not None else None)))
            return "%", out

        # tempi: profilo dei tempi settore
        L = self.data._by_id.get(lap, {})
        if metric in ("Time", "Sector 1", "Sector 2", "Sector 3"):
            return "s", [("S1", L.get("s1")), ("S2", L.get("s2")), ("S3", L.get("s3"))]
        return "", []

    def _trace(self, lap, col, sidx):
        """Traccia continua del canale 'col' vs distanza. Se sidx è 0/1/2 ritaglia
        al settore usando i tempi settore del giro (s1/s2/s3)."""
        if lap is None or self.data.con is None or col not in self.data.sample_cols:
            return []
        rs = _rows(self.data.con,
                   f"SELECT t, lapdist, {col} v FROM samples WHERE lap=? ORDER BY t", (lap,))
        if sidx is not None:
            L = self.data._by_id.get(lap, {})
            s1 = L.get("s1") or 0.0
            s2 = L.get("s2") or 0.0
            if sidx == 0:
                lo, hi = -1e9, s1
            elif sidx == 1:
                lo, hi = s1, s1 + s2
            else:
                lo, hi = s1 + s2, 1e9
            rs = [r for r in rs if r["t"] is not None and lo <= r["t"] < hi]
        xy = [(r["lapdist"], r["v"]) for r in rs
              if r["lapdist"] is not None and r["v"] is not None]
        # pulizia: ordina per distanza e scarta i campioni con lapdist che torna
        # indietro (leak dal bordo giro) -> niente più righe orizzontali spurie
        xy.sort(key=lambda p: p[0])
        clean = []
        last = None
        for x, v in xy:
            if last is None or x > last + 1e-6:
                clean.append((x, v)); last = x
        xy = clean
        if col in ("fuel", "ve") and xy:
            base = xy[0][1]                       # consumo progressivo: parte da 0 e sale
            xy = [(x, base - v) for x, v in xy]
        return xy

    @staticmethod
    def _chan(metric):
        """Canale campionato + scope settore per la traccia continua, o None."""
        m = metric.lower()
        sidx = int(metric[1]) - 1 if (metric[:1] == "S" and metric[1:2].isdigit()) else None
        if "tyre" in m or "brake" in m or "wear" in m or "press" in m:
            return None                       # -> torri (barre per-ruota)
        if "speed" in m:
            return ("speed", "km/h", sidx)
        if "fuel" in m:
            return ("fuel", "L", sidx)
        if m.startswith("ve ") or " ve " in m or m.startswith("ve("):
            return ("ve", "%", sidx)
        if "soc" in m:
            return ("soc", "%", sidx)
        if "regen" in m or "boost" in m:
            return ("regen_kw", "kW", sidx)
        return None                           # tempi -> linea settori

    def recolor(self):
        if self.tbl.horizontalHeaderItem(1):
            self.tbl.horizontalHeaderItem(1).setForeground(QBrush(QColor(_sel_col())))
        if self.tbl.horizontalHeaderItem(2):
            self.tbl.horizontalHeaderItem(2).setForeground(QBrush(QColor(_cmp_col(getattr(self, "_cmp_gold", False)))))
        if self.chart is not None:
            self.chart.update()
        if getattr(self, "map_w", None) is not None:
            self.map_w.update()

    def _bars_groups(self, metric):
        ua, ga = self._metric_vals(self._sel, metric)
        ub, gb = self._metric_vals(self._cmp, metric)
        unit = ua or ub
        labels = [l for l, _ in ga] or [l for l, _ in gb]
        am = dict(ga); bm = dict(gb)
        return unit, labels, [(l, am.get(l), bm.get(l)) for l in labels]

    def _refresh_chart(self):
        if self.chart is None:
            return
        metric = self._cur_metric()
        if metric is None:
            self.chart.clear(); return
        la = f"Lap {self._sel}" if self._sel is not None else "Selected"
        lb = f"Lap {self._cmp}" if self._cmp is not None else "Compare"
        m = metric.lower()
        # gomme / freni / usura / pressione -> torri (barre per-ruota)
        if "tyre" in m or "brake" in m or "wear" in m or "press" in m:
            unit, _, groups = self._bars_groups(metric)
            self.chart.set_bars(metric, unit, groups, la, lb)
            return
        # tutto il resto -> traccia continua (ritagliata al settore se per-settore)
        spec = self._chan(metric)
        if spec is not None:
            col, unit, sidx = spec
            sa = self._trace(self._sel, col, sidx)
            sb = self._trace(self._cmp, col, sidx)
            if sa or sb:
                self.chart.set_data(metric, unit, sa, sb, la, lb, xlabels=None)
                return
        # fallback (canale non campionato nel file) / tempi -> linea sui settori
        unit, labels, groups = self._bars_groups(metric)
        am = {l: a for l, a, _ in groups}; bm = {l: b for l, _, b in groups}
        sa = [(i, am[l]) for i, l in enumerate(labels) if am.get(l) is not None]
        sb = [(i, bm[l]) for i, l in enumerate(labels) if bm.get(l) is not None]
        self.chart.set_data(metric, unit, sa, sb, la, lb, xlabels=labels)

    def _mark_fastest(self):
        """Best assoluto dello stint in fuxia (identico alla lista Stint): miglior
        tempo e migliori settori, su qualunque colonna li mostri."""
        best = self.data.best_dict()
        keymap = {"Time": "lap_time", "Sector 1": "s1", "Sector 2": "s2", "Sector 3": "s3"}
        for r, name in enumerate(self.metrics):
            key = keymap.get(name)
            if not key:
                continue
            bv = best.get(key)
            for col, lap in ((1, self._sel), (2, self._cmp)):
                it = self.tbl.item(r, col)
                if it is None:
                    continue
                v = (self.data._by_id.get(lap, {}) or {}).get(key)
                it.setForeground(QBrush(QColor(_FUX if _is_b(v, bv) else "#ffffff")))

    def _fill(self, col, lap):
        res = self.data.values(lap)
        for r, name in enumerate(self.metrics):
            v = None if res is None else res[0].get(name)
            if isinstance(v, dict):                       # riga per-ruota
                self.tbl.setItem(r, col, QTableWidgetItem(""))
                self.tbl.setCellWidget(r, col, _wheel_widget(v))
                continue
            self.tbl.removeCellWidget(r, col)
            if res is None:
                it = QTableWidgetItem("")
            else:
                _, best = res
                text = "" if (name == "Stint" and col == 2) else v
                it = QTableWidgetItem(text if text is not None else "")
                it.setForeground(QBrush(QColor(_FUCHSIA if best.get(name) else "#ffffff")))
            if name in ("Stint", "Lap", "Valid"):
                it.setFlags(it.flags() & ~Qt.ItemIsSelectable)
            self.tbl.setItem(r, col, it)
        self.tbl.resizeRowsToContents()


class EnergiaView(QWidget):
    def __init__(self):
        super().__init__()
        self.con = None
        lay = QVBoxLayout(self)
        self.lbl = QLabel(""); lay.addWidget(self.lbl)
        self.ch = LineChart(); lay.addWidget(self.ch)

    def set_stint(self, laps, car_class):
        xs = [L["lap"] for L in laps]
        series = [("Fuel/lap (L)", [L["fuel_used"] for L in laps], QColor("#ffb74d")),
                  ("VE/lap (%)", [L["ve_used"] for L in laps], QColor("#4fc3f7"))]
        if _is_hybrid(car_class) and laps and self.con is not None:
            lo, hi = laps[0]["lap"], laps[-1]["lap"]
            regs = _rows(self.con, "SELECT lap, AVG(regen_kwh) g FROM sectors "
                                   "WHERE lap BETWEEN ? AND ? GROUP BY lap", (lo, hi))
            rmap = {r["lap"]: r["g"] for r in regs}
            series.append(("Regen (kW)", [rmap.get(x) for x in xs], QColor("#00e676")))
            self.lbl.setText("Classe ibrida: incluso regen.")
        else:
            self.lbl.setText("Solo fuel/VE.")
        self.ch.set_data(xs, series)


class GommeView(QWidget):
    def __init__(self):
        super().__init__()
        self.con = None
        lay = QVBoxLayout(self)
        self.tbl = QTableWidget()
        self.tbl.setColumnCount(5)
        self.tbl.setHorizontalHeaderLabels(["", "FL", "FR", "RL", "RR"])
        self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.tbl.verticalHeader().setVisible(False)
        self.tbl.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tbl.setSelectionMode(QAbstractItemView.NoSelection)
        self.tbl.setFocusPolicy(Qt.NoFocus)
        lay.addWidget(self.tbl)

    def set_lap(self, lap):
        if lap is None or self.con is None:
            self.tbl.setRowCount(0); return
        secs = _rows(self.con, "SELECT * FROM sectors WHERE lap=? ORDER BY sector", (lap,))
        rows = []
        for s in secs:
            rows.append((f"S{s['sector']+1} temp", [s["t_fl"], s["t_fr"], s["t_rl"], s["t_rr"]], 60, 120, True))
            rows.append((f"S{s['sector']+1} freno", [s["b_fl"], s["b_fr"], s["b_rl"], s["b_rr"]], 100, 700, True))
            rows.append((f"S{s['sector']+1} usura", [s["w_fl"], s["w_fr"], s["w_rl"], s["w_rr"]], 0, 100, False))
        self.tbl.setRowCount(len(rows))
        for r, (lbl, vals, lo, hi, color) in enumerate(rows):
            self.tbl.setItem(r, 0, QTableWidgetItem(lbl))
            for c, v in enumerate(vals):
                it = QTableWidgetItem("\u2014" if v is None else f"{v:.1f}")
                if v is not None and color:
                    it.setForeground(QBrush(_heat(v, lo, hi)))
                self.tbl.setItem(r, c + 1, it)


class GuidaView(QWidget):
    def __init__(self):
        super().__init__()
        self.con = None
        lay = QVBoxLayout(self)
        self.c_in = LineChart(); self.c_sp = LineChart()
        lay.addWidget(self.c_in); lay.addWidget(self.c_sp)

    def set_lap(self, lap):
        if lap is None or self.con is None:
            self.c_in.set_data([], []); self.c_sp.set_data([], []); return
        s = _rows(self.con, "SELECT lapdist, throttle, brake, steer, speed "
                            "FROM samples WHERE lap=? ORDER BY t", (lap,))
        xs = [r["lapdist"] for r in s]
        self.c_in.set_data(xs, [
            ("Throttle", [r["throttle"] for r in s], QColor("#00e676")),
            ("Brake", [r["brake"] for r in s], QColor("#ff3b30")),
            ("Steer", [r["steer"] for r in s], QColor("#a7aaaf"))])
        self.c_sp.set_data(xs, [("Speed (km/h)", [r["speed"] for r in s], QColor(_ACCENT))])


class MappaView(QWidget):
    def __init__(self):
        super().__init__()
        self.con = None
        lay = QVBoxLayout(self)
        lay.addWidget(QLabel("Color = speed"))
        self.view = TrajectoryView()
        lay.addWidget(self.view)

    def set_lap(self, lap):
        if lap is None or self.con is None:
            self.view.set_path([]); return
        s = _rows(self.con, "SELECT pos_x, pos_z, speed FROM samples WHERE lap=? ORDER BY t", (lap,))
        self.view.set_path([(r["pos_x"], r["pos_z"], r["speed"]) for r in s
                            if r["pos_x"] is not None and r["pos_z"] is not None])


# ── finestra ──────────────────────────────────────────────────────────────

# ── LIVE: dati stint corrente in tempo reale dal reader ──────────────────────
class _LiveSpeedChart(QWidget):
    """Velocità live del giro corrente vs distanza, marker settori + top/sett."""
    def __init__(self):
        super().__init__()
        self._pts = []           # [(lapdist, speed)]
        self._sec_dist = []      # confini settore [d1, d2]
        self._tops = [0.0, 0.0, 0.0]
        self.setMinimumHeight(280)

    def set(self, pts, sec_dist, tops):
        self._pts = pts or []
        self._sec_dist = [d for d in (sec_dist or []) if d]
        self._tops = tops or [0.0, 0.0, 0.0]
        self.update()

    def paintEvent(self, e):
        p = QPainter(self); p.setRenderHint(QPainter.Antialiasing, True)
        p.fillRect(self.rect(), QColor("#0d0e0f"))
        W, H = self.width(), self.height()
        ml, mr, mt, mb = 46, 14, 30, 24
        gw, gh = W - ml - mr, H - mt - mb
        f = p.font(); f.setPointSize(8); p.setFont(f)
        if len(self._pts) < 2:
            p.setPen(QColor("#60636c"))
            p.drawText(self.rect(), Qt.AlignCenter, "in attesa dei dati\u2026")
            p.end(); return
        xs = [x for x, _ in self._pts]; ys = [y for _, y in self._pts]
        xmin, xmax = min(xs), max(xs)
        ymin, ymax = min(ys), max(ys)
        if xmax <= xmin:
            xmax = xmin + 1.0
        ymin = max(0.0, ymin - 8.0); ymax = ymax + 8.0
        if ymax <= ymin:
            ymax = ymin + 1.0

        def X(v):
            return ml + gw * (v - xmin) / (xmax - xmin)

        def Y(v):
            return mt + gh * (1.0 - (v - ymin) / (ymax - ymin))

        for i in range(5):
            yy = int(mt + gh * i / 4)
            p.setPen(QPen(QColor("#24252a"), 1)); p.drawLine(ml, yy, W - mr, yy)
            val = ymax - (ymax - ymin) * i / 4
            p.setPen(QColor("#7e828c")); p.drawText(6, yy + 4, f"{val:.0f}")
        p.setPen(QColor("#7e828c")); p.drawText(6, mt - 8, "km/h")

        for d in self._sec_dist:
            if xmin <= d <= xmax:
                xx = int(X(d))
                p.setPen(QPen(QColor("#3a3d43"), 1, Qt.DashLine))
                p.drawLine(xx, mt, xx, mt + gh)

        labels = ["S1", "S2", "S3"]
        bounds = [xmin] + list(self._sec_dist) + [xmax]
        p.setPen(QColor("#a6a9af"))
        for i in range(3):
            if i + 1 < len(bounds):
                cx = (bounds[i] + bounds[i + 1]) / 2.0
                top = self._tops[i] if i < len(self._tops) else 0.0
                txt = f"{labels[i]}  {top:.0f}" if top else labels[i]
                tw = p.fontMetrics().horizontalAdvance(txt)
                if xmin <= cx <= xmax:
                    p.drawText(QPointF(X(cx) - tw / 2, mt + 12), txt)

        poly = QPolygonF([QPointF(X(x), Y(y)) for x, y in self._pts])
        p.setPen(QPen(QColor(_SEL_COL), 2)); p.setBrush(Qt.NoBrush)
        p.drawPolyline(poly)
        cx, cy = self._pts[-1]
        p.setBrush(QColor(_SEL_COL)); p.setPen(Qt.NoPen)
        p.drawEllipse(QPointF(X(cx), Y(cy)), 4, 4)
        p.end()


class LiveView(QWidget):
    """Vista live: legge il reader e mostra lo stint corrente in tempo reale."""
    _WH = ("FL", "FR", "RL", "RR")

    def __init__(self, on_back):
        super().__init__()
        self._on_back = on_back
        try:
            self._reader = TelemetryReader()
        except Exception:
            self._reader = None
        self._map_reader = None
        if _RealMapReader is not None:
            try:
                self._map_reader = _RealMapReader()
            except Exception:
                self._map_reader = None
        self._timer = QTimer(self); self._timer.setInterval(250)
        self._timer.timeout.connect(self._poll)
        self._reset_state()

        root = QVBoxLayout(self)
        top = QHBoxLayout()
        self.btn_back = QPushButton("\u2039 Review"); self.btn_back.setObjectName("backBtn")
        self.btn_back.setCursor(Qt.PointingHandCursor)
        self.btn_back.clicked.connect(self._on_back)
        top.addWidget(self.btn_back)
        self.lbl_state = QLabel("\u25cf  LIVE")
        self.lbl_state.setStyleSheet("color:#ff5b6e;font-weight:600;")
        top.addSpacing(10); top.addWidget(self.lbl_state)
        self.lbl_info = QLabel(""); self.lbl_info.setStyleSheet("color:#989ba2;")
        top.addSpacing(14); top.addWidget(self.lbl_info)
        top.addStretch()
        self.btn_clear = QPushButton("Reset stint"); self.btn_clear.setObjectName("backBtn")
        self.btn_clear.setCursor(Qt.PointingHandCursor)
        self.btn_clear.clicked.connect(self._reset_ui)
        top.addWidget(self.btn_clear)
        root.addLayout(top)

        self.tabs = QTabWidget()
        self._build_times()
        self._build_speed()
        self._build_ve()
        self._build_energy()
        self._build_tyres()
        self._build_stint()
        root.addWidget(self.tabs)

    # ── ciclo ──
    def start(self):
        self._timer.start(); self._poll()

    def stop(self):
        self._timer.stop()

    # ── stato ──
    def _reset_state(self):
        self._laps_done = None
        self._lapno = None
        self._sector = None
        self._spd_pts = []
        self._ped_pts = []
        self._pos_pts = []
        self._sec_top = [0.0, 0.0, 0.0]
        self._sec_dist = [None, None]
        self._lap_ve0 = None
        self._lap_fuel0 = None
        self._sec_ve = [None, None, None]
        self._sec_fuel = [None, None, None]
        self._cur_sec_ve0 = None
        self._cur_sec_fuel0 = None
        self._sec_regen = [0.0, 0.0, 0.0]
        self._sec_boost = [0.0, 0.0, 0.0]
        self._cur_regen = 0.0
        self._cur_boost = 0.0
        self._lap_regen = 0.0
        self._lap_boost = 0.0
        self._prev_et = None
        self._garage_seen = False
        self._laps = []
        self._track_pts = []

    def _reset_ui(self):
        self._reset_state()
        self._tbl_stint.setRowCount(0)
        self._poll()

    # ── costruzione tab ──
    def _grid(self, rows, cols):
        """rows: lista nomi riga. cols: header colonne. Ritorna (widget, cells dict)."""
        w = QWidget(); g = QGridLayout(w)
        g.setContentsMargins(16, 14, 16, 14); g.setHorizontalSpacing(28); g.setVerticalSpacing(12)
        for c, h in enumerate(cols):
            lab = QLabel(h); lab.setStyleSheet("color:#989ba2;font-weight:600;")
            g.addWidget(lab, 0, c + 1)
        cells = {}
        for r, name in enumerate(rows):
            rl = QLabel(name); rl.setStyleSheet("color:#dcdddf;")
            g.addWidget(rl, r + 1, 0)
            for c in range(len(cols)):
                v = QLabel("\u2014"); v.setStyleSheet(f"color:{_FG};font-size:18px;")
                g.addWidget(v, r + 1, c + 1)
                cells[(r, c)] = v
        g.setRowStretch(len(rows) + 1, 1)
        return w, cells

    def _build_times(self):
        w = QWidget(); v = QVBoxLayout(w); v.setContentsMargins(0, 0, 0, 0)
        grid, self._c_times = self._grid(
            ["Last", "Best", "Average", "Current"],
            ["Lap", "S1", "S2", "S3"])
        v.addWidget(grid)
        cap = QLabel("Pedals + position  ·  current lap"); cap.setStyleSheet("color:#989ba2;padding:4px 16px 0;")
        v.addWidget(cap)
        roww = QWidget(); rowl = QHBoxLayout(roww); rowl.setContentsMargins(0, 0, 0, 0)
        self.chart_ped = _PedalChart()
        self.chart_map = _LiveMap()          # mappa normale (tracciato registrato)
        self._real_map = False
        rowl.addWidget(self.chart_ped, 2)        # pedali 2/3
        rowl.addWidget(self.chart_map, 1)        # mappa 1/3
        v.addWidget(roww, 1)
        self.tabs.addTab(w, "Times")

    def _build_speed(self):
        w = QWidget(); v = QVBoxLayout(w)
        self.chart_speed = _LiveSpeedChart()
        v.addWidget(self.chart_speed)
        row = QHBoxLayout()
        self._spd_top = {}
        for i, s in enumerate(("S1", "S2", "S3")):
            cap = QLabel(f"Top {s}:"); cap.setStyleSheet("color:#989ba2;")
            val = QLabel("\u2014"); val.setStyleSheet(f"color:{_FG};font-weight:600;")
            row.addWidget(cap); row.addWidget(val); row.addSpacing(18)
            self._spd_top[i] = val
        row.addStretch()
        v.addLayout(row)
        self.tabs.addTab(w, "Speed")

    def _build_ve(self):
        w, self._c_ve = self._grid(["VE used (%)", "Fuel used (L)"],
                                   ["Lap", "S1", "S2", "S3"])
        self.tabs.addTab(w, "VE / Fuel")

    def _build_energy(self):
        w, self._c_en = self._grid(["SOC (%)", "Regen (kWh)", "Boost (kWh)"],
                                   ["Now/Lap", "S1", "S2", "S3"])
        self.tabs.addTab(w, "Energy")

    def _build_tyres(self):
        w, self._c_tyre = self._grid(
            ["Carcass \u00b0C", "Tread \u00b0C", "Layer \u00b0C", "Pressure kPa",
             "Brake \u00b0C", "Wear %"],
            list(self._WH))
        self.tabs.addTab(w, "Tyres")

    def _build_stint(self):
        w = QWidget(); v = QVBoxLayout(w)
        self._tbl_stint = QTableWidget(); self._tbl_stint.setColumnCount(7)
        self._tbl_stint.setHorizontalHeaderLabels(
            ["Lap", "Time", "S1", "S2", "S3", "VE %", "Fuel L"])
        self._tbl_stint.verticalHeader().setVisible(False)
        self._tbl_stint.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self._tbl_stint.setSelectionMode(QAbstractItemView.NoSelection)
        self._tbl_stint.setFocusPolicy(Qt.NoFocus)
        self._tbl_stint.setShowGrid(False); self._tbl_stint.setAlternatingRowColors(True)
        hh = self._tbl_stint.horizontalHeader()
        hh.setSectionResizeMode(QHeaderView.Stretch)
        v.addWidget(self._tbl_stint)
        self.tabs.addTab(w, "Stint")

    # ── poll ──
    def _poll(self):
        if self._reader is None:
            self.lbl_info.setText("reader non disponibile")
            return
        try:
            d = self._reader.read()
        except Exception:
            d = None
        if not d:
            self.lbl_info.setText("no telemetry (game not running)")
            return
        garage = bool(d.get("garage"))
        if garage:
            self._garage_seen = True
        elif self._garage_seen:
            self._garage_seen = False
            self._reset_state()
            self._tbl_stint.setRowCount(0)

        lapno = int(d.get("lap_number", 0) or 0)
        laps_done = int(d.get("laps_completed", 0) or 0)
        sector = int(d.get("sector", 0) or 0)
        lapdist = d.get("lapdist")
        speed = d.get("speed") or 0.0
        ve = d.get("ve_pct")
        fuel = d.get("fuel")
        et = d.get("elapsed")

        if self._laps_done is None:
            self._laps_done = laps_done
        if self._lapno is None:
            self._lapno = lapno
            self._init_lap(ve, fuel, sector)

        si = min(max(sector, 0), 2)

        # cambio settore -> salva consumi/energia settore chiuso
        if sector != self._sector:
            ps = min(max(self._sector or 0, 0), 2)
            if self._cur_sec_ve0 is not None and ve is not None:
                self._sec_ve[ps] = self._cur_sec_ve0 - ve
            if self._cur_sec_fuel0 is not None and fuel is not None:
                self._sec_fuel[ps] = self._cur_sec_fuel0 - fuel
            self._sec_regen[ps] = self._cur_regen
            self._sec_boost[ps] = self._cur_boost
            if self._sector == 0:
                self._sec_dist[0] = lapdist
            elif self._sector == 1:
                self._sec_dist[1] = lapdist
            self._cur_sec_ve0 = ve
            self._cur_sec_fuel0 = fuel
            self._cur_regen = 0.0
            self._cur_boost = 0.0
            self._sector = sector

        # accumula
        if lapdist is not None:
            self._spd_pts.append((lapdist, speed))
            self._ped_pts.append((lapdist, d.get("throttle") or 0.0, d.get("brake") or 0.0))
        px, pz = d.get("pos_x"), d.get("pos_z")
        if px is not None and pz is not None:
            self._pos_pts.append((px, pz))
        self._sec_top[si] = max(self._sec_top[si], speed)
        if et is not None and self._prev_et is not None:
            dt = et - self._prev_et
            if 0.0 < dt < 0.5:
                rk = float(d.get("regen_kw", 0.0) or 0.0)
                e = abs(rk) * dt / 3600.0
                if rk > 0:
                    self._cur_regen += e; self._lap_regen += e
                elif rk < 0:
                    self._cur_boost += e; self._lap_boost += e
        self._prev_et = et

        # giro completato (laps_completed sale) -> chiudi giro POI reset buffer
        if laps_done > self._laps_done:
            self._finish_lap(d)
            self._laps_done = laps_done
            self._lapno = lapno
            self._init_lap(ve, fuel, sector)

        self._refresh(d)

    def _init_lap(self, ve, fuel, sector):
        if len(self._pos_pts) > 10:        # conserva il tracciato del giro appena chiuso
            self._track_pts = list(self._pos_pts)
        self._spd_pts = []
        self._ped_pts = []
        self._pos_pts = []
        self._sec_top = [0.0, 0.0, 0.0]
        self._sec_dist = [None, None]
        self._lap_ve0 = ve
        self._lap_fuel0 = fuel
        self._sec_ve = [None, None, None]
        self._sec_fuel = [None, None, None]
        self._cur_sec_ve0 = ve
        self._cur_sec_fuel0 = fuel
        self._sec_regen = [0.0, 0.0, 0.0]
        self._sec_boost = [0.0, 0.0, 0.0]
        self._cur_regen = 0.0
        self._cur_boost = 0.0
        self._lap_regen = 0.0
        self._lap_boost = 0.0
        self._prev_et = None
        self._sector = sector

    def _finish_lap(self, d):
        lt = d.get("last_lap") or 0.0
        s1 = d.get("last_s1") or 0.0
        s2c = d.get("last_s2") or 0.0
        sec1 = s1 if s1 else None
        sec2 = (s2c - s1) if (s2c and s1) else None
        sec3 = (lt - s2c) if (lt and s2c) else None
        ve_used = (self._lap_ve0 - d.get("ve_pct")) if (self._lap_ve0 is not None and d.get("ve_pct") is not None) else None
        fuel_used = (self._lap_fuel0 - d.get("fuel")) if (self._lap_fuel0 is not None and d.get("fuel") is not None) else None
        rec = {"lap": int(d.get("laps_completed", 0) or 0), "time": lt,
               "s1": sec1, "s2": sec2, "s3": sec3,
               "ve": ve_used, "fuel": fuel_used}
        self._laps.append(rec)
        self._append_stint_row(rec)

    def _append_stint_row(self, rec):
        t = self._tbl_stint
        r = t.rowCount(); t.insertRow(r)
        vals = [str(rec["lap"]), _fmt(rec["time"]),
                _fmt(rec["s1"]), _fmt(rec["s2"]), _fmt(rec["s3"]),
                ("\u2014" if rec["ve"] is None else f"{rec['ve']:.2f}"),
                ("\u2014" if rec["fuel"] is None else f"{rec['fuel']:.2f}")]
        for c, v in enumerate(vals):
            it = QTableWidgetItem(v)
            if c == 0:
                it.setForeground(QBrush(QColor(_ACCENT)))
            t.setItem(r, c, it)
        t.scrollToBottom()

    # ── refresh display ──
    def _refresh(self, d):
        track = d.get("track", "") or ""
        self.lbl_info.setText(f"{track}   ·   Lap {self._lapno}   ·   S{min(max((self._sector or 0)+1,1),3)}")

        # Times
        valid = [L for L in self._laps if (L["time"] or 0) > 0]
        best = min((L["time"] for L in valid), default=None)
        avg = (sum(L["time"] for L in valid) / len(valid)) if valid else None
        last = self._laps[-1] if self._laps else None
        cur_t = None
        if d.get("elapsed") is not None and d.get("lap_start_et"):
            cur_t = d["elapsed"] - d["lap_start_et"]
        rowdata = {
            0: [last["time"] if last else None, last["s1"] if last else None,
                last["s2"] if last else None, last["s3"] if last else None],   # Last
            1: [best, None, None, None],                                       # Best
            2: [avg, None, None, None],                                        # Average
            3: [cur_t, d.get("cur_s1") or None, None, None],                   # Current
        }
        for r in range(4):
            for c in range(4):
                v = rowdata[r][c]
                self._c_times[(r, c)].setText(_fmt(v) if v else "\u2014")

        # Speed
        self.chart_speed.set(self._spd_pts, self._sec_dist, self._sec_top)
        self.chart_ped.set_live(self._ped_pts, self._sec_dist)
        if self._real_map:
            md = None
            if self._map_reader is not None:
                try:
                    md = self._map_reader.read()
                except Exception:
                    md = None
            if md:
                self.chart_map.set_data(
                    md.get("track", ""), md.get("cars"), md.get("player"),
                    md.get("sector_flags"), md.get("player_sector"),
                    md.get("yellow_active", False), md.get("my_dist", 0.0),
                    md.get("track_len", 0.0), md.get("yellow_bands"))
        else:
            self.chart_map.set_svg(d.get("track"))
            self.chart_map.set_driver(class_tag(d.get("car_class") or ""), "")
            self.chart_map.set_path(self._track_pts if self._track_pts else self._pos_pts)
            px, pz = d.get("pos_x"), d.get("pos_z")
            if px is not None and pz is not None:
                self.chart_map.set_marker((px, pz))
        for i in range(3):
            tp = self._sec_top[i]
            self._spd_top[i].setText(f"{tp:.0f} km/h" if tp else "\u2014")

        # VE / Fuel (lap progressivo + settori)
        ve = d.get("ve_pct"); fuel = d.get("fuel")
        lap_ve = (self._lap_ve0 - ve) if (self._lap_ve0 is not None and ve is not None) else None
        lap_fuel = (self._lap_fuel0 - fuel) if (self._lap_fuel0 is not None and fuel is not None) else None
        sec_ve = list(self._sec_ve)
        sec_fuel = list(self._sec_fuel)
        cs = min(max(self._sector or 0, 0), 2)
        if self._cur_sec_ve0 is not None and ve is not None:
            sec_ve[cs] = self._cur_sec_ve0 - ve
        if self._cur_sec_fuel0 is not None and fuel is not None:
            sec_fuel[cs] = self._cur_sec_fuel0 - fuel
        self._c_ve[(0, 0)].setText(self._f2(lap_ve))
        self._c_ve[(1, 0)].setText(self._f2(lap_fuel))
        for i in range(3):
            self._c_ve[(0, i + 1)].setText(self._f2(sec_ve[i]))
            self._c_ve[(1, i + 1)].setText(self._f2(sec_fuel[i]))

        # Energy
        soc = d.get("soc")
        sec_regen = list(self._sec_regen); sec_regen[cs] = self._cur_regen
        sec_boost = list(self._sec_boost); sec_boost[cs] = self._cur_boost
        self._c_en[(0, 0)].setText(self._f1(soc))
        self._c_en[(1, 0)].setText(self._f2(self._lap_regen))
        self._c_en[(2, 0)].setText(self._f2(self._lap_boost))
        for i in range(3):
            self._c_en[(0, i + 1)].setText("\u2014")
            self._c_en[(1, i + 1)].setText(self._f2(sec_regen[i]))
            self._c_en[(2, i + 1)].setText(self._f2(sec_boost[i]))

        # Tyres (valori correnti per ruota)
        carc = d.get("tyre_carcass") or [None] * 4
        surf = d.get("tyre_surf") or [None] * 4
        inner = d.get("tyre_inner") or [None] * 4
        press = d.get("tyre_press") or [None] * 4
        brk = d.get("brake_temp") or [None] * 4
        wear = d.get("tyre_wear") or [None] * 4

        def m3(v):
            if not v:
                return None
            xs = [x for x in v if x is not None]
            return sum(xs) / len(xs) if xs else None
        for c in range(4):
            self._c_tyre[(0, c)].setText(self._f0(carc[c] if c < len(carc) else None))
            self._c_tyre[(1, c)].setText(self._f0(m3(surf[c]) if c < len(surf) else None))
            self._c_tyre[(2, c)].setText(self._f0(m3(inner[c]) if c < len(inner) else None))
            self._c_tyre[(3, c)].setText(self._f0(press[c] if c < len(press) else None))
            self._c_tyre[(4, c)].setText(self._f0(brk[c] if c < len(brk) else None))
            self._c_tyre[(5, c)].setText(self._f1(wear[c] if c < len(wear) else None))

    @staticmethod
    def _f0(v):
        return "\u2014" if v is None else f"{v:.0f}"

    @staticmethod
    def _f1(v):
        return "\u2014" if v is None else f"{v:.1f}"

    @staticmethod
    def _f2(v):
        return "\u2014" if v is None else f"{v:.2f}"


def _ov_session_label(st):
    try:
        st = int(st)
    except Exception:
        return "Session"
    if st <= 0:
        return "Test Day"
    if 1 <= st <= 4:
        return "Practice"
    if 5 <= st <= 8:
        return "Qualify"
    if st == 9:
        return "Warmup"
    return "Race"


def _ov_clock(s):
    s = int(s); h = s // 3600; m = (s % 3600) // 60; sec = s % 60
    return f"{h}:{m:02d}:{sec:02d}" if h else f"{m:02d}:{sec:02d}"


def _fmt_session_len(s):
    """Durata impostata della sessione: '6h', '10m', '1h30m'."""
    if not s or s <= 0:
        return ""
    s = int(round(s)); h = s // 3600; m = (s % 3600) // 60
    if h:
        return f"{h}h{m:02d}m" if m else f"{h}h"
    if m:
        return f"{m}m"
    return f"{s}s"


_OV_TRACKMAP_DIR = Path(__file__).resolve().parent.parent / "settings" / "trackmap"
_ov_trackmap_idx = None


def _ov_trackmap_file(track):
    """Risolve l'SVG della pista in settings/trackmap per nome (match esatto o approssimato)."""
    global _ov_trackmap_idx
    if not track:
        return None
    if _ov_trackmap_idx is None:
        import re
        idx = {}
        try:
            for f in _OV_TRACKMAP_DIR.glob("*.svg"):
                name = re.sub(r"#U([0-9a-fA-F]{4})",
                              lambda m: chr(int(m.group(1), 16)), f.stem)
                idx[name] = f
        except Exception:
            idx = {}
        _ov_trackmap_idx = idx
    if track in _ov_trackmap_idx:
        return _ov_trackmap_idx[track]
    tl = track.lower()
    for name, f in _ov_trackmap_idx.items():
        nl = name.lower()
        if tl in nl or nl in tl:
            return f
    return None


# Etichetta leggibile del LAYOUT per le descrizioni sessione. Chiavi = stem SVG
# in settings/trackmap (un SVG per layout). "" = layout principale del circuito.
_LAYOUT_LABELS = {
    "Monza Curva Grande Circuit": "Curva Grande",
    "Bahrain Outer Circuit": "Outer",
    "Bahrain Paddock Circuit": "Paddock",
    "Circuit de Spa-Francorchamps Endurance": "Endurance",
    "Fuji Speedway Classic": "Classic",
    "Lusail Short Circuit": "Short",
    "Sebring School Circuit": "School",
    "Circuit de la Sarthe Mulsanne": "Mulsanne",
    "24 Heures du Mans 2022": "2022",
    "Paul Ricard - ELMS": "ELMS",
    "Silverstone Grand Prix Circuit - ELMS": "ELMS",
}


def _track_layout_label(track):
    """Variante di layout leggibile (es. 'Curva Grande', 'Outer'), '' se layout
    principale. Risolta dallo stem SVG del trackmap (un SVG per layout)."""
    p = _ov_trackmap_file(track)
    if not p:
        return ""
    import re
    stem = re.sub(r"#U([0-9a-fA-F]{4})",
                  lambda m: chr(int(m.group(1), 16)), p.stem)
    return _LAYOUT_LABELS.get(stem, "")


_trackmap_white_cache = {}


def _trackmap_white_bytes(track):
    """SVG del tracciato (settings/trackmap) ricolorato in BIANCO, come bytes.
    None se non trovato."""
    p = _ov_trackmap_file(track)
    if not p:
        return None
    key = str(p)
    cached = _trackmap_white_cache.get(key, 0)
    if cached != 0:
        return cached
    try:
        txt = p.read_text(encoding="utf-8", errors="replace")
        txt = txt.replace('stroke="black"', 'stroke="#ffffff"') \
                 .replace('stroke="#000000"', 'stroke="#ffffff"') \
                 .replace('stroke="#000"', 'stroke="#ffffff"')
        import re as _re
        txt = _re.sub(r'stroke-width="[\d.]+"', 'stroke-width="34"', txt)
        out = txt.encode("utf-8")
    except Exception:
        out = None
    _trackmap_white_cache[key] = out
    return out


_TRACK_ROT_JSON = _OV_TRACKMAP_DIR.parent / "trackmap_rot.json"
_track_rot_map = None


def _track_rot(track):
    """Rotazione (gradi) del tracciato per la pista, da settings/trackmap_rot.json
    (chiave = stem SVG del layout). 0 se assente."""
    global _track_rot_map
    if _track_rot_map is None:
        import json
        try:
            _track_rot_map = json.loads(_TRACK_ROT_JSON.read_text(encoding="utf-8"))
        except Exception:
            _track_rot_map = {}
    p = _ov_trackmap_file(track)
    if not p:
        return 0.0
    import re
    stem = re.sub(r"#U([0-9a-fA-F]{4})",
                  lambda m: chr(int(m.group(1), 16)), p.stem)
    try:
        return float(_track_rot_map.get(stem, 0))
    except Exception:
        return 0.0


_SVG_RENDERER_CACHE = {}


class _SvgBox(QWidget):
    """Render di un SVG mantenendo le proporzioni (centrato).
    Renderer condiviso per sorgente + render messo in cache come QPixmap
    (ri-renderizza solo quando cambia sorgente o dimensione)."""
    def __init__(self, min_h=0):
        super().__init__()
        self._r = None
        self._pix = None
        self._pix_key = None
        if min_h:
            self.setMinimumHeight(min_h)

    def load(self, src):
        if QSvgRenderer is None:
            return
        if not src or (not isinstance(src, (bytes, bytearray)) and not str(src).strip()):
            self.clear(); return        # niente percorso -> evita "filename is empty"
        key = bytes(src) if isinstance(src, (bytes, bytearray)) else str(src)
        r = _SVG_RENDERER_CACHE.get(key)
        if r is None:
            try:
                r = QSvgRenderer(QByteArray(bytes(src))) if isinstance(src, (bytes, bytearray)) \
                    else QSvgRenderer(str(src))
                if not r.isValid():
                    r = None
            except Exception:
                r = None
            if r is not None:
                _SVG_RENDERER_CACHE[key] = r
        self._r = r
        self._pix = None; self._pix_key = None
        self.update()

    def clear(self):
        self._r = None
        self._pix = None; self._pix_key = None
        self.update()

    def paintEvent(self, e):
        if self._r is None:
            return
        W, H = self.width(), self.height()
        if W <= 0 or H <= 0:
            return
        dpr = self.devicePixelRatioF()
        key = (W, H, round(dpr, 3), id(self._r))
        if self._pix is None or self._pix_key != key:
            ds = self._r.defaultSize()
            dw = ds.width() or 1; dh = ds.height() or 1
            s = min(W / dw, H / dh)
            w = dw * s; h = dh * s
            pix = QPixmap(max(1, int(W * dpr)), max(1, int(H * dpr)))
            pix.setDevicePixelRatio(dpr)
            pix.fill(Qt.transparent)
            pp = QPainter(pix); pp.setRenderHint(QPainter.Antialiasing, True)
            self._r.render(pp, QRectF((W - w) / 2.0, (H - h) / 2.0, w, h))
            pp.end()
            self._pix = pix; self._pix_key = key
        p = QPainter(self)
        p.drawPixmap(0, 0, self._pix)
        p.end()


class _TrackMapBox(_SvgBox):
    """Come _SvgBox ma con rotazione: ruota attorno al centro e adatta alla bbox
    ruotata, così non si stira MAI e non viene tagliato."""
    def __init__(self, rot=0.0, min_h=0):
        super().__init__(min_h)
        self._rot = float(rot or 0.0)

    def paintEvent(self, e):
        if self._r is None:
            return
        W, H = self.width(), self.height()
        if W <= 0 or H <= 0:
            return
        import math
        ds = self._r.defaultSize()
        dw = ds.width() or 1; dh = ds.height() or 1
        a = math.radians(self._rot)
        rw = abs(dw * math.cos(a)) + abs(dh * math.sin(a))
        rh = abs(dw * math.sin(a)) + abs(dh * math.cos(a))
        s = min(W / rw, H / rh) if (rw and rh) else 1.0
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.translate(W / 2.0, H / 2.0)
        p.rotate(self._rot)
        p.scale(s, s)
        self._r.render(p, QRectF(-dw / 2.0, -dh / 2.0, dw, dh))
        p.end()


_OV_TRACKLOGO_DIR = Path(__file__).resolve().parent.parent / "assets" / "tracklogos"
_OV_TRACKMAPS_SVG_DIR = Path(__file__).resolve().parent.parent / "assets" / "trackmaps_svg"


def _track_styled_svg(track):
    """SVG mappa in stile (gradiente + linea centrale) per il LAYOUT, già
    orientata. None se non disponibile."""
    p = _ov_trackmap_file(track)
    if not p:
        return None
    cand = _OV_TRACKMAPS_SVG_DIR / p.name
    return cand if cand.exists() else None


# Layout "varianti" di un circuito base: descrizione in card con accent arancione.
_ALT_LAYOUT_STEMS = {
    "Monza Curva Grande Circuit", "Bahrain Outer Circuit", "Bahrain Paddock Circuit",
    "Circuit de Spa-Francorchamps Endurance", "Circuit de la Sarthe Mulsanne",
    "24 Heures du Mans 2022", "Fuji Speedway Classic",
    "Lusail Short Circuit", "Sebring School Circuit",
}


def _track_is_alt(track):
    """True se la pista è un layout alternativo (variante di un circuito base)."""
    p = _ov_trackmap_file(track)
    if not p:
        return False
    import re
    stem = re.sub(r"#U([0-9a-fA-F]{4})", lambda m: chr(int(m.group(1), 16)), p.stem)
    return stem in _ALT_LAYOUT_STEMS

_OV_TRACKMAPS_PNG_DIR = Path(__file__).resolve().parent.parent / "assets" / "trackmaps"

# alias nome pista -> file PNG (mappe "belle" già orientate). Sottostringa nel
# nome in-gioco. Monza/Sebring non hanno PNG: fallback all'SVG.
_TRACK_PNG_ALIASES = (
    ("monza", "monza"),
    ("sebring", "sebring"),
    ("spa", "spa"), ("francorchamps", "spa"),
    ("sarthe", "lemans"), ("mans", "lemans"),
    ("bahrain", "bahrain"), ("sakhir", "bahrain"),
    ("lusail", "qatar"), ("qatar", "qatar"), ("losail", "qatar"),
    ("americas", "cota"), ("cota", "cota"), ("austin", "cota"),
    ("fuji", "fuji"),
    ("interlagos", "interlagos"), ("carlos pace", "interlagos"), ("sao paulo", "interlagos"),
    ("algarve", "portimao"), ("portimao", "portimao"),
    ("barcelona", "barcelona"), ("catalunya", "barcelona"), ("montmelo", "barcelona"),
    ("paul ricard", "paulricard"), ("ricard", "paulricard"), ("castellet", "paulricard"),
    ("silverstone", "silverstone"),
    ("imola", "imola"), ("enzo e dino", "imola"), ("ferrari", "imola"),
)


def _track_png_file(track):
    """PNG della mappa pista (assets/trackmaps), None se non disponibile."""
    if not track:
        return None
    tl = track.lower()
    for sub, key in _TRACK_PNG_ALIASES:
        if sub in tl:
            p = _OV_TRACKMAPS_PNG_DIR / (key + ".png")
            if p.exists():
                return p
    return None


class _PngBox(QLabel):
    """Mostra un PNG mantenendo le proporzioni (mai stirato), centrato."""
    _pix_cache = {}

    def __init__(self, path, w, h):
        super().__init__()
        self.setFixedSize(w, h)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("background:transparent;")
        key = (str(path), w, h)
        pm = _PngBox._pix_cache.get(key)
        if pm is None:
            try:
                src = QPixmap(str(path))
                pm = src.scaled(w, h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            except Exception:
                pm = QPixmap()
            _PngBox._pix_cache[key] = pm
        if not pm.isNull():
            self.setPixmap(pm)


_OV_LOGO_ALIASES = {
    "monza": "Monza", "imola": "Imola", "enzo e dino": "Imola",
    "bahrain": "Bahrain", "barcelona": "Barcelona", "catalunya": "Barcelona",
    "fuji": "Fuji", "interlagos": "Interlagos", "carlos pace": "Interlagos",
    "silverstone": "Silverstone", "americas": "COTA", "cota": "COTA",
    "mans": "LeMans", "sarthe": "LeMans",
}


def _ov_tracklogo_file(track):
    if not track:
        return None
    tl = track.lower()
    for k, v in _OV_LOGO_ALIASES.items():
        if k in tl:
            p = _OV_TRACKLOGO_DIR / (v + ".svg")
            if p.exists():
                return p
    try:
        for f in _OV_TRACKLOGO_DIR.glob("*.svg"):
            if f.stem.lower() in tl:
                return f
    except Exception:
        pass
    return None


def _track_logo_stem(track):
    """Nome breve del circuito (stem del file SVG) per un track name, o None."""
    p = _ov_tracklogo_file(track)
    return p.stem if p else None


def _fmt_when(started_at, name=""):
    """ISO datetime -> 'DD Mon YYYY · HH:MM'. Fallback dal nome file (MM-DD_HH-MM)."""
    import time as _t
    if started_at:
        try:
            tm = _t.strptime(started_at[:19], "%Y-%m-%dT%H:%M:%S")
            return _t.strftime("%d %b %Y \u00b7 %H:%M", tm)
        except Exception:
            pass
    try:
        import re as _re
        m = _re.search(r"(\d{2})-(\d{2})_(\d{2})-(\d{2})", name or "")
        if m:
            mo, da, hh, mm = m.groups()
            return f"{da}/{mo} \u00b7 {hh}:{mm}"
    except Exception:
        pass
    return ""


def _class_color(cls):
    """Colore classe come nello standings (HY/P2/P3/GT3/GTE)."""
    try:
        from core.classes import class_tag
        tag = class_tag(cls)
    except Exception:
        tag = (cls or "").upper()[:3]
    return {"HY": "#bd1016", "P2": "#1e3163", "P3": "#411c52",
            "GT3": "#01824d", "GTE": "#ff9100"}.get(tag, "#6e727b")


# Traduzione etichette pace (FRONT-END). Cambia qui per rinominare le bande.
_PACE_LABEL = {
    "Alien":       "Pro",
    "Competitive": "Competitive",
    "Good":        "Good",
    "Midpack":     "Midpack",
    "Tail-ender":  "Tail-ender",
    "Offline":     "Non competitive",
    "Hotlap":      "Hotlap",
}


def _pace_label(internal):
    return _PACE_LABEL.get(internal, internal)


_TRASH_SVG = (b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'>"
              b"<path fill='%s' d='M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12z"
              b"M19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z'/></svg>")
_trash_icon_cache = {}


_FOLDER_SVG = (b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'>"
               b"<path fill='%s' d='M10 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16"
               b"c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2h-8l-2-2z'/></svg>")
_folder_icon_cache = {}


def _folder_icon(color="#838790", size=16):
    key = (color, size)
    if key in _folder_icon_cache:
        return _folder_icon_cache[key]
    from PySide6.QtGui import QIcon, QPixmap
    ic = QIcon()
    try:
        if QSvgRenderer is not None:
            r = QSvgRenderer(QByteArray(_FOLDER_SVG % color.encode()))
            pm = QPixmap(size, size); pm.fill(Qt.transparent)
            p = QPainter(pm); r.render(p); p.end()
            ic = QIcon(pm)
    except Exception:
        ic = QIcon()
    _folder_icon_cache[key] = ic
    return ic


def _trash_icon(color="#838790", size=16):
    key = (color, size)
    if key in _trash_icon_cache:
        return _trash_icon_cache[key]
    from PySide6.QtGui import QIcon, QPixmap
    ic = QIcon()
    try:
        if QSvgRenderer is not None:
            r = QSvgRenderer(QByteArray(_TRASH_SVG % color.encode()))
            pm = QPixmap(size, size); pm.fill(Qt.transparent)
            p = QPainter(pm); r.render(p); p.end()
            ic = QIcon(pm)
    except Exception:
        ic = QIcon()
    _trash_icon_cache[key] = ic
    return ic


_X_SVG = (b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' "
          b"stroke='%s' stroke-width='3.4' stroke-linecap='round'>"
          b"<line x1='6.5' y1='6.5' x2='17.5' y2='17.5'/>"
          b"<line x1='17.5' y1='6.5' x2='6.5' y2='17.5'/></svg>")
_x_icon_cache = {}


def _x_icon(color="#838790", size=16):
    key = (color, size)
    if key in _x_icon_cache:
        return _x_icon_cache[key]
    from PySide6.QtGui import QIcon, QPixmap
    ic = QIcon()
    try:
        if QSvgRenderer is not None:
            r = QSvgRenderer(QByteArray(_X_SVG % color.encode()))
            pm = QPixmap(size, size); pm.fill(Qt.transparent)
            p = QPainter(pm); p.setRenderHint(QPainter.Antialiasing, True)
            r.render(p); p.end()
            ic = QIcon(pm)
    except Exception:
        ic = QIcon()
    _x_icon_cache[key] = ic
    return ic


class _XButton(QPushButton):
    """X bold che diventa rossa al passaggio del mouse."""
    def __init__(self, size=16):
        super().__init__()
        self._sz = size
        self._n = _x_icon("#9aa0aa", size)
        self._h = _x_icon("#ff5b5b", size)
        self.setIcon(self._n); self.setIconSize(QSize(size, size))

    def enterEvent(self, e):
        self.setIcon(self._h); super().enterEvent(e)

    def leaveEvent(self, e):
        self.setIcon(self._n); super().leaveEvent(e)


class _SessionRow(QFrame):
    """Riga della lista telemetrie: barra colore-classe, logo auto, classe·pilota,
    circuito, data/ora, cestino. Clic sulla riga = seleziona."""
    def __init__(self, idx, s, selected, on_select, on_delete, empty_svg, on_open=None):
        super().__init__()
        self._idx = idx; self._sel_cb = on_select; self._del_cb = on_delete
        self._open_cb = on_open; self._file = s.get("file")
        self._selected = selected
        self.setObjectName("ovSelRow" if selected else ("ovRowB" if idx % 2 else "ovRowA"))
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(82)
        h = QHBoxLayout(self); h.setContentsMargins(10, 5, 8, 5); h.setSpacing(9)
        logo = _SvgBox(); logo.setFixedSize(54, 38)
        try:
            from core.brands import brand_from_vehicle
            from core.utils import find_logo_path
            brand = (brand_from_vehicle(s.get("team") or "")
                     or brand_from_vehicle(s.get("vehicle") or ""))
            p = find_logo_path(brand) if brand else None
            logo.load(str(p) if p else empty_svg)
        except Exception:
            logo.load(empty_svg)
        h.addWidget(logo, 0, Qt.AlignVCenter)
        tb = QVBoxLayout(); tb.setSpacing(0); tb.setContentsMargins(0, 0, 0, 0)
        cls = (s.get("car_class") or "").strip()
        drv = (s.get("driver") or "").strip()
        if cls:
            try:
                from core.classes import class_tag
                tag = class_tag(cls) or cls
            except Exception:
                tag = cls
        else:
            tag = ""
        top = QWidget(); tl = QHBoxLayout(top); tl.setContentsMargins(0, 0, 0, 0)
        tl.setSpacing(7)
        top.setFixedHeight(22); top.setStyleSheet("background:transparent;")
        if cls:
            pill = QLabel(tag); pill.setObjectName("ovClsPill")
            pill.setAlignment(Qt.AlignCenter); pill.setFixedHeight(16)
            pill.setStyleSheet(
                "#ovClsPill{background:%s;color:#fff;font-weight:700;font-size:11px;"
                "border-radius:3px;padding:0 5px;}" % _class_color(cls))
            tl.addWidget(pill, 0, Qt.AlignVCenter)
        dlb = QLabel(drv or (s.get("name") or "\u2014")); dlb.setObjectName("ovRowTitle")
        tl.addWidget(dlb, 0, Qt.AlignVCenter); tl.addStretch()
        l2 = QLabel((s.get("track") or "\u2014")); l2.setObjectName("ovRowSub")
        l2.setStyleSheet("color:#ff8a18;" if _track_is_alt(s.get("track")) else "color:#1c9fe0;")
        l2.setWordWrap(False); l2.setFixedHeight(16)
        is_wet = (s.get("wetness") or 0.0) > 0.10
        mcol = "#4ec3ff" if is_wet else "#f5c542"
        mtxt = "WET" if is_wet else "DRY"
        styp = _ov_session_label(s.get("session_type"))
        slen = _fmt_session_len(s.get("session_len"))
        meta_bits = styp + ((" \u00b7 " + slen) if slen else "")
        l3 = QLabel("%s &nbsp;<span style='color:%s;font-weight:700'>%s</span>"
                    % (meta_bits, mcol, mtxt))
        l3.setObjectName("ovRowSub"); l3.setTextFormat(Qt.RichText); l3.setFixedHeight(16)
        l4 = QLabel(_fmt_when(s.get("started_at"), s.get("name")))
        l4.setObjectName("ovRowDim"); l4.setFixedHeight(16)
        tb.addWidget(top); tb.addSpacing(3)
        tb.addWidget(l2); tb.addWidget(l3); tb.addWidget(l4)
        h.addLayout(tb, 1)
        # tracciato della pista in bianco, a destra della scheda
        # mappa pista a destra: SVG in stile (gradiente + linea centrale), per layout
        sp = _track_styled_svg(s.get("track"))
        if sp is not None:
            mapbox = _SvgBox(); mapbox.setFixedSize(118, 66)
            mapbox.setStyleSheet("background:transparent;")
            mapbox.load(str(sp))
            h.addWidget(mapbox, 0, Qt.AlignVCenter)
        rb = QVBoxLayout(); rb.setSpacing(4); rb.setContentsMargins(0, 0, 0, 0)
        rb.addStretch()
        icons = QHBoxLayout(); icons.setSpacing(6); icons.setContentsMargins(0, 0, 0, 0)
        btn_del = _XButton(16); btn_del.setObjectName("ovRowIcon")
        btn_del.setFlat(True); btn_del.setCursor(Qt.PointingHandCursor)
        btn_del.setToolTip("Delete"); btn_del.setFixedSize(22, 22)
        btn_del.clicked.connect(self._on_del)
        icons.addWidget(btn_del)
        rb.addLayout(icons)
        h.addLayout(rb, 0)

    def set_selected(self, on):
        self._selected = on
        self.setObjectName("ovSelRow" if on else ("ovRowB" if self._idx % 2 else "ovRowA"))
        self.style().unpolish(self); self.style().polish(self)

    def _on_del(self):
        if self._del_cb:
            self._del_cb(self._idx)

    def _on_open(self):
        if self._open_cb:
            self._open_cb(self._file)

    def mousePressEvent(self, e):
        if self._sel_cb:
            self._sel_cb(self._idx)
        super().mousePressEvent(e)


def _clear_layout(lay, keep_stretch=False):
    while lay.count():
        it = lay.takeAt(0)
        w = it.widget()
        if w is not None:
            w.hide()                 # evita il flash come finestra top-level
            w.deleteLater()          # NON usare setParent(None) su widget visibili
    if keep_stretch:
        lay.addStretch()


class _LapRow(QFrame):
    """Riga giro: UN check (verde=Selected, viola=Compare) + numero + tempo +
    settori. Out-lap e giri invalidi non sono selezionabili (nessun check)."""
    def __init__(self, lap, time_s, secs, is_best, invalid, is_out, is_sel, is_cmp,
                 on_pick, best_secs=None, pace_label=None, pace_gap=None, pace_color=None,
                 is_in=False, e_delta=None, w_delta=None):
        super().__init__()
        self._lap = lap
        selectable = not invalid and not is_out and not is_in
        self._on_pick = on_pick if selectable else None
        if selectable:
            self.setCursor(Qt.PointingHandCursor)
        if is_out or invalid or is_in:
            self.setObjectName("ovLapDis")
        elif is_best:
            self.setObjectName("ovLapBestCard")
        else:
            self.setObjectName("ovLapSel" if (is_sel and selectable) else "ovLapRow")
        h = QHBoxLayout(self); h.setContentsMargins(12, 5, 16, 5); h.setSpacing(0)
        ck = None
        if selectable:
            border = _BEST_ROSE if is_best else "#3a3d43"
            if is_sel or is_cmp:
                check_col = _FUX if is_best else _SEL_COL
            else:
                check_col = "transparent"
            ck = _mk_check(lambda: on_pick(("lap", lap)), border,
                           is_sel or is_cmp, check_col)
        no = QLabel(str(lap)); no.setObjectName("ovLapInv" if (invalid or is_out or is_in) else "ovLapNo")
        no.setFixedWidth(34)
        h.addWidget(no)
        if is_out:
            tag = QLabel("OUT LAP"); tag.setObjectName("ovTagOut"); h.addWidget(tag)
        elif invalid:
            tag = QLabel("TRACK LIMITS"); tag.setObjectName("ovTagTL"); h.addWidget(tag)
        elif is_in:
            tag = QLabel("PIT LINE"); tag.setObjectName("ovTagOut"); h.addWidget(tag)
        elif is_best and pace_label:
            h.addSpacing(4)
            pl = QLabel(pace_label)
            pl.setStyleSheet("color:#f5f5f5;font-size:11px;background:transparent;")
            h.addWidget(pl, 0, Qt.AlignVCenter)
            if pace_gap is not None:
                h.addSpacing(8)
                sign = "+" if pace_gap >= 0 else "\u2212"
                g = QLabel("%s%.2f" % (sign, abs(pace_gap)))
                _gc = pace_color or "#f5f5f5"
                g.setStyleSheet("color:%s;font-size:11px;font-weight:600;"
                                "background:transparent;" % _gc)
                h.addWidget(g, 0, Qt.AlignVCenter)
        h.addStretch()
        dim = invalid or is_out or is_in
        t = QLabel(_fmt(time_s) if time_s else "\u2014"); t.setFixedWidth(84)
        t.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        t.setObjectName("ovLapInv" if dim else ("ovLapBest" if is_best else "ovLapTime"))
        h.addWidget(t)
        bs = best_secs or [None, None, None]
        for i, s in enumerate(secs):
            sl = QLabel(_fmt(s) if (s and s > 0) else "\u2014"); sl.setFixedWidth(64)
            sl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            if dim:
                sl.setObjectName("ovSecInv")
            elif s and bs[i] and abs(s - bs[i]) < 1e-6:
                sl.setObjectName("ovSecBest")       # miglior settore dello stint = fuxia
            else:
                sl.setObjectName("ovSec")
            h.addWidget(sl)
        if ck is not None:
            h.addSpacing(12); h.addWidget(ck, 0, Qt.AlignVCenter)
        else:
            h.addSpacing(12 + 16)                  # riserva spazio check (allinea)

    def mousePressEvent(self, e):
        if self._on_pick:
            self._on_pick(("lap", self._lap))


class _LapBoard(QFrame):
    """Pannello destro Overview: tab per stint + tabella tempi con riga REF in
    cima (logo auto + pilota + tempo, oro) e checkbox per scegliere il giro da
    confrontare; il confronto è SEMPRE vs REF (automatico)."""
    _EMPTY_SVG = b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'/>"

    def __init__(self):
        super().__init__()
        self.setObjectName("ovCard")
        self._on_stint = None; self._on_pick = None
        self._live = False        # auto-scroll all'ultimo giro solo in registrazione
        self._tyre4 = []
        v = QVBoxLayout(self); v.setContentsMargins(0, 6, 0, 6); v.setSpacing(0)
        # tab stint (niente scritta TIMES)
        head = QWidget(); hl = QHBoxLayout(head); hl.setContentsMargins(12, 6, 14, 6)
        hl.setSpacing(8)
        self._tabs_host = QWidget(); self._tabs_l = QHBoxLayout(self._tabs_host)
        self._tabs_l.setContentsMargins(0, 0, 0, 0); self._tabs_l.setSpacing(6)
        hl.addWidget(self._tabs_host); hl.addStretch()
        self.tabs_bar = head            # esposta: il parent la mette SOPRA la card
        # riga riassunto dello stint (durata effettiva, consumo gomma, energia)
        self.lb_summary = QLabel(""); self.lb_summary.setObjectName("ovStintSum")
        self.lb_summary.setTextFormat(Qt.RichText)
        self.lb_summary.setContentsMargins(20, 5, 24, 5)
        # (spostata nella stint_card del parent)
        # separatore + spazio tra riassunto e intestazione colonne
        dvw = QWidget(); dvl = QHBoxLayout(dvw); dvl.setContentsMargins(20, 6, 24, 6)
        dvl.setSpacing(0)
        div = QFrame(); div.setFixedHeight(1); div.setStyleSheet("background:#26282e;")
        dvl.addWidget(div)
        v.addWidget(dvw)
        # intestazione colonne (allineata alle righe: num a sx, check riservata a dx)
        colh = QWidget(); cl = QHBoxLayout(colh); cl.setContentsMargins(24, 0, 28, 4)
        cl.setSpacing(0)
        c0 = QLabel("LAP"); c0.setObjectName("ovColCap")
        cl.addWidget(c0); cl.addStretch()
        for cap, w in (("TIME", 84), ("S1", 64), ("S2", 64), ("S3", 64)):
            lb = QLabel(cap); lb.setObjectName("ovColCap"); lb.setFixedWidth(w)
            lb.setAlignment(Qt.AlignRight | Qt.AlignVCenter); cl.addWidget(lb)
        cl.addSpacing(12 + 16)            # colonna check riservata (allinea i settori)
        v.addWidget(colh)
        # giri (scroll) — ogni giro è una card
        from PySide6.QtWidgets import QScrollArea
        self._scroll = QScrollArea(); self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._laps_host = QWidget(); self._laps_v = QVBoxLayout(self._laps_host)
        self._laps_v.setContentsMargins(12, 0, 12, 0); self._laps_v.setSpacing(6)
        self._laps_v.addStretch()
        self._scroll.setWidget(self._laps_host)
        v.addWidget(self._scroll, 1)

    def set_callbacks(self, on_stint, on_pick):
        self._on_stint = on_stint; self._on_pick = on_pick

    def update_board(self, keys, cur_key, laps, best_id, sel_id, cmp_lap, tyre4=None, pace=None, stint_new=None, stint_new4=None):
        self._tyre4 = tyre4 or []
        self._pace = pace if (pace and pace.get("kind")) else None
        self._stint_new_map = stint_new if isinstance(stint_new, dict) else {}
        self._stint_new4_map = stint_new4 if isinstance(stint_new4, dict) else {}
        self._build_tabs(keys, cur_key)
        self._set_summary(laps)
        self._build_laps(laps, best_id, sel_id, cmp_lap)

    def _stint_started_new(self, laps):
        """Integrità gomma a INIZIO stint, scontando l'out-lap.

        Il 1° giro dello stint è l'out-lap: il wear registrato è già di FINE
        out-lap, quindi una gomma NUOVA legge <100%. Ricostruisco il valore di
        partenza ri-sommando il consumo medio di un giro (stimato dai giri
        successivi). ~100% -> nuova (pieno); inferiore -> usata (tratteggiata).
        Non dipende dal consumo successivo. Dato assente -> nuova."""
        seq = []
        for L in laps:
            ws = [L.get(k) for k in ("w_fl", "w_fr", "w_rl", "w_rr")]
            ws = [x for x in ws if x is not None]
            if ws:
                seq.append(sum(ws) / len(ws))
        if not seq:
            return True
        end_outlap = seq[0]                      # wear a fine out-lap
        drops = [seq[i - 1] - seq[i] for i in range(1, len(seq))
                 if seq[i - 1] - seq[i] > 0]
        per_lap = (sum(drops) / len(drops)) if drops else 0.0
        est_start = end_outlap + per_lap         # integrità prima dell'out-lap
        return est_start >= 99.0

    def _set_summary(self, laps):
        """Riassunto dello stint: durata effettiva, consumo gomma, energia/fuel."""
        valid_t = [L.get("lap_time") for L in laps if (L.get("lap_time") or 0) > 0]
        dur = sum(valid_t) if valid_t else 0
        fuel = sum((L.get("fuel_used") or 0.0) for L in laps)
        ve = sum((L.get("ve_used") or 0.0) for L in laps)
        w_first = w_last = None
        for L in laps:
            ws = [L.get(k) for k in ("w_fl", "w_fr", "w_rl", "w_rr")]
            ws = [x for x in ws if x is not None]
            if ws:
                avg = sum(ws) / len(ws)
                if w_first is None:
                    w_first = avg
                w_last = avg
        tyre_used = (w_first - w_last) if (w_first is not None and w_last is not None) else None
        parts = ["Duration <b style='color:#f5f5f5'>%s</b>"
                 % (_ov_clock(dur) if dur else "\u2014")]
        parts.append("Laps <b style='color:#f5f5f5'>%d</b>" % len(laps))
        if tyre_used is not None and tyre_used > 0:
            parts.append("Tyre <b style='color:#f5f5f5'>-%.1f%%</b>" % tyre_used)
        if fuel > 0:
            parts.append("Fuel <b style='color:#f5f5f5'>%.1f L</b>" % fuel)
        if ve > 0:
            parts.append("Energy <b style='color:#f5f5f5'>%.0f%%</b>" % ve)
        self.lb_summary.setText("&nbsp;&nbsp;\u00b7&nbsp;&nbsp;".join(parts))

    def _build_tabs(self, keys, cur_key):
        from core.tyre_cell import TyreCell
        _clear_layout(self._tabs_l)
        four = self._tyre4 if (len(self._tyre4) == 4 and all(self._tyre4)) else None
        single = (four[0] if four else (self._tyre4[0] if self._tyre4 else ""))
        for k in keys:
            b = _ClickFrame(lambda kk=k: self._on_stint and self._on_stint(kk))
            b.setObjectName("ovTabOn" if k == cur_key else "ovTabOff")
            bl = QHBoxLayout(b); bl.setContentsMargins(10, 4, 8, 4); bl.setSpacing(7)
            lbl = QLabel(f"STINT {k}"); lbl.setObjectName("ovTabTxt")
            bl.addWidget(lbl, 0, Qt.AlignVCenter)
            if single or four:
                tc = TyreCell(size=26, scale=0.9)
                tc.setStyleSheet("background:transparent;")
                tc.set_tyre(single, four,
                            new4=self._stint_new4_map.get(k),
                            single_new=self._stint_new_map.get(k, True))
                bl.addWidget(tc, 0, Qt.AlignVCenter)
            self._tabs_l.addWidget(b)
        self._tabs_l.addStretch()

    def _build_laps(self, laps, best_id, sel_id, cmp_id):
        _clear_layout(self._laps_v, keep_stretch=True)
        valid = [L for L in laps if not L.get("invalid")]

        def _bs(k):
            vals = [L.get(k) for L in valid if (L.get(k) or 0) > 0]
            return min(vals) if vals else None
        best_secs = [_bs("s1"), _bs("s2"), _bs("s3")]
        pace = getattr(self, "_pace", None)

        # --- gestione per giro: delta energia/gomma vs giro di spinta (best) ---
        def _energy(L):
            v = L.get("ve_used") or 0
            return v if v > 0 else (L.get("fuel_used") or 0)

        def _avgw(L):
            ws = [L.get(k) for k in ("w_fl", "w_fr", "w_rl", "w_rr") if L.get(k) is not None]
            return (sum(ws) / len(ws)) if ws else None

        wear_used = {}
        _prev_w = None
        for L in laps:
            a = _avgw(L)
            if _prev_w is not None and a is not None and (_prev_w - a) >= 0:
                wear_used[L["lap"]] = _prev_w - a
            if a is not None:
                _prev_w = a
        best_L = next((L for L in laps if L["lap"] == best_id), None)
        base_e = _energy(best_L) if best_L else 0
        base_w = wear_used.get(best_id) if best_id else None

        for i, L in enumerate(laps):
            secs = [L.get("s1"), L.get("s2"), L.get("s3")]
            is_best = L["lap"] == best_id
            lt = L.get("lap_time") or 0
            s1 = L.get("s1") or 0; s2 = L.get("s2") or 0; s3 = L.get("s3") or 0
            # in-lap (rientro box): e' SEMPRE l'ultimo giro dello stint (il pit
            # chiude lo stint). Settori 1-2 presenti, s3/tempo assenti, non invalid.
            is_in = (i != 0) and (i == len(laps) - 1) and (not L.get("invalid")) \
                and (lt <= 0) and (s1 > 0) and (s2 > 0) and (s3 <= 0)
            # giro senza tempo a meta' stint = invalidato (track limits/abortito)
            inval = bool(L.get("invalid")) or ((i != 0) and (lt <= 0) and (not is_in))
            usable = (i != 0) and (not is_in) and (not inval)
            e_delta = w_delta = None
            if usable:
                e = _energy(L)
                if base_e > 0 and e > 0:
                    e_delta = (e / base_e - 1.0) * 100.0
                wu = wear_used.get(L["lap"])
                if base_w and base_w > 0 and wu is not None:
                    w_delta = (wu / base_w - 1.0) * 100.0
            p_lab = p_gap = p_col = None
            if is_best and pace:
                p_lab = _pace_label(pace.get("label"))
                p_gap = pace.get("gap"); p_col = pace.get("color")
            r = _LapRow(L["lap"], L.get("lap_time"), secs,
                        is_best, inval, i == 0,
                        L["lap"] == sel_id, L["lap"] == cmp_id, self._on_pick,
                        best_secs, p_lab, p_gap, p_col, is_in=is_in,
                        e_delta=e_delta, w_delta=w_delta)
            self._laps_v.insertWidget(self._laps_v.count() - 1, r)
        # focus sull'ultimo giro: scrolla in fondo dopo il layout
        from PySide6.QtCore import QTimer
        QTimer.singleShot(0, self._scroll_laps_bottom)

    def _scroll_laps_bottom(self):
        if not getattr(self, "_live", False):
            return                       # solo in registrazione (in pista)
        sb = self._scroll.verticalScrollBar()
        sb.setValue(sb.maximum())


_EMPTY_LOGO_SVG = b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'/>"

# cerchio (come la gomma) con goccia benzina dentro, viola
_FUEL_WEIGHT_SVG = (
    "<svg viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'>"
    "<circle cx='12' cy='12' r='10.2' fill='none' stroke='#9d6bff' stroke-width='1.9'/>"
    "<path fill='#9d6bff' d='M12 6.6 C9.4 9.7 8.3 11.5 8.3 13.3 "
    "a3.7 3.7 0 0 0 7.4 0 C15.7 11.5 14.6 9.7 12 6.6 Z'/></svg>")

_BEST_ROSE = "#ff5bb0"   # bordo check del giro più veloce (rosa)


def _mk_check(on_click, border, checked, check_col):
    """Casella: bordo in tinta (grigio/rosa/oro) + segno di spunta dentro
    quando selezionata (verde=Selected, viola=Compare)."""
    b = QPushButton("\u2713" if checked else "")
    b.setFixedSize(16, 16); b.setCursor(Qt.PointingHandCursor)
    b.setStyleSheet(
        "QPushButton{background:transparent;border:1.5px solid %s;border-radius:4px;"
        "color:%s;font-size:11px;font-weight:900;padding:0;margin:0;}"
        "QPushButton:hover{border-color:%s;}" % (border, check_col, border))
    if on_click:
        b.clicked.connect(lambda: on_click())
    return b


class _ClickFrame(QFrame):
    """QFrame cliccabile (per la riga REF)."""
    def __init__(self, on_click=None):
        super().__init__()
        self._on_click = on_click
        if on_click:
            self.setCursor(Qt.PointingHandCursor)

    def mousePressEvent(self, e):
        if self._on_click:
            self._on_click()


def _brand_from_car_name(car):
    """Manifattura dal nome auto (es. 'Porsche 911 GT3 R' -> 'Porsche'),
    matchando i file in brandlogo/. Per i record online di altri team, dove
    il team non è nel brands.json locale. None se nessuno."""
    if not car:
        return None
    try:
        from core.utils import LOGO_DIR
        if not LOGO_DIR.exists():
            return None
        cl = car.lower()
        best = None
        for f in LOGO_DIR.glob("*.svg"):
            nm = f.stem
            if nm and nm.lower() in cl and (best is None or len(nm) > len(best)):
                best = nm
        return best
    except Exception:
        return None


def _car_logo_into(box, team, vehicle):
    try:
        from core.brands import brand_from_vehicle
        from core.utils import find_logo_path
        brand = brand_from_vehicle(team or "") or brand_from_vehicle(vehicle or "")
        if not brand:                       # online: team sconosciuto -> dal nome auto
            brand = _brand_from_car_name(vehicle)
        p = find_logo_path(brand) if brand else None
        box.load(str(p) if p else _EMPTY_LOGO_SVG)
    except Exception:
        box.load(_EMPTY_LOGO_SVG)


_SVM_KEY_NAMES = {
    # electronics / brakes
    "TractionControlMapSetting": "Onboard TC",
    "TCPowerCutMapSetting": "TC Power Cut",
    "TCSlipAngleMapSetting": "TC Slip Angle",
    "AntilockBrakeSystemMapSetting": "ABS",
    "RearBrakeSetting": "Brake Bias",
    "BrakePressureSetting": "Brake Pressure",
    "BrakeMigrationSetting": "Brake Migration",
    "SteerLockSetting": "Steering Lock",
    # aero / body
    "FWSetting": "Front Wing",
    "RWSetting": "Rear Wing",
    "WaterRadiatorSetting": "Water Radiator",
    "OilRadiatorSetting": "Oil Radiator",
    "BrakeDuctSetting": "Front Brake Duct",
    "BrakeDuctRearSetting": "Rear Brake Duct",
    "FenderFlareSetting": "Fender Flare",
    # suspension
    "FrontAntiSwaySetting": "Front Anti-Roll Bar",
    "RearAntiSwaySetting": "Rear Anti-Roll Bar",
    "FrontToeInSetting": "Front Toe",
    "RearToeInSetting": "Rear Toe",
    "FrontToeOffsetSetting": "Front Toe Offset",
    "RearToeOffsetSetting": "Rear Toe Offset",
    "Front3rdSpringSetting": "Front 3rd Spring",
    "Front3rdPackerSetting": "Front 3rd Packer",
    "Front3rdTenderSpringSetting": "Front 3rd Tender Spring",
    "Front3rdTenderTravelSetting": "Front 3rd Tender Travel",
    "Rear3rdTenderSpringSetting": "Rear 3rd Tender Spring",
    "Rear3rdTenderTravelSetting": "Rear 3rd Tender Travel",
    "Front3rdSlowBumpSetting": "Front 3rd Slow Bump",
    "Front3rdFastBumpSetting": "Front 3rd Fast Bump",
    "Front3rdSlowReboundSetting": "Front 3rd Slow Rebound",
    "Front3rdFastReboundSetting": "Front 3rd Fast Rebound",
    "Rear3rdSpringSetting": "Rear 3rd Spring",
    "Rear3rdPackerSetting": "Rear 3rd Packer",
    "Rear3rdSlowBumpSetting": "Rear 3rd Slow Bump",
    "Rear3rdFastBumpSetting": "Rear 3rd Fast Bump",
    "Rear3rdSlowReboundSetting": "Rear 3rd Slow Rebound",
    "Rear3rdFastReboundSetting": "Rear 3rd Fast Rebound",
    # corners
    "CamberSetting": "Camber",
    "PressureSetting": "Tyre Pressure",
    "PackerSetting": "Packer",
    "SpringSetting": "Spring Rate",
    "SpringRubberSetting": "Spring Rubber",
    "TenderSpringSetting": "Tender Spring",
    "TenderTravelSetting": "Tender Travel",
    "RideHeightSetting": "Ride Height",
    "SlowBumpSetting": "Slow Bump",
    "FastBumpSetting": "Fast Bump",
    "SlowReboundSetting": "Slow Rebound",
    "FastReboundSetting": "Fast Rebound",
    "BrakeDiscSetting": "Brake Disc",
    "BrakePadSetting": "Brake Pad",
    "CompoundSetting": "Tyre Compound",
    # drivetrain
    "DiffPreloadSetting": "Diff Preload",
    "DiffPowerSetting": "Diff Power",
    "DiffCoastSetting": "Diff Coast",
    "DiffPumpSetting": "Diff Pump",
    "FrontDiffPreloadSetting": "Front Diff Preload",
    "FrontDiffPowerSetting": "Front Diff Power",
    "FrontDiffCoastSetting": "Front Diff Coast",
    "FrontDiffPumpSetting": "Front Diff Pump",
    "RatioSetSetting": "Gear Ratio Set",
    "RearSplitSetting": "Rear Split",
    "GearAutoUpShiftSetting": "Auto Upshift",
    "GearAutoDownShiftSetting": "Auto Downshift",
    # engine
    "RevLimitSetting": "Rev Limit",
    "EngineMixtureSetting": "Engine Mixture",
    "EngineBoostSetting": "Engine Boost",
    "RegenerationMapSetting": "Regeneration Map",
    "ElectricMotorMapSetting": "Electric Motor Map",
    "EngineBrakingMapSetting": "Engine Braking Map",
    # general
    "FuelSetting": "Fuel",
    "FuelCapacitySetting": "Fuel Capacity",
    "VirtualEnergySetting": "Virtual Energy",
    "NumPitstopsSetting": "Pit Stops",
    "Pitstop1Setting": "Pitstop 1",
    "Pitstop2Setting": "Pitstop 2",
    "Pitstop3Setting": "Pitstop 3",
}
# flag "disponibilità" aiuti: ridondanti con le mappe vere -> nascosti
_SVM_HIDE_KEYS = {"TCSetting", "ABSSetting"}


def _svm_humanize(key):
    if key in _SVM_KEY_NAMES:
        return _SVM_KEY_NAMES[key]
    import re
    k = key[:-7] if key.endswith("Setting") else key
    # split camelCase tenendo uniti gli acronimi (ABS, TC, RW...)
    k = re.sub(r'(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])', ' ', k)
    return k.strip()


def _svm_human_value(comment):
    c = (comment or "").lstrip("/").strip()
    # taglia annotazioni manuali tipo "  // ..."  oppure  "<-- ..."
    for sep in (" //", "<--", "<!--", "//"):
        i = c.find(sep)
        if i > 0:
            c = c[:i].strip()
    return c or "\u2014"


def _svm_full_note(comment):
    """Commento completo (per tooltip), senza lo slash iniziale."""
    return (comment or "").lstrip("/").strip()


def _svm_is_fixed(comment):
    c = (comment or "").lower()
    return any(x in c for x in ("non-adjustable", "n/a", "fixed", "non-adjust"))


_SVM_SECTION_NAMES = {
    "GENERAL": "General", "BASIC": "Basic",
    "FRONTWING": "Front Wing", "REARWING": "Rear Wing", "BODYAERO": "Body / Ducts",
    "LEFTFENDER": "Left Fender", "RIGHTFENDER": "Right Fender",
    "SUSPENSION": "Suspension", "CONTROLS": "Controls / Brakes",
    "ENGINE": "Engine", "DRIVELINE": "Driveline",
    "FRONTLEFT": "Front Left", "FRONTRIGHT": "Front Right",
    "REARLEFT": "Rear Left", "REARRIGHT": "Rear Right",
}


class _SettingsTab(QWidget):
    """Sezione Settings: carica, visualizza, modifica e salva un assetto LMU
    (.svm), organizzato in tab (Aero, Suspension, Corners, Brakes, Drivetrain,
    General). Salvataggio round-trip: tocca solo le righe modificate."""
    _GROUPS = [
        ("Aero", ["FRONTWING", "REARWING", "BODYAERO", "LEFTFENDER", "RIGHTFENDER"]),
        ("Suspension", ["SUSPENSION"]),
        ("Corners", ["FRONTLEFT", "FRONTRIGHT", "REARLEFT", "REARRIGHT"]),
        ("Brakes & Controls", ["CONTROLS"]),
        ("Drivetrain", ["DRIVELINE", "ENGINE"]),
        ("General", ["GENERAL", "BASIC"]),
    ]

    def __init__(self, win=None):
        super().__init__()
        self._win = win
        self._svm = None
        self._path = None
        root = QVBoxLayout(self); root.setContentsMargins(12, 10, 12, 12); root.setSpacing(8)
        bar = QHBoxLayout()
        self.btn_load = QPushButton("Load .svm"); self.btn_load.setObjectName("backBtn")
        self.btn_load.setCursor(Qt.PointingHandCursor)
        self.btn_load.clicked.connect(self._load)
        self.lb_file = QLabel("No setup loaded"); self.lb_file.setObjectName("ovRowSub")
        self.btn_save = QPushButton("Save"); self.btn_save.setObjectName("backBtn")
        self.btn_save.setCursor(Qt.PointingHandCursor); self.btn_save.setEnabled(False)
        self.btn_save.clicked.connect(self._save)
        self.btn_saveas = QPushButton("Save As\u2026"); self.btn_saveas.setObjectName("backBtn")
        self.btn_saveas.setCursor(Qt.PointingHandCursor); self.btn_saveas.setEnabled(False)
        self.btn_saveas.clicked.connect(self._save_as)
        bar.addWidget(self.btn_load); bar.addWidget(self.lb_file, 1)
        bar.addWidget(self.btn_save); bar.addWidget(self.btn_saveas)
        root.addLayout(bar)
        self.sub = QTabWidget(); root.addWidget(self.sub, 1)
        self.setStyleSheet(
            "#svmCard{background:#16181c;border:none;border-radius:10px;}"
            "#svmHdr{color:#eeeeef;font-size:12px;font-weight:700;letter-spacing:1.2px;}"
            "#svmHdrLine{background:#2c2e33;max-height:1px;min-height:1px;}"
            "#svmRowA{background:transparent;border-radius:6px;}"
            "#svmRowB{background:#212327;border-radius:6px;}"
            "#svmName{color:#d1d2d4;font-size:12px;}"
            "#svmNameOff{color:#60646d;font-size:12px;}"
            "#svmVal{color:#94979f;font-size:12px;}"
            "#svmSpin{background:#1d1f24;color:#ffffff;border:none;"
            "border-radius:7px;font-size:14px;font-weight:700;}"
            "#svmSpin:disabled{background:#111114;color:#4b4e55;border-color:#212327;}"
            "#svmStep{background:#2a2d33;color:%s;border:none;"
            "border-radius:7px;font-size:18px;font-weight:700;}"
            "#svmStep:hover{background:#494c53;}"
            "#svmStep:pressed{background:%s;color:#09090b;border-color:%s;}"
            "#svmStep:disabled{background:#17191c;color:#4b4e55;"
            "border-color:#212327;}" % (_ACCENT, _ACCENT, _ACCENT))
        self._placeholder()

    def _placeholder(self):
        self.sub.clear()
        w = QWidget(); l = QVBoxLayout(w)
        lbl = QLabel("Load an LMU .svm setup to view and edit.")
        lbl.setStyleSheet("color:#989ba2;font-size:14px;"); lbl.setAlignment(Qt.AlignCenter)
        l.addStretch(); l.addWidget(lbl); l.addStretch()
        self.sub.addTab(w, "Setup")

    def load_path(self, path):
        try:
            txt = open(path, encoding="utf-8", errors="replace").read()
            from core.svm import SVM
            self._svm = SVM.parse(txt); self._path = path
        except Exception:
            return False
        self.lb_file.setText(os.path.basename(path))
        self.btn_save.setEnabled(True); self.btn_saveas.setEnabled(True)
        self._build(); return True

    def _load(self):
        from PySide6.QtWidgets import QFileDialog
        start = ""
        if self._path:
            start = os.path.dirname(self._path)
        else:
            try:
                from core.lmu_paths import lmu_settings_dir
                start = lmu_settings_dir() or ""
            except Exception:
                start = ""
        fn, _f = QFileDialog.getOpenFileName(self, "Open LMU setup", start,
                                             "LMU setup (*.svm)")
        if fn:
            self.load_path(fn)

    def _build(self):
        from PySide6.QtWidgets import QScrollArea, QSpinBox
        self.sub.clear()
        secmap = dict(self._svm.sections())
        for gname, secs in self._GROUPS:
            scroll = QScrollArea(); scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.NoFrame)
            host = QWidget(); host.setStyleSheet("background:transparent;")
            hl = QVBoxLayout(host)
            hl.setContentsMargins(10, 10, 10, 10); hl.setSpacing(12)
            has_any = False
            for sname in secs:
                entries = secmap.get(sname)
                if not entries:
                    continue
                # solo voci regolabili e non ridondanti
                adj = [e for e in entries
                       if not _svm_is_fixed(e["comment"])
                       and e["key"] not in _SVM_HIDE_KEYS]
                if not adj:
                    continue
                has_any = True
                card = QFrame(); card.setObjectName("svmCard")
                cv = QVBoxLayout(card)
                cv.setContentsMargins(14, 12, 14, 14); cv.setSpacing(5)
                hdr = QLabel(_SVM_SECTION_NAMES.get(sname, sname).upper())
                hdr.setObjectName("svmHdr")
                cv.addWidget(hdr)
                line = QFrame(); line.setObjectName("svmHdrLine")
                line.setFixedHeight(1)
                cv.addWidget(line)
                cv.addSpacing(4)
                r = 0
                for e in adj:
                    name = _svm_humanize(e["key"])
                    hv = _svm_human_value(e["comment"])
                    note = _svm_full_note(e["comment"])
                    row = QFrame()
                    row.setObjectName("svmRowB" if r % 2 else "svmRowA")
                    rh = QHBoxLayout(row)
                    rh.setContentsMargins(12, 7, 10, 7); rh.setSpacing(12)
                    lbl = QLabel(name)
                    lbl.setObjectName("svmName")
                    if note and note != hv:
                        lbl.setToolTip(note)
                    # stepper:  [ - ][ valore ][ + ]
                    stepw = QWidget(); stepw.setStyleSheet("background:transparent;")
                    sh = QHBoxLayout(stepw)
                    sh.setContentsMargins(0, 0, 0, 0); sh.setSpacing(4)
                    minus = QPushButton("\u2212"); minus.setObjectName("svmStep")
                    minus.setFixedSize(28, 28); minus.setCursor(Qt.PointingHandCursor)
                    sp = QSpinBox(); sp.setObjectName("svmSpin")
                    sp.setRange(0, 9999); sp.setValue(int(e["value"]))
                    sp.setFixedSize(56, 28); sp.setAlignment(Qt.AlignCenter)
                    sp.setButtonSymbols(QSpinBox.NoButtons)
                    plus = QPushButton("+"); plus.setObjectName("svmStep")
                    plus.setFixedSize(28, 28); plus.setCursor(Qt.PointingHandCursor)
                    minus.clicked.connect(sp.stepDown)
                    plus.clicked.connect(sp.stepUp)
                    sh.addWidget(minus); sh.addWidget(sp); sh.addWidget(plus)
                    vlb = QLabel(hv); vlb.setObjectName("svmVal")
                    vlb.setMinimumWidth(150)
                    vlb.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    if note and note != hv:
                        vlb.setToolTip(note)
                    rh.addWidget(lbl, 1)
                    rh.addWidget(stepw)
                    rh.addWidget(vlb)
                    ix = e["idx"]
                    sp.valueChanged.connect(
                        lambda v, i=ix, w=vlb: self._on_change(i, v, w))
                    cv.addWidget(row)
                    r += 1
                hl.addWidget(card)
            hl.addStretch()
            scroll.setWidget(host)
            if has_any:
                self.sub.addTab(scroll, gname)

    def _on_change(self, idx, value, vlabel):
        if self._svm is None:
            return
        self._svm.set_value(idx, value)
        vlabel.setText("edited \u2192 reload in LMU")
        vlabel.setStyleSheet("color:#f5c542;font-size:12px;")

    def _save(self):
        if not (self._svm and self._path):
            return
        try:
            with open(self._path, "w", encoding="utf-8", newline="") as f:
                f.write(self._svm.to_text())
        except Exception:
            pass

    def _save_as(self):
        from PySide6.QtWidgets import QFileDialog
        if self._svm is None:
            return
        start = self._path
        if not start:
            try:
                from core.lmu_paths import lmu_settings_dir
                sd = lmu_settings_dir()
                start = os.path.join(sd, "setup.svm") if sd else "setup.svm"
            except Exception:
                start = "setup.svm"
        fn, _f = QFileDialog.getSaveFileName(self, "Save LMU setup",
                                             start, "LMU setup (*.svm)")
        if not fn:
            return
        try:
            with open(fn, "w", encoding="utf-8", newline="") as f:
                f.write(self._svm.to_text())
            self._path = fn; self.lb_file.setText(os.path.basename(fn))
        except Exception:
            pass


def _eng_fmt_t(s):
    try:
        s = float(s)
    except Exception:
        return "\u2014"
    m = int(s // 60); r = s - m * 60
    return ("%d:%06.3f" % (m, r)) if m else ("%.3f" % r)


class _TeamModeTab(QWidget):
    """Modalità squadra (driver swap endurance): cartella condivisa per i
    profili appresi + pannello 'spotter' col pilota in pista."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self._win = parent
        self._team_seen = set()      # snapshot gia' importati
        self._team_db = None         # .lmtel ricostruito in LOGS_DIR
        self._listed = False
        from PySide6.QtWidgets import QCheckBox, QLineEdit
        try:
            from core import team as _team
        except Exception:
            _team = None
        self._team = _team
        cfg = _team.load_cfg() if _team else {"enabled": False, "dir": "", "driver": ""}

        root = QVBoxLayout(self); root.setContentsMargins(16, 14, 16, 14); root.setSpacing(10)
        title = QLabel("TEAM MODE"); title.setObjectName("engHdr")
        title.setStyleSheet("color:#cfe8ff;font-size:12px;font-weight:800;letter-spacing:2px;")
        root.addWidget(title)
        note = QLabel("Share one synced folder (e.g. Syncthing) between the drivers. "
                      "Learned references are shared; whoever is driving publishes a "
                      "live status the others can watch. Only one drives at a time.")
        note.setObjectName("engStatus"); note.setWordWrap(True)
        root.addWidget(note)

        row1 = QHBoxLayout()
        self._chk = QCheckBox("Enable team mode"); self._chk.setObjectName("engStatus")
        self._chk.setChecked(bool(cfg.get("enabled")))
        self._chk.toggled.connect(self._toggle)
        row1.addWidget(self._chk); row1.addStretch()
        root.addLayout(row1)

        row2 = QHBoxLayout()
        self._btn_folder = QPushButton("Shared folder\u2026"); self._btn_folder.setObjectName("engLang")
        self._btn_folder.setFixedWidth(150); self._btn_folder.setCursor(Qt.PointingHandCursor)
        self._btn_folder.clicked.connect(self._pick_folder)
        idlbl = QLabel("Team & driver are taken from your profile (initial menu).")
        idlbl.setObjectName("engStatus")
        row2.addWidget(self._btn_folder); row2.addSpacing(14)
        row2.addWidget(idlbl); row2.addStretch()
        root.addLayout(row2)

        self._path_lbl = QLabel(cfg.get("dir") or "no folder selected")
        self._path_lbl.setObjectName("engStatus"); self._path_lbl.setWordWrap(True)
        root.addWidget(self._path_lbl)

        plbl = QLabel("ON TRACK NOW"); plbl.setObjectName("engHdr")
        plbl.setStyleSheet("color:#6e727b;font-size:9px;font-weight:800;letter-spacing:1.6px;")
        root.addWidget(plbl)
        self._panel = QLabel("Team mode off"); self._panel.setObjectName("engConsole")
        self._panel.setWordWrap(True)
        self._panel.setStyleSheet(
            "#engConsole{background:#0c0d10;border:1px solid #2a2c30;border-radius:8px;"
            "color:#cfe8ff;font-size:13px;padding:10px;}")
        root.addWidget(self._panel)

        # ── guida integrata, scrollabile, IT/EN ──
        from PySide6.QtWidgets import QTextBrowser
        g_row = QHBoxLayout()
        glbl = QLabel("GUIDE"); glbl.setObjectName("engHdr")
        glbl.setStyleSheet("color:#6e727b;font-size:9px;font-weight:800;letter-spacing:1.6px;")
        self._g_it = QPushButton("IT"); self._g_en = QPushButton("EN")
        for b in (self._g_it, self._g_en):
            b.setObjectName("engLang"); b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor); b.setFixedWidth(46)
        self._g_it.clicked.connect(lambda: self._set_guide("it"))
        self._g_en.clicked.connect(lambda: self._set_guide("en"))
        g_row.addWidget(glbl); g_row.addStretch()
        g_row.addWidget(self._g_it); g_row.addWidget(self._g_en)
        root.addLayout(g_row)
        self._guide = QTextBrowser(); self._guide.setObjectName("engConsole")
        self._guide.setOpenExternalLinks(True)
        self._guide.setStyleSheet(
            "#engConsole{background:#0c0d10;border:1px solid #2a2c30;border-radius:8px;"
            "color:#d7dbe0;font-size:13px;padding:12px;}")
        root.addWidget(self._guide, 1)
        self._set_guide("it")

        self._timer = QTimer(self); self._timer.setInterval(1500)
        self._timer.timeout.connect(self._refresh); self._timer.start()
        self._refresh()

    _GUIDE_IT = """
<h3 style="color:#cfe8ff;">Modalità Squadra — guida rapida</h3>
<p>Una cartella condivisa tra i PC dei piloti. Chi guida ci scrive i suoi dati,
gli altri li leggono. Guida uno alla volta: chi subentra parte già con i
riferimenti (passo, consumo, miglior giro, frenate) di chi ha guidato prima.</p>

<p><b style="color:#46e08a;">1. Installare l'app</b><br>
Estrai e avvia <code>LMU_TelemetryPro.exe</code>. Niente installazione.
Crea da sola la sua cartella dati personale.</p>

<p><b style="color:#46e08a;">2. Syncthing (una volta)</b><br>
Scarica da <b>syncthing.net</b>, installa lasciando i default (Relays = true).
Apri <code>http://127.0.0.1:8384</code>.<br>
• <b>Actions → Show ID</b>: copia il tuo ID e mandalo agli altri.<br>
• <b>Add Remote Device</b>: incolla l'ID degli altri due, accetta le richieste.<br>
• Un solo pilota: <b>Add Folder</b> → label <code>LMU_Team</code> → percorso
<code>C:\\LMU_Team</code> → scheda <b>Sharing</b>, spunta gli altri due → Save.<br>
• Gli altri due ricevono la richiesta cartella → <b>Accept</b>.</p>

<p><b style="color:#46e08a;">3. Nell'app (ogni pilota)</b><br>
Scheda <b>Team Mode</b> → spunta <b>Enable team mode</b> →
<b>Shared folder…</b> seleziona la cartella Syncthing (es. <code>C:\\LMU_Team</code>).<br>
Nome team e pilota li prende dal <b>profilo</b> (quello del menu iniziale): non
si scrivono qui.</p>

<p><b style="color:#46e08a;">4. In gara</b><br>
• Chi guida: va in pista, l'app pubblica da sola i suoi giri (con telemetria).<br>
• Chi non guida: nel riquadro <b>ON TRACK NOW</b> vede il pilota in pista.
La <b>telemetria dei giri</b> compare nella scheda <b>Telemetry</b> come sessione
<b>TEAM_…</b>: cliccabile e analizzabile, cresce giro dopo giro.<br>
• Al cambio pilota: la stessa gara continua, gli stint si accodano.</p>

<p><b style="color:#ffcc33;">Problemi</b><br>
• "Waiting for a teammate": nessuno in pista o cartella non ancora sincronizzata
(controlla che in Syncthing sia <i>Up to Date</i>).<br>
• "Team mode off": manca la spunta Enable o la cartella.<br>
• Dati non aggiornati: in Syncthing i device devono essere <i>Connected</i> e la
cartella <i>Up to Date</i>.<br>
• Tornare ai dati solo tuoi: togli la spunta Enable (non cancella nulla).</p>
"""

    _GUIDE_EN = """
<h3 style="color:#cfe8ff;">Team Mode — quick guide</h3>
<p>One shared folder between the drivers' PCs. Whoever drives writes their data,
the others read it. Only one drives at a time: who takes over already has the
references (pace, fuel use, best lap, braking) left by the previous driver.</p>

<p><b style="color:#46e08a;">1. Install the app</b><br>
Extract and run <code>LMU_TelemetryPro.exe</code>. No installation.
It creates its own personal data folder.</p>

<p><b style="color:#46e08a;">2. Syncthing (one time)</b><br>
Get it from <b>syncthing.net</b>, install with defaults (Relays = true).
Open <code>http://127.0.0.1:8384</code>.<br>
• <b>Actions → Show ID</b>: copy your ID and send it to the others.<br>
• <b>Add Remote Device</b>: paste the other two IDs, accept the requests.<br>
• One driver only: <b>Add Folder</b> → label <code>LMU_Team</code> → path
<code>C:\\LMU_Team</code> → <b>Sharing</b> tab, tick the other two → Save.<br>
• The other two get the folder request → <b>Accept</b>.</p>

<p><b style="color:#46e08a;">3. In the app (each driver)</b><br>
<b>Team Mode</b> tab → tick <b>Enable team mode</b> →
<b>Shared folder…</b> pick the Syncthing folder (e.g. <code>C:\\LMU_Team</code>).<br>
Team and driver names come from your <b>profile</b> (set in the initial menu):
you don't type them here.</p>

<p><b style="color:#46e08a;">4. On race day</b><br>
• Driving: go on track, the app publishes its laps (with telemetry) automatically.<br>
• Not driving: <b>ON TRACK NOW</b> shows the driver on track. The <b>lap
telemetry</b> shows up in the <b>Telemetry</b> tab as a <b>TEAM_…</b> session:
clickable and analysable, growing lap by lap.<br>
• At driver swap: the same race continues, stints are appended.</p>

<p><b style="color:#ffcc33;">Troubleshooting</b><br>
• "Waiting for a teammate": nobody on track or folder not synced yet
(check it's <i>Up to Date</i> in Syncthing).<br>
• "Team mode off": Enable not ticked or no folder.<br>
• Data not updating: in Syncthing devices must be <i>Connected</i> and the
folder <i>Up to Date</i>.<br>
• Back to your own data only: untick Enable (nothing is deleted).</p>
"""

    def _set_guide(self, lang):
        self._guide_lang = lang
        self._g_it.setChecked(lang == "it")
        self._g_en.setChecked(lang == "en")
        self._guide.setHtml(self._GUIDE_IT if lang == "it" else self._GUIDE_EN)

    def _toggle(self, on):
        if self._team:
            self._team.save_cfg(enabled=bool(on))
        self._refresh()

    def _pick_folder(self):
        from PySide6.QtWidgets import QFileDialog
        d = QFileDialog.getExistingDirectory(self, "Shared team folder")
        if d and self._team:
            self._team.save_cfg(dir=d)
            self._path_lbl.setText(d)
            self._refresh()

    def _driving_now(self):
        """True se sei tu in pista (sei lo scrittore, non importi)."""
        try:
            rec = getattr(self._win, "_recorder", None)
            raw = (rec.latest() or {}).get("raw") or {}
            import time as _t
            ts = raw.get("ts")
            return bool(raw.get("on_track")) and ts is not None and (_t.monotonic() - ts < 3.0)
        except Exception:
            return False

    def _import_team_session(self):
        """Importa gli snapshot del pilota in pista in un .lmtel dentro LOGS_DIR,
        così compare nella tab Telemetry (cliccabile, analizzabile)."""
        if not self._team or not self._team.is_active() or self._driving_now():
            return
        cfg = self._team.load_cfg()
        try:
            from core import team_session as TS
            from core.paths import LOGS_DIR
            race = TS.current_race(cfg["dir"])
            if race is None:
                return
            LOGS_DIR.mkdir(parents=True, exist_ok=True)
            db = LOGS_DIR / ("TEAM_%s.lmtel" % race.name)
            self._team_db = db
            n = TS.import_new(race, db, self._team_seen)
            if n and self._win is not None and not self._listed:
                self._listed = True
                try:
                    self._win._reload_sessions()
                except Exception:
                    pass
        except Exception:
            pass

    def _refresh(self):
        if not self._team or not self._team.is_active():
            self._panel.setText("Team mode off \u2014 enable it and pick the shared folder.")
            return
        self._import_team_session()
        d = self._team.read_live()
        mydrv = (self._team.driver_name() if self._team else "").strip().lower()
        if not d:
            self._panel.setText("Waiting for a teammate on track\u2026")
            return
        if mydrv and d.get("driver", "").strip().lower() == mydrv:
            self._panel.setText("You are the one publishing (on track).")
            return
        lt = d.get("lap_time")
        lt = ("%d:%05.2f" % (int(lt) // 60, lt % 60)) if isinstance(lt, (int, float)) and lt else "\u2014"
        fl = d.get("fuel_laps")
        fl = ("%d" % int(fl)) if isinstance(fl, (int, float)) else "\u2014"
        ga = d.get("gap_ahead")
        ga = ("+%.1f  %s" % (ga, d.get("name_ahead") or "")) if isinstance(ga, (int, float)) else "\u2014"
        trk = d.get("track") or ""
        self._panel.setText(
            "%s  \u2014  on track  %s\n\nLap %s   ·   %s\nFuel: %s laps left\nAhead: %s"
            % (d.get("driver") or "?", trk, d.get("lap", "\u2014"), lt, fl, ga))


class _EngineerTab(QWidget):
    """Analisi deterministica del giro selezionato vs REF: dove perdi tempo
    (zone con fase/causa/consiglio) e consigli assetto dedotti dai pattern."""
    _PHASE_COL = {"Braking": "#ff7a59", "Mid-corner": "#f5c542",
                  "Traction": "#55ff7f"}

    def __init__(self, win=None):
        super().__init__()
        self._win = win
        root = QVBoxLayout(self); root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(14)
        title = QLabel("RACE ENGINEER"); title.setObjectName("engHdr")
        root.addWidget(title)
        # selettore lingua IT / EN
        try:
            from engineer_overlay import _load_lang as _ll, _save_lang as _sl
            self._lang = _ll(); self._save_lang = _sl
        except Exception:
            self._lang = "it"; self._save_lang = lambda x: None
        lang_row = QHBoxLayout()
        llbl = QLabel("Language"); llbl.setObjectName("engStatus")
        self._btn_it = QPushButton("IT"); self._btn_en = QPushButton("EN")
        for b in (self._btn_it, self._btn_en):
            b.setObjectName("engLang"); b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor); b.setFixedWidth(52)
        self._btn_it.setChecked(self._lang == "it")
        self._btn_en.setChecked(self._lang == "en")
        self._btn_it.clicked.connect(lambda: self._set_lang("it"))
        self._btn_en.clicked.connect(lambda: self._set_lang("en"))
        lang_row.addWidget(llbl); lang_row.addSpacing(10)
        lang_row.addWidget(self._btn_it); lang_row.addWidget(self._btn_en)
        lang_row.addStretch()
        root.addLayout(lang_row)

        # ── scala overlay + TEST (dev) ──
        from PySide6.QtWidgets import QSlider
        try:
            from engineer_overlay import _load_scale as _ls, _save_scale as _ss
        except Exception:
            _ls = lambda: 1.0; _ss = lambda v: None
        self._save_scale = _ss
        scl_row = QHBoxLayout()
        slbl = QLabel("Overlay scale"); slbl.setObjectName("engStatus")
        self._scale_slider = QSlider(Qt.Horizontal)
        self._scale_slider.setMinimum(50); self._scale_slider.setMaximum(180)
        self._scale_slider.setValue(int(round(_ls() * 100)))
        self._scale_slider.setFixedWidth(180)
        self._scale_val = QLabel("%d%%" % self._scale_slider.value())
        self._scale_val.setObjectName("engStatus"); self._scale_val.setFixedWidth(46)
        self._scale_slider.valueChanged.connect(self._on_scale)
        self._btn_test = QPushButton("TEST"); self._btn_test.setObjectName("engLang")
        self._btn_test.setCursor(Qt.PointingHandCursor); self._btn_test.setFixedWidth(64)
        self._btn_test.clicked.connect(self._on_test)
        scl_row.addWidget(slbl); scl_row.addSpacing(10)
        scl_row.addWidget(self._scale_slider); scl_row.addWidget(self._scale_val)
        scl_row.addStretch(); scl_row.addWidget(self._btn_test)
        root.addLayout(scl_row)

        # modalità squadra: UI nella tab dedicata; qui solo lo stato per il write
        try:
            from core import team as _team
        except Exception:
            _team = None
        self._team = _team
        self._live_t = 0.0
        note = QLabel("The engineer starts automatically when you're on track "
                      "and hides in menus and pause.")
        note.setObjectName("engStatus"); note.setWordWrap(True)
        root.addWidget(note)
        self.status = QLabel("\u2014"); self.status.setObjectName("engStatus")
        root.addWidget(self.status)
        # console: cosa fa l'ingegnere (con data/ora), persistente
        from PySide6.QtWidgets import QPlainTextEdit
        clbl = QLabel("CONSOLE"); clbl.setObjectName("engHdr")
        clbl.setStyleSheet("color:#6e727b;font-size:9px;font-weight:800;"
                           "letter-spacing:1.6px;")
        root.addWidget(clbl)
        self.console = QPlainTextEdit(); self.console.setReadOnly(True)
        self.console.setObjectName("engConsole")
        self.console.setMaximumBlockCount(500)
        self.console.setStyleSheet(
            "#engConsole{background:#0c0d10;border:1px solid #2a2c30;border-radius:8px;"
            "color:#9fd8f6;font-family:'Consolas','Menlo','DejaVu Sans Mono',monospace;"
            "font-size:12px;padding:8px;}")
        root.addWidget(self.console, 1)
        try:
            from core import paths as _p
            self._log_file = _p.USER_DIR / "engineer_log.txt"
        except Exception:
            self._log_file = None
        self._load_log_tail()
        self.log("Engineer ready \u00b7 lang %s" % self._lang.upper())
        self.setStyleSheet(
            "#engHdr{color:#eeeeef;font-size:14px;font-weight:800;letter-spacing:1.4px;}"
            "#engLang{background:#1d1f24;color:#9aa0aa;border:1px solid #2a2c30;"
            "border-radius:8px;padding:8px 0;font-size:13px;font-weight:800;}"
            "#engLang:checked{background:#0b1f44;color:#9fd8f6;border:1px solid #45b4ef;}"
            "#engStatus{color:#94979f;font-size:12px;}")
        # overlay automatico: mostrato in pista, nascosto in menu/pausa
        self._ov = None
        self._ov_shown = False
        self._mon = QTimer(self)
        self._mon.timeout.connect(self._monitor)
        self._mon.start(1000)

    def _load_log_tail(self, n=200):
        try:
            if self._log_file and self._log_file.exists():
                lines = self._log_file.read_text(encoding="utf-8").splitlines()[-n:]
                self.console.setPlainText("\n".join(lines))
                sb = self.console.verticalScrollBar(); sb.setValue(sb.maximum())
        except Exception:
            pass

    def log(self, text):
        """Scrive una riga con data/ora nella console (e su file)."""
        import time as _t
        line = "[%s] %s" % (_t.strftime("%Y-%m-%d %H:%M:%S"), text)
        try:
            self.console.appendPlainText(line)
            sb = self.console.verticalScrollBar(); sb.setValue(sb.maximum())
        except Exception:
            pass
        try:
            if self._log_file:
                with open(self._log_file, "a", encoding="utf-8") as fh:
                    fh.write(line + "\n")
        except Exception:
            pass

    def _set_lang(self, lang):
        self._lang = "en" if str(lang).startswith("en") else "it"
        self._btn_it.setChecked(self._lang == "it")
        self._btn_en.setChecked(self._lang == "en")
        self._save_lang(self._lang)
        if self._ov is not None:
            self._ov.set_lang(self._lang)

    # ── overlay automatico (in pista mostra, menu/pausa nascondi) ──
    def _write_live(self, latest):
        """Chi guida pubblica lo stato live nella cartella squadra (~ogni 2s)."""
        if not self._team or not self._team.is_active():
            return
        now = time.monotonic()
        if now - getattr(self, "_live_t", 0.0) < 2.0:
            return
        self._live_t = now
        raw = (latest or {}).get("raw") or {}
        strat = (latest or {}).get("strategy") or {}
        riv = raw.get("rivals") or {}
        b = getattr(self._ov, "brain", None) if getattr(self, "_ov", None) else None
        plan = (strat.get("plan_ve") if strat.get("constraint") == "VE"
                else strat.get("plan_fuel")) or {}
        st = {
            "lap": int(raw.get("laps_completed") or 0),
            "lap_time": raw.get("lap_time"),
            "best": raw.get("best_lap"),
            "fuel_laps": plan.get("autonomy"),
            "target": getattr(b, "_pace_mode", None) if b else None,
            "name_ahead": riv.get("name_ahead") or "",
            "gap_ahead": riv.get("gap_ahead"),
            "track": raw.get("track") or "",
            "car_class": raw.get("car_class") or "",
        }
        try:
            self._team.write_live(st)
        except Exception:
            pass

    def _on_scale(self, v):
        try:
            self._scale_val.setText("%d%%" % v)
        except Exception:
            pass
        f = max(0.5, min(1.8, v / 100.0))
        try:
            self._save_scale(f)
        except Exception:
            pass
        ov = getattr(self, "_ov", None)
        if ov is not None:
            try:
                ov.set_scale(f)
            except Exception:
                pass

    def _on_test(self):
        self._ensure_overlay()
        self._test_until = time.monotonic() + 25.0
        ov = getattr(self, "_ov", None)
        if ov is not None:
            try:
                ov.test_messages()
                self.log("Dev test: spawned sample messages")
            except Exception:
                pass

    def _ensure_overlay(self):
        if self._ov is not None:
            return self._ov
        try:
            from engineer_overlay import EngineerOverlay
        except Exception:
            return None
        self._ov = EngineerOverlay(standalone=False)
        self._ov.set_lang(getattr(self, "_lang", "it"))
        try:
            from core import engineer_learn as _EL
            _m = getattr(getattr(self._win, "_overview", None), "_meta", {}) or {}
            _cls = getattr(self._win, "_car_class", "") or _m.get("car_class", "")
            if self._ov.brain:
                self._ov.brain.set_class(_cls)
            _bl = _EL.baseline(_m.get("track"), _cls)
            if self._ov.brain:
                self._ov.brain.set_baseline(_bl)
        except Exception:
            pass
        return self._ov

    def _set_shown(self, on):
        if on == self._ov_shown:
            return
        self._ov_shown = on
        self.log("On track \u2014 engineer active" if on
                 else "Menu / pause \u2014 engineer hidden")
        if self._ov is None:
            return
        if on:
            self._ov.show(); self._ov.raise_()
        else:
            self._ov.hide()

    def _monitor(self):
        win = self._win
        rec = getattr(win, "_recorder", None)
        if rec is None:
            self._set_shown(False); self.status.setText("\u2014"); return
        try:
            latest = rec.latest()
        except Exception:
            return
        raw = (latest or {}).get("raw") or {}
        ts = raw.get("ts")
        fresh = (ts is not None) and (time.monotonic() - ts < 3.0)
        on_track = bool(raw.get("on_track")) and fresh
        # tenuta test (dev): non nascondere durante un test manuale
        if not on_track and time.monotonic() < getattr(self, "_test_until", 0):
            return
        if on_track:
            self._ensure_overlay()
            self._set_shown(True)
            self._feed_overlay(latest)
            self.status.setText("On track \u2014 engineer active")
            self._write_live(latest)
        else:
            self._set_shown(False)
            self.status.setText("Menu / pause \u2014 hidden" if fresh
                                else "Waiting for the game")

    def _feed_overlay(self, latest):
        if self._ov is None:
            return
        self._ov.feed_latest(latest)
        try:
            raw = (latest or {}).get("raw") or {}
            wet = float(raw.get("wetness") or 0.0)
            self._ov.push_msgs(self._ov.brain.weather([], wet_now=(wet > 0.15)))
            if raw.get("car_class"):
                self._ov.brain.set_class(raw.get("car_class"))
            # accumula la media temperature (gomme carcass + freni); valutazione a giro
            self._ov.brain.temp_tick(raw.get("tyre_temp"), raw.get("brake_temp"),
                                     raw.get("tyre_press"))
            # track limits preventivo (avvisa a un passo dalla penalita')
            self._ov.push_msgs(self._ov.brain.track_limits_live(
                raw.get("tl_steps"), raw.get("tl_pen")))
            # rivali: vicinanza, pit davanti, bandiera gialla
            self._ov.push_msgs(self._ov.brain.rivals(raw.get("rivals")))
            self._last_riv = raw.get("rivals")
            # danni / flat / ruota staccata (evento)
            self._ov.push_msgs(self._ov.brain.damage(raw.get("damage")))
        except Exception:
            pass
        try:
            self._engineer_lap_check(self._win)
        except Exception:
            pass

    def _engineer_lap_check(self, win):
        """A ogni giro chiuso: analisi vs best di stint -> messaggi guida + gomme.
        Usa una connessione PROPRIA (read-only) per non interferire col live."""
        if self._ov is None or self._ov.brain is None:
            return
        f = None
        ss = getattr(win, "_sessions", [])
        cs = getattr(win, "_cur_sess", -1)
        if 0 <= cs < len(ss):
            f = ss[cs].get("file")
        if not f:
            return
        import sqlite3 as _sql
        con = None
        try:
            con = _sql.connect(f)
            con.row_factory = _sql.Row
            self._engineer_lap_eval(con)
        except Exception:
            pass
        finally:
            try:
                if con is not None:
                    con.close()
            except Exception:
                pass

    def _team_publish(self, con, rows):
        """Chi guida pubblica ogni giro chiuso (telemetria inclusa) nella
        cartella di gara condivisa. Uno scrittore alla volta = chi e' in pista."""
        t = getattr(self, "_team", None)
        if t is None:
            return
        cfg = t.load_cfg()
        if not cfg.get("enabled") or not cfg.get("dir"):
            return
        try:
            from core import team_session as TS
            race = TS.join_or_start(cfg["dir"], t.team_name() or "team", driving=True)
            if race is None:
                return
            TS.touch_race(cfg["dir"], race)
            exported = getattr(self, "_team_exported", set())
            driver = t.driver_name() or ""
            for r in rows:
                lp = r["lap"]
                if lp in exported or not r["lap_time"] or r["lap_time"] <= 0:
                    continue
                if TS.export_lap(con, lp, race, driver=driver, stint=r["stint"] or 1):
                    exported.add(lp)
            self._team_exported = exported
        except Exception:
            pass

    def _engineer_lap_eval(self, con):
        rows = con.execute(
            "SELECT lap,stint,lap_time,invalid,s1,s2,s3,w_fl,w_fr,w_rl,w_rr "
            "FROM laps WHERE lap_time>0 ORDER BY lap").fetchall()
        if not rows:
            return
        last = rows[-1]
        last_lap = last["lap"]
        prev_seen = getattr(self, "_eng_last_lap", None)
        if last_lap == prev_seen:
            return                          # nessun giro nuovo
        self._eng_last_lap = last_lap
        self._team_publish(con, rows)
        if prev_seen is None:
            return                          # primo giro: niente confronto
        cur_stint = last["stint"]
        svalid = [r for r in rows if r["stint"] == cur_stint and not r["invalid"]]
        best = min(svalid, key=lambda r: r["lap_time"]) if svalid else None
        out = []
        # ── analisi guida ANTICIPATA: curva peggiore + consiglio per il settore ──
        drive_msgs = []; tip = None
        try:
            if best is not None and len(svalid) >= 2 and last_lap != best["lap"]:
                from core.analysis import analyze
                res = analyze(con, last_lap, con, best["lap"])
                if res:
                    drive_msgs = self._ov.brain.driving(res)
                    tip = getattr(self._ov.brain, "_last_tip", None)
        except Exception:
            drive_msgs = []; tip = None
        # ── tempo giro (verde/fuxia/bianco) + settore peggiore con consiglio ──
        try:
            bs = [best["s1"], best["s2"], best["s3"]] if best else None
            ls = [last["s1"], last["s2"], last["s3"]]
            out += self._ov.brain.lap_feedback(
                last["lap_time"], best["lap_time"] if best else None, ls, bs, tip=tip)
        except Exception:
            pass
        out += drive_msgs
        # relative: pilota davanti in classe, a fine giro ogni 3 giri
        try:
            out += self._ov.brain.relative_lap(getattr(self, "_last_riv", None), last_lap)
        except Exception:
            pass
        # ── track limits: giro cancellato ──
        try:
            if last["invalid"]:
                out += self._ov.brain.track_limits_lap(True)
        except Exception:
            pass
        # ── temperature medie gomme/freni (valutazione a giro, persistenza+isteresi) ──
        try:
            out += self._ov.brain.temps_lap()
        except Exception:
            pass
        if out:
            self._ov.push_msgs(out)
        # da qui serve un best valido con almeno 2 giri puliti nello stint
        if best is None or len(svalid) < 2 or last_lap == best["lap"]:
            return
        # ── gomme: usura/giro front/rear vs miglior giro (meno usura) ──
        tmsgs = []
        try:
            def consumed(prev, cur, ks):
                pv = [prev[k] for k in ks if prev[k] is not None]
                cv = [cur[k] for k in ks if cur[k] is not None]
                if len(pv) != len(ks) or len(cv) != len(ks):
                    return None
                return (sum(pv) / len(pv)) - (sum(cv) / len(cv))
            by_lap = {r["lap"]: r for r in rows if r["stint"] == cur_stint}
            order = sorted(by_lap)
            fr_list, re_list = {}, {}
            for i in range(1, len(order)):
                pr, cu = by_lap[order[i - 1]], by_lap[order[i]]
                f = consumed(pr, cu, ("w_fl", "w_fr"))
                r = consumed(pr, cu, ("w_rl", "w_rr"))
                if f is not None and f >= 0:
                    fr_list[order[i]] = f
                if r is not None and r >= 0:
                    re_list[order[i]] = r
            cf = fr_list.get(last_lap); cr = re_list.get(last_lap)
            bf = min(fr_list.values()) if fr_list else None
            br = min(re_list.values()) if re_list else None
            tmsgs += self._ov.brain.tyres(cf, cr, bf, br, 0)
            # check gomme ogni 5 giri: usura/giro per ruota + freddo
            prev = None
            if last_lap in order:
                _idx = order.index(last_lap)
                if _idx > 0:
                    prev = by_lap.get(order[_idx - 1])
            w4 = None
            if prev is not None:
                w4 = []
                for k in ("w_fl", "w_fr", "w_rl", "w_rr"):
                    a, b = prev[k], last[k]
                    w4.append((a - b) if (a is not None and b is not None and a - b >= 0) else None)
            cold = False
            try:
                tw = self._ov.brain._tyre_win
                te = self._ov.brain._tyre_ema
                cold = (te is not None and te < tw["cold"])
            except Exception:
                cold = False
            tmsgs += self._ov.brain.tyre_check(w4, last_lap, cold=cold)
        except Exception:
            pass
        self._ov.push_msgs(tmsgs)

    def run(self):
        win = self._win
        data = getattr(win, "_data", None)
        if data is None or getattr(data, "con", None) is None:
            self._placeholder("No session loaded."); return
        try:
            sel, _ = win._cur_sel_cmp()
        except Exception:
            sel = None
        if sel is None:
            self.status.setText("Select a lap first.")
            self._placeholder("Select a lap first."); return
        if getattr(data, "ref_lap", None) is None:
            self.status.setText("No REF available.")
            self._placeholder("No REF set for this car/track. Set a reference "
                              "lap, then analyze."); return
        try:
            from core.analysis import analyze
            res = analyze(data.con, sel, data.ref_con or data.con, data.ref_lap)
        except Exception:
            res = None
        if not res:
            self.status.setText("")
            self._placeholder("Not enough telemetry to analyze this lap."); return
        self.status.setText("")
        self._render(res)

    def _card(self, title):
        card = QFrame(); card.setObjectName("engCard")
        cv = QVBoxLayout(card); cv.setContentsMargins(14, 12, 14, 14); cv.setSpacing(6)
        if title:
            hdr = QLabel(title); hdr.setObjectName("engHdr")
            cv.addWidget(hdr)
            line = QFrame(); line.setObjectName("svmHdrLine"); line.setFixedHeight(1)
            cv.addWidget(line); cv.addSpacing(2)
        return card, cv

    def _render(self, res):
        self._clear()
        # riepilogo
        card, cv = self._card("")
        gap = res["gap"]
        sign = "+" if gap >= 0 else "\u2212"
        big = QLabel("Lap %s\u2003vs REF %s\u2003%s%.3fs" % (
            _eng_fmt_t(res["sel_time"]), _eng_fmt_t(res["ref_time"]),
            sign, abs(gap)))
        big.setObjectName("engBig")
        sub = QLabel("Recoverable in the zones below: \u2248 %.3fs over %d m"
                     % (res["lost_total"], int(res["dist"])))
        sub.setStyleSheet("color:#94979f;font-size:12px;")
        cv.addWidget(big); cv.addWidget(sub)
        self.hl.addWidget(card)

        # zone dove perdi
        if res["zones"]:
            card, cv = self._card("WHERE YOU LOSE")
            for z in res["zones"]:
                row = QFrame(); row.setObjectName("engRow")
                rl = QVBoxLayout(row); rl.setContentsMargins(12, 8, 12, 8); rl.setSpacing(3)
                top = QHBoxLayout(); top.setSpacing(8)
                ph = QLabel(z["phase"]); ph.setObjectName("engPhase")
                col = self._PHASE_COL.get(z["phase"], "#a7aaaf")
                ph.setStyleSheet("#engPhase{color:#09090b;background:%s;}" % col)
                dist = QLabel("%d\u2013%d m" % (int(z["d0"]), int(z["d1"])))
                dist.setStyleSheet("color:#a7aaaf;font-size:12px;")
                lost = QLabel("\u2212%.3fs" % z["lost"]); lost.setObjectName("engLost")
                top.addWidget(ph); top.addWidget(dist); top.addStretch()
                top.addWidget(lost)
                cause = QLabel(z["cause"]); cause.setObjectName("engCause")
                tip = QLabel("\u2192 " + z["tip"]); tip.setObjectName("engTip")
                tip.setWordWrap(True)
                rl.addLayout(top); rl.addWidget(cause); rl.addWidget(tip)
                cv.addWidget(row)
            self.hl.addWidget(card)

        # consigli assetto
        card, cv = self._card("SETUP SUGGESTIONS")
        if res["setup"]:
            for s in res["setup"]:
                row = QFrame(); row.setObjectName("engRow")
                rl = QVBoxLayout(row); rl.setContentsMargins(12, 8, 12, 8); rl.setSpacing(3)
                area = QLabel(s["area"]); area.setObjectName("engArea")
                obs = QLabel(s["obs"]); obs.setObjectName("engObs"); obs.setWordWrap(True)
                chg = QLabel("\u2192 " + s["change"]); chg.setObjectName("engChange")
                chg.setWordWrap(True)
                rl.addWidget(area); rl.addWidget(obs); rl.addWidget(chg)
                cv.addWidget(row)
        else:
            ok = QLabel("Balance looks consistent with the reference \u2014 "
                        "the gap is mostly driving, not setup.")
            ok.setObjectName("engObs"); ok.setWordWrap(True)
            cv.addWidget(ok)
        self.hl.addWidget(card)
        self.hl.addStretch()


class _OverviewTab(QWidget):
    """Tab d'apertura: identita pilota/team (modificabile), logo team, logo
    circuito, condizioni della sessione (striscia compatta) e la board tempi
    (tab stint + riga REF + giri con checkbox)."""
    _EMPTY_SVG = b"<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'/>"

    def __init__(self):
        super().__init__()
        self._meta = {}
        self._live = False
        self._reader = None
        self._load_overrides()
        self._build()
        self._refresh_display()
        self._timer = QTimer(self); self._timer.setInterval(1000)
        self._timer.timeout.connect(self._live_tick); self._timer.start()

    def set_empty(self, flag):
        """Mostra solo 'No data yet' e nasconde card condizioni / REF / board."""
        for w in (self._cond_card, self.ref_card, self.board, self.board.tabs_bar, self.stint_card):
            w.setVisible(not flag)
        self._empty_state.setVisible(False)

    def set_live(self, on):
        """Attiva la lettura LIVE delle condizioni mentre si registra (START)."""
        self._live = bool(on)
        if self._live and self._reader is None:
            try:
                self._reader = TelemetryReader()
            except Exception:
                self._reader = None

    def _live_tick(self):
        if not self._live or self._reader is None:
            return
        try:
            d = self._reader.read()
        except Exception:
            d = {}
        if not d:
            return
        self.set_meta({
            "driver": d.get("driver"), "team": d.get("team"),
            "vehicle": d.get("vehicle"), "car_class": d.get("car_class"),
            "track": d.get("track"), "session_type": d.get("session_type"),
            "air_temp": d.get("air_temp"), "track_temp": d.get("track_temp"),
            "wetness": d.get("wetness"),
            "compound_f": d.get("compound_front"), "compound_r": d.get("compound_rear"),
            "compounds4": ",".join(d.get("tyre_compound4") or []),
            "fuel_start": d.get("fuel"),
            "_laps": d.get("laps_completed"), "_best": None,
            "_race_remaining": d.get("race_remaining"),
            "_race_total": d.get("race_total"),
        })

    # ── persistenza override pilota/team ──
    def _ovr_file(self):
        from core.paths import USER_DIR
        return USER_DIR / "overview.json"

    def _load_overrides(self):
        import json
        try:
            self._ovr = json.loads(self._ovr_file().read_text(encoding="utf-8"))
        except Exception:
            self._ovr = {}

    def _save_overrides(self):
        import json
        try:
            self._ovr_file().write_text(json.dumps(self._ovr, ensure_ascii=False, indent=2),
                                        encoding="utf-8")
        except Exception:
            pass

    def _build(self):
        outer = QHBoxLayout(self); outer.setContentsMargins(16, 14, 16, 14); outer.setSpacing(14)
        self._build_session_list(outer)
        right = QWidget()
        root = QVBoxLayout(right); root.setContentsMargins(4, 0, 4, 4); root.setSpacing(10)
        # ── card CONDIZIONI: logo circuito a sinistra + condizioni sessione ──
        # (driver/auto/classe stanno già nella lista sessioni a sinistra)
        card = QFrame(); card.setObjectName("ovCard"); self._cond_card = card
        cl = QHBoxLayout(card); cl.setContentsMargins(16, 10, 18, 10); cl.setSpacing(18)
        tboxf = QFrame(); tboxf.setObjectName("ovTrackBox")
        tl = QVBoxLayout(tboxf); tl.setContentsMargins(0, 0, 0, 0); tl.setSpacing(4)
        self.track_logo = _SvgBox(); self.track_logo.setFixedSize(82, 48)
        self.lb_track = QLabel("\u2014"); self.lb_track.setObjectName("ovTrack")
        self.lb_track.setVisible(False)
        tl.addWidget(self.track_logo, 0, Qt.AlignCenter)
        cl.addWidget(tboxf, 0)
        # condizioni sessione
        cond = QVBoxLayout(); cond.setSpacing(3)
        cond.addStretch()
        self.lb_sess = QLabel("\u2014"); self.lb_sess.setObjectName("ovSessName")
        self.lb_clock = QLabel(""); self.lb_clock.setObjectName("ovSessClock")
        self.lb_cond = QLabel("\u2014"); self.lb_cond.setObjectName("ovCondLine")
        self.lb_cond.setTextFormat(Qt.RichText)
        cond.addWidget(self.lb_sess)
        cond.addWidget(self.lb_cond)
        cond.addStretch()
        cl.addLayout(cond, 1)
        cl.addWidget(self.lb_clock, 0, Qt.AlignRight | Qt.AlignVCenter)
        # widget identità tenuti staccati (info nella lista sessioni); servono a
        # _refresh_display / _on_edit ma non sono mostrati in questa card.
        self.logo = _SvgBox(); self.logo.setFixedSize(1, 1)
        self.ed_driver = QLineEdit(); self.ed_driver.setObjectName("ovDriver")
        self.ed_team = QLineEdit(); self.ed_team.setObjectName("ovTeam")
        self.lb_car = QLabel(""); self.lb_car.setObjectName("ovCar")
        self.ed_driver.editingFinished.connect(self._on_edit)
        self.ed_team.editingFinished.connect(self._on_edit)
        root.addWidget(card)
        # ── riga REF (record): spostata nella colonna SINISTRA sotto le sessioni ──
        self.ref_card = QWidget()
        self.ref_card.setFixedWidth(600)        # stessa misura delle card sessioni
        self._refcard_l = QVBoxLayout(self.ref_card)
        self._refcard_l.setContentsMargins(0, 0, 0, 0); self._refcard_l.setSpacing(6)
        self._left_col.addWidget(self.ref_card, 0, Qt.AlignTop)
        self._left_col.addStretch()
        self._vals = {}
        for name in ("Session", "Weather", "Air temp", "Track temp", "Track wetness",
                     "Fuel (start)", "Compound", "Laps", "Best lap", "Theoretical"):
            self._vals[name] = QLabel()
        # ── board tempi/stint (giri) ──
        self.board = _LapBoard()
        root.addWidget(self.board.tabs_bar)   # tab stint sopra la card
        self.stint_card = QFrame(); self.stint_card.setObjectName("ovCard")
        self.stint_card.setStyleSheet("#ovCard{background:#16181c;border:none;border-radius:5px;}")
        self.stint_card.setMinimumHeight(20)
        self.stint_card_l = QVBoxLayout(self.stint_card)
        self.stint_card_l.setContentsMargins(0, 0, 0, 0); self.stint_card_l.setSpacing(0)
        root.addWidget(self.stint_card)       # card #16181c sotto stint (da riempire)
        self.stint_card_l.addWidget(self.board.lb_summary)  # riga dati stint
        root.addWidget(self.board, 1)
        # stato "nessun dato": nasconde card/REF/board al primo avvio
        self._empty_state = QLabel("No data yet"); self._empty_state.setObjectName("ovNoData")
        self._empty_state.setAlignment(Qt.AlignCenter); self._empty_state.setVisible(False)
        root.addWidget(self._empty_state, 1)
        outer.addWidget(right, 1)
        self.setStyleSheet(
            "#ovCard{background:#16181c;border:none;border-radius:10px;}"
            "#ovNoData{color:#5c5f68;font-size:14px;background:transparent;}"
            "#ovTrackBox{background:transparent;border:none;}"
            "#ovSessName{color:#f2f4f7;font-size:17px;font-weight:700;background:transparent;}"
            "#ovSessClock{color:#45b4ef;font-size:17px;font-weight:700;background:transparent;}"
            "#ovCondLine{color:#a7aaaf;font-size:13px;background:transparent;}"
            "#ovInfoLine{color:#cfd2d8;font-size:12px;background:transparent;}"
            "#ovListCard{background:#191b1f;border:none;border-radius:0;}"
            "QScrollBar:horizontal{height:0px;background:transparent;}"
            "#ovHead{color:#6e727b;font-size:11px;font-weight:700;letter-spacing:2px;}"
            "#ovDriver{background:transparent;border:none;color:#f2f4f7;font-size:16px;font-weight:600;}"
            "#ovTeam{background:transparent;border:none;color:#a7aaaf;font-size:12px;}"
            "#ovDriver:focus,#ovTeam:focus{border-bottom:1px solid #3a3d43;}"
            "#ovCar{color:#6e727b;font-size:12px;}"
            "#ovTrack{color:#bdbfc3;font-size:11px;font-weight:600;letter-spacing:1px;}"
            "#ovRowA,#ovRowB{background:#1d1f24;border-radius:8px;}"
            "#ovRowA:hover,#ovRowB:hover{background:#23262d;}"
            "#ovKey{color:#989ba2;font-size:13px;background:transparent;}"
            "#ovVal{color:#f2f4f7;font-size:14px;font-weight:600;background:transparent;}"
            "#ovRowTitle{color:#f2f4f7;font-size:13px;font-weight:600;background:transparent;}"
            "#ovRowSub{color:#989ba2;font-size:11px;background:transparent;}"
            "#ovRowDim{color:#61646d;font-size:11px;background:transparent;}"
            "#ovSelRow{background:#262a31;border-left:2px solid #45b4ef;border-radius:8px;}"
            "#ovRowIcon{background:transparent;border:none;color:#7e828c;font-size:14px;}"
            "#ovRowIcon:hover{color:#ff5b6e;}"
            "#ovIcon{background:transparent;border:none;color:#989ba2;font-size:15px;}"
            "#ovIcon:hover{color:#f2f4f7;}"
            "#ovBadgeDry{color:#1a1400;background:#f5c542;border-radius:6px;"
            "padding:1px 7px;font-size:10px;font-weight:700;}"
            "#ovBadgeWet{color:#04222e;background:#4ec3ff;border-radius:6px;"
            "padding:1px 7px;font-size:10px;font-weight:700;}"
            # striscia condizioni compatta
            "#ovStatKey{color:#6e727b;font-size:10px;font-weight:700;letter-spacing:1px;background:transparent;}"
            "#ovStatVal{color:#f2f4f7;font-size:14px;font-weight:600;background:transparent;}"
            # board tempi
            "#ovColCap{color:#5c5f68;font-size:10px;font-weight:700;letter-spacing:1px;background:transparent;}"
            "#ovColCapSel{color:#55ff7f;font-size:9px;font-weight:700;letter-spacing:1px;background:transparent;}"
            "#ovColCapCmp{color:#8b7bff;font-size:9px;font-weight:700;letter-spacing:1px;background:transparent;}"
            "#ovTheo{color:#45b4ef;font-size:11px;font-weight:700;letter-spacing:.5px;background:transparent;}"
            "#ovTabOn{background:#262a31;border:none;border-left:2px solid #45b4ef;border-radius:8px;}"
            "#ovTabOff{background:#1d1f24;border:none;border-radius:8px;}"
            "#ovTabOff:hover{border-color:#3a3d43;}"
            "#ovTabTxt{color:#f2f4f7;font-size:11px;font-weight:700;letter-spacing:.5px;background:transparent;}"
            "#ovStintSum{color:#838790;font-size:12px;background:transparent;}"
            "#ovTabOff #ovTabTxt{color:#989ba2;}"
            # riga REF (oro)
            "#ovRefRow{background:#1f1c12;border:none;border-radius:10px;}"
            "#ovRefEmpty{background:#111214;border:1px dashed #2a2c30;border-radius:10px;}"
            "#ovRefTag{color:#f5c542;font-size:12px;font-weight:800;letter-spacing:1px;background:transparent;}"
            "#ovRefDrv{color:#f5f5f5;font-size:13px;font-weight:600;background:transparent;}"
            "#ovRefTime{color:#f5c542;font-size:14px;font-weight:700;background:transparent;}"
            "#ovRefSec{color:#9c8a4e;font-size:12px;background:transparent;}"
            "#ovRefNone{color:#6e727b;font-size:12px;background:transparent;}"
            "#ovRefSub{color:#7c7148;font-size:10px;background:transparent;padding-left:12px;}"
            "#ovRefInfo{color:#cfd2d8;font-size:11px;background:transparent;padding-left:12px;}"
            "#ovWrRow{background:#10212c;border:none;border-radius:10px;}"
            "#ovWrTag{color:#39b6e8;font-size:12px;font-weight:800;letter-spacing:1px;background:transparent;}"
            "#ovWrDrv{color:#f5f5f5;font-size:13px;font-weight:600;background:transparent;}"
            "#ovWrTime{color:#39b6e8;font-size:14px;font-weight:700;background:transparent;}"
            "#ovWrSec{color:#5f93ad;font-size:12px;background:transparent;}"
            "#ovWrSub{color:#5f93ad;font-size:10px;background:transparent;padding-left:12px;}"
            # righe giro — ogni giro è una card
            "#ovLapRow{background:#181a1e;border:none;border-radius:10px;}"
            "#ovLapRow:hover{background:#1a1b1f;border-color:#2a2c30;}"
            "#ovLapSel{background:#23262c;border:none;border-radius:10px;}"
            "#ovLapDis{background:#14161a;border:none;border-radius:10px;}"
            "#ovLapBestCard{background:#241420;border:none;border-radius:10px;}"
            "#ovLapNo{color:#bdbfc3;font-size:13px;font-weight:600;background:transparent;}"
            "#ovLapInv{color:#60636c;font-size:13px;background:transparent;}"
            "#ovLapTime{color:#f5f5f5;font-size:14px;font-weight:600;background:transparent;}"
            "#ovLapBest{color:#ff5bb0;font-size:14px;font-weight:700;background:transparent;}"
            "#ovSec{color:#989ba2;font-size:12px;background:transparent;}"
            "#ovSecBest{color:#ff3bd4;font-size:12px;background:transparent;}"
            "#ovSecInv{color:#4c4f57;font-size:12px;background:transparent;}"
            "#ovTagOut{color:#838790;font-size:9px;font-weight:700;letter-spacing:1px;"
            "background:#202225;border-radius:4px;padding:1px 5px;margin-left:6px;}"
            "#ovTagTL{color:#ffcc33;font-size:9px;font-weight:700;letter-spacing:1px;"
            "background:#2a2410;border-radius:4px;padding:1px 5px;margin-left:6px;}"
            "#ovTagInv{color:#e06a6a;font-size:9px;font-weight:700;letter-spacing:1px;"
            "background:#2a1618;border-radius:4px;padding:1px 5px;margin-left:6px;}"
            "#ovTagPit{color:#f0a23a;font-size:9px;font-weight:700;letter-spacing:1px;"
            "background:#241a10;border-radius:4px;padding:1px 5px;margin-left:6px;}"
            # checkbox
            "#ovCkOff{background:transparent;border:1.5px solid #3a3d43;border-radius:4px;}"
            "#ovCkOff:hover{border-color:#60636c;}"
            "#ovCkSelOn{background:transparent;border:2px solid #55ff7f;border-radius:4px;}"
            "#ovCkCmpOn{background:transparent;border:2px solid #8b7bff;border-radius:4px;}"
            "#ovCkRefOn{background:transparent;border:2px solid #f5c542;border-radius:4px;}")
        if self._ovr.get("driver"):
            self.ed_driver.setText(self._ovr["driver"])
        if self._ovr.get("team"):
            self.ed_team.setText(self._ovr["team"])

    def _on_edit(self):
        self._ovr["driver"] = self.ed_driver.text().strip()
        self._ovr["team"] = self.ed_team.text().strip()
        self._save_overrides()

    def set_ref(self, ref, ref_is_cmp, theo, on_pick, pace=None):
        """Card REF (record personale) + card PACE (riferimento dal CSV).
        Real lap (record reale) rimosso."""
        _clear_layout(self._refcard_l)
        if not ref:
            row = QFrame(); row.setObjectName("ovRefEmpty")
            h = QHBoxLayout(row); h.setContentsMargins(12, 10, 12, 10)
            lb = QLabel("REF \u2014  no record yet"); lb.setObjectName("ovRefNone")
            h.addWidget(lb)
            self._refcard_l.addWidget(row)
        else:
            card = _ClickFrame(lambda: on_pick(("ref",)))
            card.setObjectName("ovRefRow")
            cv = QVBoxLayout(card); cv.setContentsMargins(0, 4, 0, 8); cv.setSpacing(2)
            rw = QWidget(); rw.setStyleSheet("background:transparent;")
            h = QHBoxLayout(rw); h.setContentsMargins(12, 6, 16, 4); h.setSpacing(0)
            ckc = _mk_check(lambda: on_pick(("ref",)), _GOLD, bool(ref_is_cmp), _GOLD)
            ckc.setToolTip("Compare vs REF")
            logo = _SvgBox(); logo.setFixedSize(54, 38)
            _car_logo_into(logo, ref.get("team"), ref.get("vehicle"))
            h.addWidget(logo, 0, Qt.AlignVCenter); h.addSpacing(10)
            col = QWidget(); col.setStyleSheet("background:transparent;")
            col.setFixedWidth(200)
            coll = QVBoxLayout(col); coll.setContentsMargins(0, 0, 0, 0); coll.setSpacing(0)
            r1 = QLabel((ref.get("driver") or "").strip() or "record")
            r1.setObjectName("ovRefDrv")
            r2 = QLabel(get_team() or "\u2014")
            r2.setStyleSheet("color:#b9ad84;font-size:12px;background:transparent;")
            r3 = QLabel((ref.get("vehicle") or "").strip() or "\u2014")
            r3.setStyleSheet("color:#e8c87a;font-size:12px;font-weight:600;background:transparent;")
            coll.addWidget(r1); coll.addWidget(r2); coll.addWidget(r3)
            h.addWidget(col, 0, Qt.AlignVCenter); h.addSpacing(40)
            from core.tyre_cell import TyreCell
            _four, _single = _comp_four_single(ref.get("compounds4"))
            _w4 = ref.get("wear4") or []
            _new4 = ([(w is not None and w >= 97) for w in _w4]
                     if len(_w4) == 4 else None)
            _snew = all(_new4) if _new4 else True
            col2 = QWidget(); c2 = QVBoxLayout(col2)
            c2.setContentsMargins(0, 0, 0, 0); c2.setSpacing(0)
            tc = TyreCell(size=24); tc.set_tyre(_single, _four, new4=_new4, single_new=_snew)
            tc.setFixedHeight(24)
            c2.addWidget(tc, 0, Qt.AlignHCenter)
            _ts = ref.get("tyre_state")
            pclose = QLabel(("%.0f%%" % _ts) if _ts is not None else "\u2014")
            pclose.setStyleSheet("color:#e8eaee;font-size:12px;font-weight:700;background:transparent;")
            pclose.setAlignment(Qt.AlignHCenter)
            c2.addWidget(pclose, 0, Qt.AlignHCenter)
            h.addWidget(col2, 0, Qt.AlignVCenter); h.addSpacing(26)
            # colonna carico benzina: simbolo + kg (litri x 0.75)
            _fl = ref.get("fuel_l")
            _kg = (_fl * 0.75) if _fl is not None else None
            col3 = QWidget(); c3 = QVBoxLayout(col3)
            c3.setContentsMargins(0, 0, 0, 0); c3.setSpacing(0)
            fsym = _SvgBox(); fsym.setFixedSize(24, 24)
            fsym.load(_FUEL_WEIGHT_SVG.encode())
            c3.addWidget(fsym, 0, Qt.AlignHCenter)
            fkg = QLabel(("+%.0f kg" % _kg) if _kg is not None else "\u2014")
            fkg.setStyleSheet("color:#e8eaee;font-size:12px;font-weight:700;background:transparent;")
            fkg.setAlignment(Qt.AlignHCenter)
            c3.addWidget(fkg, 0, Qt.AlignHCenter)
            h.addWidget(col3, 0, Qt.AlignVCenter)
            h.addStretch()
            t = QLabel(_fmt(ref.get("time")) if ref.get("time") else "\u2014")
            t.setObjectName("ovRefTime"); t.setFixedWidth(84)
            t.setAlignment(Qt.AlignRight | Qt.AlignVCenter); h.addWidget(t)
            h.addSpacing(12); h.addWidget(ckc, 0, Qt.AlignVCenter)
            cv.addWidget(rw)
            self._refcard_l.addWidget(card)
        if pace is not None:
            _pc = self._build_pace_card(pace, on_pick)
            if _pc is not None:
                self._refcard_l.addWidget(_pc)

    def _build_pace_card(self, pace, on_pick=None):
        """Card 'ONLINE REF': riferimento esterno dal foglio laptimes (Ohne Speed).
        Check azzurro (default ON): se attivo, sul giro migliore compaiono
        dicitura e gap. Riga: check + logo auto + ONLINE REF + 'Peter - OhneSpeed'
        + tempo. Sotto: pace/hotlap + data del documento aggiornato."""
        # nessun dato online -> niente card (resta nascosta finché non c'è un tempo)
        if not (pace and pace.get("online")):
            return None
        _BLUE = "#4aa3df"
        card = QFrame(); card.setObjectName("ovWrRow")
        cv = QVBoxLayout(card); cv.setContentsMargins(0, 4, 0, 8); cv.setSpacing(2)
        rw = QWidget(); rw.setStyleSheet("background:transparent;")
        h = QHBoxLayout(rw); h.setContentsMargins(12, 6, 16, 4); h.setSpacing(0)
        sel = bool(pace.get("sel", True))
        ck = _mk_check(lambda: on_pick(("pace",)) if on_pick else None,
                       _BLUE, sel, _BLUE)
        ck.setToolTip("Show pace label & gap on best lap")
        car_nm = pace.get("car")
        box = _SvgBox(); box.setFixedSize(54, 38)
        _car_logo_into(box, pace.get("team"), car_nm)
        h.addWidget(box, 0, Qt.AlignVCenter); h.addSpacing(10)
        col = QWidget(); col.setStyleSheet("background:transparent;")
        col.setFixedWidth(200)
        coll = QVBoxLayout(col); coll.setContentsMargins(0, 0, 0, 0); coll.setSpacing(0)
        _drv = pace.get("player") or "\u2014"
        _tm = pace.get("team") or "\u2014"
        _car = car_nm or "\u2014"
        r1 = QLabel(_drv); r1.setObjectName("ovRefDrv")
        r2 = QLabel(_tm)
        r2.setStyleSheet("color:#5f93ad;font-size:12px;background:transparent;")
        r3 = QLabel(_car)
        r3.setStyleSheet("color:#7bbde8;font-size:12px;font-weight:600;background:transparent;")
        coll.addWidget(r1); coll.addWidget(r2); coll.addWidget(r3)
        h.addWidget(col, 0, Qt.AlignVCenter); h.addSpacing(40)
        # colonna gomma (placeholder finché non arriva il Worker)
        from core.tyre_cell import TyreCell
        col2 = QWidget(); c2 = QVBoxLayout(col2)
        c2.setContentsMargins(0, 0, 0, 0); c2.setSpacing(0)
        tc = TyreCell(size=24)
        _c4 = pace.get("compounds4") or ""
        _four = [x.strip() for x in _c4.split(",") if x.strip()]
        _single = pace.get("compound") or (_four[0] if _four else "M")
        _tsv = pace.get("tyre_state_pct")
        _newv = (_tsv is None) or (_tsv >= 99.5)
        if len(_four) == 4:
            tc.set_tyre(_single, _four, new4=[_newv, _newv, _newv, _newv],
                        single_new=_newv)
        else:
            tc.set_tyre(_single, None, single_new=_newv)
        tc.setFixedHeight(24)
        c2.addWidget(tc, 0, Qt.AlignHCenter)
        _ts = pace.get("tyre_state_pct")
        pcl = QLabel(("%.0f%%" % _ts) if _ts is not None else "\u2014")
        pcl.setStyleSheet("color:#e8eaee;font-size:12px;font-weight:700;background:transparent;")
        pcl.setAlignment(Qt.AlignHCenter)
        c2.addWidget(pcl, 0, Qt.AlignHCenter)
        h.addWidget(col2, 0, Qt.AlignVCenter); h.addSpacing(26)
        # colonna carico benzina (placeholder finché non arriva il Worker)
        col3 = QWidget(); c3 = QVBoxLayout(col3)
        c3.setContentsMargins(0, 0, 0, 0); c3.setSpacing(0)
        fsym = _SvgBox(); fsym.setFixedSize(24, 24)
        fsym.load(_FUEL_WEIGHT_SVG.encode())
        c3.addWidget(fsym, 0, Qt.AlignHCenter)
        _fl = pace.get("fuel_l")
        _kg = (_fl * 0.75) if _fl is not None else None
        fkg = QLabel(("+%.0f kg" % _kg) if _kg is not None else "\u2014")
        fkg.setStyleSheet("color:#e8eaee;font-size:12px;font-weight:700;background:transparent;")
        fkg.setAlignment(Qt.AlignHCenter)
        c3.addWidget(fkg, 0, Qt.AlignHCenter)
        h.addWidget(col3, 0, Qt.AlignVCenter)
        h.addStretch()
        t = QLabel(_fmt(pace.get("ref_time")) if (pace and pace.get("ref_time")) else "\u2014")
        t.setObjectName("ovWrTime"); t.setFixedWidth(84)
        t.setAlignment(Qt.AlignRight | Qt.AlignVCenter); h.addWidget(t)
        h.addSpacing(12); h.addWidget(ck, 0, Qt.AlignVCenter)
        cv.addWidget(rw)
        return card

    def _build_session_list(self, outer):
        self._sel_cb = None; self._del_cb = None; self._open_cb = None
        panel = QFrame(); panel.setObjectName("ovListCard"); panel.setFixedWidth(600)
        pl = QVBoxLayout(panel); pl.setContentsMargins(0, 0, 0, 0); pl.setSpacing(0)
        from PySide6.QtWidgets import QScrollArea
        self._list_scroll = QScrollArea(); self._list_scroll.setWidgetResizable(True)
        self._list_scroll.setFrameShape(QFrame.NoFrame)
        self._list_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self._list_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._list_host = QWidget()
        self._list_v = QVBoxLayout(self._list_host)
        self._list_v.setContentsMargins(0, 0, 0, 0); self._list_v.setSpacing(6)
        self._list_v.addStretch()
        self._list_scroll.setWidget(self._list_host)
        self._list_scroll.setFixedHeight(82 * 3 + 6 * 2)   # sempre 3 card, poi scroll
        pl.addWidget(self._list_scroll, 1)
        # colonna sinistra verticale: lista sessioni (3 card) + card REF sotto
        leftw = QWidget()
        self._left_col = QVBoxLayout(leftw)
        self._left_col.setContentsMargins(0, 0, 0, 0); self._left_col.setSpacing(10)
        self._left_col.addWidget(panel, 0, Qt.AlignTop)
        outer.addWidget(leftw, 0, Qt.AlignTop)
        self._rows_w = []

    def set_sessions(self, sessions, current_idx, on_select, on_delete, on_open):
        self._sel_cb = on_select; self._del_cb = on_delete; self._open_cb = on_open
        while self._list_v.count() > 1:                  # rimuovi righe (tiene lo stretch finale)
            it = self._list_v.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()
        self._rows_w = []
        for i, s in enumerate(sessions):
            row = _SessionRow(i, s, i == current_idx, on_select, on_delete,
                              _OverviewTab._EMPTY_SVG, on_open)
            self._list_v.insertWidget(self._list_v.count() - 1, row)
            self._rows_w.append(row)
        # porta in vista la sessione selezionata (lista alta 3 card)
        if 0 <= current_idx < len(self._rows_w):
            from PySide6.QtCore import QTimer
            _row = self._rows_w[current_idx]
            QTimer.singleShot(0, lambda: self._list_scroll.ensureWidgetVisible(_row))

    def highlight_session(self, idx):
        for i, row in enumerate(getattr(self, "_rows_w", [])):
            row.set_selected(i == idx)

    def set_meta(self, meta):
        self._meta = meta or {}
        self._refresh_display()

    def _refresh_display(self):
        m = self._meta
        team = m.get("team") or ""
        veh = m.get("vehicle") or ""
        cls = m.get("car_class") or ""
        trk = m.get("track") or ""
        # logo team/auto: prova prima il team (brands.json e indicizzato sul team)
        try:
            from core.brands import brand_from_vehicle
            from core.utils import find_logo_path
            brand = brand_from_vehicle(team) or brand_from_vehicle(veh)
            p = find_logo_path(brand) if brand else None
            self.logo.load(str(p) if p else self._EMPTY_SVG)
        except Exception:
            self.logo.load(self._EMPTY_SVG)
        # tracklogo (mantiene proporzioni)
        f = _ov_tracklogo_file(trk)
        self.track_logo.load(str(f) if f else self._EMPTY_SVG)
        self.lb_track.setText(trk or "\u2014")
        self.ed_driver.setPlaceholderText((m.get("driver") or "") or "Driver")
        self.ed_team.setPlaceholderText((team or "") or "Team")
        self.lb_car.setText(veh + (("   \u00b7   " + cls) if cls else ""))
        # condizioni
        wet = float(m.get("wetness") or 0.0)
        is_wet = wet > 0.10
        wlab = "WET" if is_wet else "DRY"
        at = m.get("air_temp"); tt = m.get("track_temp")
        cf = m.get("compound_f") or ""; cr = m.get("compound_r") or ""
        comp = cf if cf == cr else ((cf + " / " + cr) if (cf or cr) else "")
        if not comp:
            comp = (m.get("compounds4") or "").strip()
        fs = m.get("fuel_start")
        self._vals["Session"].setText(_ov_session_label(m.get("session_type")))
        self._vals["Weather"].setText(wlab)
        self._vals["Weather"].setStyleSheet(
            "background:transparent;font-size:14px;font-weight:700;color:%s;"
            % ("#4ec3ff" if is_wet else "#f5c542"))
        self._vals["Air temp"].setText(f"{at:.0f} \u00b0C" if at is not None else "\u2014")
        self._vals["Track temp"].setText(f"{tt:.0f} \u00b0C" if tt is not None else "\u2014")
        self._vals["Track wetness"].setText(f"{wet * 100:.0f}%")
        self._vals["Fuel (start)"].setText(f"{fs:.1f} L" if fs else "\u2014")
        self._vals["Compound"].setText(comp or "\u2014")
        laps = m.get("_laps")
        self._vals["Laps"].setText(str(laps) if laps is not None else "\u2014")
        best = m.get("_best")
        self._vals["Best lap"].setText(_fmt(best) if best else "\u2014")
        theo = m.get("_theo")
        self._vals["Theoretical"].setText(_fmt(theo) if theo else "\u2014")
        # ── card condizioni (nuova) ──
        styp = _ov_session_label(m.get("session_type"))
        slen = _fmt_session_len(m.get("session_len"))
        self.lb_sess.setText(styp + ((" \u00b7 " + slen) if slen else ""))
        air = f"{at:.0f}\u00b0C" if at is not None else "\u2014"
        trk_t = f"{tt:.0f}\u00b0C" if tt is not None else "\u2014"
        wcol = "#4ec3ff" if is_wet else "#f5c542"
        self.lb_cond.setText(
            "Air %s &nbsp;\u00b7&nbsp; Track %s &nbsp;\u00b7&nbsp; "
            "<span style='color:%s;font-weight:700'>%s</span>" % (air, trk_t, wcol, wlab))
        rr = m.get("_race_remaining")
        if self._live and rr:
            self.lb_clock.setText("Remaining  " + _ov_clock(rr))
            self.lb_clock.setVisible(True)
        else:
            self.lb_clock.setVisible(False)

    def stop(self):
        try:
            self._timer.stop()
        except Exception:
            pass
        try:
            if self._reader:
                self._reader.stop()
        except Exception:
            pass



def _fmt_ms(ms):
    """ms -> 'm:ss.mmm' o 'ss.mmm'. '—' se assente."""
    if not ms:
        return "\u2014"
    s = ms / 1000.0
    return "%d:%06.3f" % (int(s) // 60, s % 60) if s >= 60 else "%.3f" % s


def _track_short(track):
    """Nome pista breve e pulito (es. 'Bahrain Paddock Circuit' -> 'Bahrain',
    'Circuit de Spa Francorchamps' -> 'Spa')."""
    t = (track or "").replace("-", " ").strip()
    tl = t.lower()
    table = [
        ("spa", "Spa"), ("bahrain", "Bahrain"), ("monza", "Monza"),
        ("sarthe", "Le Mans"), ("le mans", "Le Mans"), ("fuji", "Fuji"),
        ("portim", "Portim\u00e3o"), ("algarve", "Portim\u00e3o"),
        ("barcelona", "Barcelona"), ("catalu", "Barcelona"),
        ("paul ricard", "Paul Ricard"), ("ricard", "Paul Ricard"),
        ("imola", "Imola"), ("interlagos", "Interlagos"),
        ("sebring", "Sebring"), ("atlanta", "Road Atlanta"),
        ("americas", "COTA"), ("cota", "COTA"),
        ("lusail", "Qatar"), ("losail", "Qatar"), ("qatar", "Qatar"),
        ("silverstone", "Silverstone"), ("nurburg", "N\u00fcrburgring"),
        ("daytona", "Daytona"), ("watkins", "Watkins Glen"),
    ]
    for k, v in table:
        if k in tl:
            base = v
            break
    else:
        base = t
    # appende la variante di layout (Mulsanne, Outer, Short, ...) se presente,
    # così la classifica distingue i tracciati dello stesso circuito
    try:
        from telemetry.db import _layout_suffix
        lay = _layout_suffix(track)
    except Exception:
        lay = ""
    if lay:
        readable = {"CurvaGrande": "Curva Grande"}.get(lay, lay)
        if readable.lower() not in base.lower():
            base = "%s %s" % (base, readable)
    return base


class _ClassChip(QLabel):
    """Tag classe colorato e cliccabile (come nella scheda sessioni)."""

    def __init__(self, cls, on_click):
        super().__init__(cls or "\u2014")
        self._cls = cls; self._on_click = on_click
        col = _class_color(cls)
        self.setCursor(Qt.PointingHandCursor)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet(
            "QLabel{color:#fff;font-size:10px;font-weight:800;background:%s;"
            "border-radius:4px;padding:3px 9px;}" % col)

    def mousePressEvent(self, e):
        if self._on_click:
            self._on_click(self._cls)


class _TrackRow(QFrame):
    """Riga pista: logo circuito + nome + tag classe colorati cliccabili."""

    def __init__(self, track, classes, on_pick):
        super().__init__()
        self.setObjectName("commTrack")
        self.setStyleSheet("#commTrack{background:#16181c;border:none;"
                           "border-radius:8px;}")
        h = QHBoxLayout(self); h.setContentsMargins(12, 8, 14, 8); h.setSpacing(10)
        disp = (track or "").replace("-", " ")
        logo = _SvgBox(); logo.setFixedSize(50, 32)
        f = _ov_tracklogo_file(disp)
        logo.load(str(f) if f else _EMPTY_LOGO_SVG)
        h.addWidget(logo, 0, Qt.AlignVCenter)
        nm = QLabel(_track_short(track))
        nm.setStyleSheet("color:#f2f4f7;font-size:13px;font-weight:700;"
                         "background:transparent;")
        nm.setMinimumWidth(150)
        h.addWidget(nm)
        h.addStretch()
        for c in classes:
            chip = _ClassChip(c, lambda cc=c: on_pick(track, cc))
            h.addWidget(chip); h.addSpacing(5)


class _RankRow(QFrame):
    """Riga classifica: posizione + pilota/team + logo + gomma + kg + tempo+gap
    + settori. Il 1° in tinta oro."""

    def __init__(self, pos, rec, leader_ms):
        super().__init__()
        self.setObjectName("rankRow")
        top = (pos == 1)
        _BLUE = "#4aa3df"
        self.setStyleSheet(
            "#rankRow{background:%s;border:none;border-radius:8px;%s}"
            % ("#12222e" if top else "#16181c",
               ("border-left:3px solid %s;" % _BLUE) if top else ""))
        h = QHBoxLayout(self); h.setContentsMargins(12, 8, 14, 8); h.setSpacing(0)
        pcol = _BLUE if top else "#8a8f98"
        pb = QLabel(str(pos)); pb.setFixedWidth(30); pb.setAlignment(Qt.AlignCenter)
        pb.setStyleSheet("color:%s;font-size:13px;font-weight:800;"
                         "background:transparent;" % pcol)
        h.addWidget(pb); h.addSpacing(8)
        box = _SvgBox(); box.setFixedSize(38, 24)
        _car_logo_into(box, rec.get("team"), rec.get("car"))
        h.addWidget(box, 0, Qt.AlignVCenter); h.addSpacing(12)
        dcol = QVBoxLayout(); dcol.setSpacing(0); dcol.setContentsMargins(0, 0, 0, 0)
        dl = QLabel(rec.get("player") or "\u2014")
        dl.setStyleSheet("color:#e8eaee;font-size:12px;font-weight:600;"
                         "background:transparent;")
        tl = QLabel(rec.get("team") or "\u2014")
        tl.setStyleSheet("color:#8a8f98;font-size:11px;background:transparent;")
        dcol.addWidget(dl); dcol.addWidget(tl)
        dw = QWidget(); dw.setLayout(dcol); dw.setFixedWidth(160)
        dw.setStyleSheet("background:transparent;")
        h.addWidget(dw); h.addSpacing(8)
        from core.tyre_cell import TyreCell
        c4 = rec.get("compounds4") or ""
        four = [x.strip() for x in c4.split(",") if x.strip()]
        single = rec.get("compound") or (four[0] if four else "M")
        tc = TyreCell(size=28)
        tc.setStyleSheet("background:transparent;")
        _ts = rec.get("tyre_state_pct")
        _new = (_ts is None) or (_ts >= 97.0)
        if len(four) == 4:
            tc.set_tyre(single, four, new4=[_new, _new, _new, _new], single_new=_new)
        else:
            tc.set_tyre(single, None, single_new=_new)
        tc.setFixedHeight(26)
        h.addWidget(tc, 0, Qt.AlignVCenter); h.addSpacing(16)
        fl = rec.get("fuel_l")
        fk = QLabel(("+%.0f kg" % (fl * 0.75)) if fl is not None else "\u2014")
        fk.setStyleSheet("color:#e8eaee;font-size:12px;font-weight:700;"
                         "background:transparent;")
        fk.setFixedWidth(64); fk.setAlignment(Qt.AlignCenter)
        h.addWidget(fk)
        h.addStretch()
        ms = rec.get("lap_ms")
        t = QLabel(_fmt_ms(ms))
        t.setStyleSheet("color:%s;font-size:14px;font-weight:800;"
                        "background:transparent;" % (_BLUE if top else "#f2f4f7"))
        t.setFixedWidth(92); t.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        h.addWidget(t)
        gap = ""
        if leader_ms and ms and ms > leader_ms:
            gap = "+%.3f" % ((ms - leader_ms) / 1000.0)
        g = QLabel(gap); g.setStyleSheet("color:#8a8f98;font-size:11px;"
                                         "background:transparent;")
        g.setFixedWidth(66); g.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        h.addWidget(g)
        for sk in ("s1_ms", "s2_ms", "s3_ms"):
            sv = rec.get(sk)
            sl = QLabel(("%.1f" % (sv / 1000.0)) if sv else "\u2014")
            sl.setStyleSheet("color:#9aa0a8;font-size:12px;background:transparent;")
            sl.setFixedWidth(50); sl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            h.addWidget(sl)


class _CommunityTab(QWidget):
    """Tab 'Community': sinistra le piste (logo + tag classe colorati). Clicchi
    un tag -> a destra la classifica ricca di quella pista+classe (1° in cima,
    poi i tempi successivi). Toggle DRY/WET."""
    _CLS_ORDER = {"HY": 0, "P2": 1, "P3": 2, "GT3": 3, "GTE": 4}

    def __init__(self):
        super().__init__()
        root = QVBoxLayout(self); root.setContentsMargins(16, 12, 16, 12)
        root.setSpacing(10)
        bar = QHBoxLayout(); bar.setSpacing(8)
        title = QLabel("COMMUNITY"); title.setObjectName("ovColCap")
        bar.addWidget(title); bar.addStretch()
        self._refresh_btn = QPushButton("Refresh")
        self._refresh_btn.setCursor(Qt.PointingHandCursor)
        self._refresh_btn.clicked.connect(lambda: self.reload(force=True))
        bar.addWidget(self._refresh_btn)
        root.addLayout(bar)
        self._status = QLabel(""); self._status.setObjectName("ovColCap")
        root.addWidget(self._status)
        body = QHBoxLayout(); body.setSpacing(12)
        from PySide6.QtWidgets import QScrollArea
        # sinistra: piste
        scL = QScrollArea(); scL.setWidgetResizable(True)
        scL.setFrameShape(QFrame.NoFrame)
        scL.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scL.setMaximumWidth(470)
        hostL = QWidget(); self._tracks_v = QVBoxLayout(hostL)
        self._tracks_v.setContentsMargins(0, 0, 0, 0); self._tracks_v.setSpacing(6)
        self._tracks_v.addStretch()
        scL.setWidget(hostL); body.addWidget(scL, 2)
        # destra: classifica
        rp = QFrame(); rp.setObjectName("ovCard")
        rpl = QVBoxLayout(rp); rpl.setContentsMargins(12, 12, 12, 12); rpl.setSpacing(8)
        hdr = QHBoxLayout()
        self._rank_title = QLabel("Select a track / class")
        self._rank_title.setStyleSheet("color:#e8eaee;font-size:13px;font-weight:700;"
                                       "background:transparent;")
        hdr.addWidget(self._rank_title); hdr.addStretch()
        self._dry_btn = QPushButton("DRY"); self._wet_btn = QPushButton("WET")
        for b, m in ((self._dry_btn, "DRY"), (self._wet_btn, "WET")):
            b.setCursor(Qt.PointingHandCursor); b.setCheckable(True)
            b.clicked.connect(lambda _=False, mm=m: self._set_meteo(mm))
            hdr.addWidget(b)
        rpl.addLayout(hdr)
        scR = QScrollArea(); scR.setWidgetResizable(True)
        scR.setFrameShape(QFrame.NoFrame)
        scR.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        hostR = QWidget(); self._rank_v = QVBoxLayout(hostR)
        self._rank_v.setContentsMargins(0, 0, 0, 0); self._rank_v.setSpacing(6)
        self._rank_v.addStretch()
        scR.setWidget(hostR); rpl.addWidget(scR, 1)
        body.addWidget(rp, 3)
        root.addLayout(body, 1)
        self._rows = []; self._tree = {}
        self._sel_track = None; self._sel_cls = None; self._sel_meteo = "DRY"
        self.reload()

    @staticmethod
    def _parse_key(key):
        parts = (key or "").split("_")
        if len(parts) < 3:
            return ("", key or "", "")
        return (parts[0], "_".join(parts[1:-1]), parts[-1])

    def reload(self, force=False):
        try:
            from core import online
            if not online.enabled():
                self._status.setText("Online non configurato (settings/online.json)")
                self._rows = []; self._build_tree(); return
            if force:
                self._rows = online.all_refs(refresh=True) or []
            else:
                online.load_async()
                self._rows = online.cached_refs() or []
            self._status.setText("%d piste" % len({self._parse_key(r.get("key"))[1]
                                                   for r in self._rows}))
        except Exception as e:
            self._rows = []
            self._status.setText("Errore: %s" % e)
        self._build_tree()

    def _build_tree(self):
        tree = {}
        for r in self._rows:
            cls, trk, cond = self._parse_key(r.get("key"))
            tree.setdefault(trk, {}).setdefault(cls, set()).add(cond)
        self._tree = tree
        self._render_tracks()

    def _render_tracks(self):
        while self._tracks_v.count() > 1:
            it = self._tracks_v.takeAt(0); w = it.widget()
            if w:
                w.deleteLater()
        for trk in sorted(self._tree.keys(), key=lambda t: t.lower()):
            classes = sorted(self._tree[trk].keys(),
                             key=lambda c: self._CLS_ORDER.get(c.upper(), 9))
            row = _TrackRow(trk, classes, self._pick)
            self._tracks_v.insertWidget(self._tracks_v.count() - 1, row)

    def _pick(self, track, cls):
        self._sel_track = track; self._sel_cls = cls
        conds = self._tree.get(track, {}).get(cls, set())
        self._sel_meteo = "DRY" if "DRY" in conds else ("WET" if "WET" in conds else "DRY")
        self._dry_btn.setEnabled("DRY" in conds)
        self._wet_btn.setEnabled("WET" in conds)
        self._refresh_rank()

    def _set_meteo(self, m):
        self._sel_meteo = m
        self._refresh_rank()

    def _refresh_rank(self):
        self._dry_btn.setChecked(self._sel_meteo == "DRY")
        self._wet_btn.setChecked(self._sel_meteo == "WET")
        disp = _track_short(self._sel_track)
        self._rank_title.setText("%s \u00b7 %s \u00b7 %s"
                                 % (self._sel_cls or "", disp, self._sel_meteo))
        while self._rank_v.count() > 1:
            it = self._rank_v.takeAt(0); w = it.widget()
            if w:
                w.deleteLater()
        if not (self._sel_track and self._sel_cls):
            return
        key = "%s_%s_%s" % (self._sel_cls, self._sel_track, self._sel_meteo)
        try:
            from core import online
            rows = online.top(key, 30)
        except Exception:
            rows = []
        lead = rows[0].get("lap_ms") if rows else None
        for i, rec in enumerate(rows):
            self._rank_v.insertWidget(self._rank_v.count() - 1,
                                      _RankRow(i + 1, rec, lead))

    def set_enabled(self, *_):
        pass


class _CircuitCard(_ClickFrame):
    """Card grigia cliccabile: logo SVG pista + nome + n. sessioni."""
    def __init__(self, track, count, logo_path, on_pick):
        super().__init__(lambda: on_pick(track))
        has = count > 0
        self.setObjectName("circCardOn" if has else "circCard")
        self.setMinimumHeight(150)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        v = QVBoxLayout(self); v.setContentsMargins(14, 14, 14, 12); v.setSpacing(6)
        logo = _SvgBox(min_h=64)
        logo.setFixedHeight(72)               # dimensione SVG uniforme tra le card
        if logo_path:
            logo.load(str(logo_path))
        v.addWidget(logo, 1)
        nm = QLabel(track or "\u2014"); nm.setObjectName("circName")
        nm.setAlignment(Qt.AlignCenter); nm.setWordWrap(True)
        v.addWidget(nm)
        cnt = QLabel("%d session%s" % (count, "" if count == 1 else "s"))
        cnt.setObjectName("circCountOn" if has else "circCount")
        cnt.setAlignment(Qt.AlignCenter)
        v.addWidget(cnt)


def _comp_four_single(c4, fallback=""):
    """compounds4 'FL,FR,RL,RR' -> (four|None, single). four valido solo se 4
    sigle presenti; single = sigla principale o fallback."""
    four = [x.strip() for x in (c4 or "").split(",")][:4]
    four = four if (len(four) == 4 and all(four)) else None
    single = (four[0] if four else fallback) or fallback
    return four, single


def _state_col(p):
    """Colore per lo stato gomme: verde alto, ambra medio, rosso basso."""
    if p is None:
        return "#cfd2d8"
    if p >= 70:
        return "#2ecc71"
    if p >= 40:
        return "#f0a23a"
    return "#ff5b5b"


def _load_info_html(tyre_state, load_pct, load_kind, team):
    """Riga testo: stato gomme % · VE/Fuel residuo % · team (compound a parte,
    via widget TyreCell)."""
    info = []
    if tyre_state is not None:
        info.append("Tyres <b style='color:%s'>%.0f%%</b>"
                    % (_state_col(tyre_state), tyre_state))
    if load_pct is not None and load_kind:
        info.append("%s <b style='color:#cfd2d8'>%.0f%%</b>" % (load_kind, load_pct))
    tm = (team or "").strip()
    if tm:
        info.append("<span style='color:#9aa0aa'>%s</span>" % tm)
    return "  &nbsp;\u00b7&nbsp;  ".join(info)


_PROFILE_FILE = Path(__file__).resolve().parent.parent / "settings" / "profile.json"


def _load_profile():
    try:
        import json
        return json.loads(_PROFILE_FILE.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}


def _save_profile(d):
    try:
        import json
        _PROFILE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _PROFILE_FILE.write_text(json.dumps(d, ensure_ascii=False, indent=2),
                                 encoding="utf-8")
    except Exception:
        pass


def get_team():
    """Nome team salvato nel profilo (per card e upload online). '' se assente."""
    return (_load_profile().get("team") or "").strip()


class _CircuitMenu(QWidget):
    """Menu iniziale: griglia di card, una per circuito con sessioni."""
    _COLS = 4

    def __init__(self, on_pick):
        super().__init__()
        self._on_pick = on_pick
        root = QVBoxLayout(self); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)

        # ── HEADER: logo + nome app (sinistra), campo Team (destra) ──
        header = QWidget(); header.setObjectName("circHeader")
        hl = QHBoxLayout(header); hl.setContentsMargins(24, 14, 24, 14); hl.setSpacing(10)
        self.app_logo = _SvgBox(); self.app_logo.setFixedSize(34, 34)
        _logo_p = Path(__file__).resolve().parent.parent / "assets" / "app_logo.svg"
        if _logo_p.exists():
            self.app_logo.load(str(_logo_p))
        hl.addWidget(self.app_logo, 0, Qt.AlignVCenter)
        app_name = QLabel("LMU TELEMETRY PRO"); app_name.setObjectName("appName")
        hl.addWidget(app_name, 0, Qt.AlignVCenter)
        hl.addStretch()
        dlb = QLabel("DRIVER"); dlb.setObjectName("hdrTeamLbl")
        hl.addWidget(dlb, 0, Qt.AlignVCenter)
        self.lb_driver = QLabel(_load_profile().get("driver", "") or "\u2014")
        self.lb_driver.setObjectName("hdrDriver")
        hl.addWidget(self.lb_driver, 0, Qt.AlignVCenter)
        hl.addSpacing(18)
        tlb = QLabel("TEAM"); tlb.setObjectName("hdrTeamLbl")
        hl.addWidget(tlb, 0, Qt.AlignVCenter)
        self.ed_team = QLineEdit(); self.ed_team.setObjectName("hdrTeam")
        self.ed_team.setMaxLength(30); self.ed_team.setFixedWidth(220)
        self.ed_team.setPlaceholderText("Your team")
        self.ed_team.setText(_load_profile().get("team", ""))
        self.ed_team.editingFinished.connect(self._save_team)
        hl.addWidget(self.ed_team, 0, Qt.AlignVCenter)
        save_btn = QPushButton("Save"); save_btn.setObjectName("hdrSave")
        save_btn.setCursor(Qt.PointingHandCursor)
        save_btn.clicked.connect(self._save_team)
        hl.addWidget(save_btn, 0, Qt.AlignVCenter)
        root.addWidget(header)

        # ── BANNER: riga messaggi sotto l'header (riusabile) ──
        self.banner = QLabel(""); self.banner.setObjectName("circBanner")
        self.banner.setVisible(False); self.banner.setWordWrap(True)
        root.addWidget(self.banner)

        # ── CONTENUTO: titolo + griglia circuiti ──
        body = QWidget(); body.setObjectName("circBody")
        self._body = body
        from PySide6.QtWidgets import QGraphicsOpacityEffect
        self._body_op = QGraphicsOpacityEffect(body)
        body.setGraphicsEffect(self._body_op)
        bl = QVBoxLayout(body); bl.setContentsMargins(24, 18, 24, 18); bl.setSpacing(16)
        title = QLabel("Select a circuit"); title.setObjectName("circTitle")
        bl.addWidget(title)
        from PySide6.QtWidgets import QScrollArea
        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._host = QWidget()
        self._grid = QGridLayout(self._host)
        self._grid.setContentsMargins(0, 0, 0, 0)
        self._grid.setHorizontalSpacing(16); self._grid.setVerticalSpacing(16)
        scroll.setWidget(self._host)
        bl.addWidget(scroll, 1)
        self._empty = QLabel("No sessions yet"); self._empty.setObjectName("circCount")
        self._empty.setAlignment(Qt.AlignCenter); self._empty.setVisible(False)
        bl.addWidget(self._empty)
        root.addWidget(body, 1)

        # ── FOOTER: barra riservata (contenuti futuri) ──
        footer = QWidget(); footer.setObjectName("circFooter")
        fl = QHBoxLayout(footer); fl.setContentsMargins(24, 8, 24, 8); fl.setSpacing(8)
        fl.addStretch()
        root.addWidget(footer)

        self.setStyleSheet(
            "#circHeader{background:#16181c;border-bottom:1px solid #23262d;}"
            "#circFooter{background:#16181c;border-top:1px solid #23262d;}"
            "#circBody{background:transparent;}"
            "#appName{color:#f2f4f7;font-size:16px;font-weight:800;"
            "letter-spacing:1px;background:transparent;}"
            "#hdrTeamLbl{color:#6e727b;font-size:11px;font-weight:700;"
            "letter-spacing:2px;background:transparent;}"
            "#hdrTeam{background:#1d1f24;color:#e8eaee;border:1px solid #2c2e33;"
            "border-radius:6px;padding:4px 8px;font-size:12px;}"
            "#hdrTeam:focus{border:1px solid #45b4ef;}"
            "#hdrSave{background:#1c9fe0;color:#0b1f44;border:none;border-radius:6px;"
            "padding:5px 14px;font-size:12px;font-weight:700;}"
            "#hdrSave:hover{background:#45b4ef;}"
            "#hdrDriver{color:#e8eaee;font-size:12px;font-weight:700;background:transparent;}"
            "#circTitle{color:#f2f4f7;font-size:18px;font-weight:700;background:transparent;}"
            "#circCard{background:#1d1f24;border:none;border-radius:10px;}"
            "#circCard:hover{background:#23262d;}"
            "#circCardOn{background:#1d1f24;border-left:2px solid #45b4ef;border-radius:10px;}"
            "#circCardOn:hover{background:#23262d;}"
            "#circName{color:#f2f4f7;font-size:13px;font-weight:600;background:transparent;}"
            "#circCount{color:#f2f4f7;font-size:11px;background:transparent;}"
            "#circCountOn{color:#f2f4f7;font-size:11px;background:transparent;}")
        self._update_gate()

    # ── banner messaggi (riusabile) ───────────────────────────────────
    def set_banner(self, text, level="info"):
        cols = {"info": ("#0e2a3a", "#45b4ef"), "warn": ("#2e2410", "#f0a23a"),
                "error": ("#2e1416", "#ff5b5b")}
        bg, fg = cols.get(level, cols["info"])
        self.banner.setStyleSheet(
            "#circBanner{background:%s;color:%s;font-size:12px;font-weight:600;"
            "padding:8px 24px;border:none;}" % (bg, fg))
        self.banner.setText(text); self.banner.setVisible(True)

    def clear_banner(self):
        self.banner.setVisible(False)

    def set_driver(self, name):
        """Nome pilota (auto dal gioco) mostrato in header."""
        name = (name or "").strip()
        if name and self.lb_driver.text() != name:
            self.lb_driver.setText(name)

    def _update_gate(self):
        """Team obbligatorio: senza team i circuiti sono bloccati e opacizzati."""
        if get_team():
            self.clear_banner(); self._body.setEnabled(True)
            self._body_op.setOpacity(1.0)
        else:
            self.set_banner("Enter your team name above to access the circuits", "warn")
            self._body.setEnabled(False)
            self._body_op.setOpacity(0.25)

    def _save_team(self):
        t = self.ed_team.text().strip()[:30]
        d = _load_profile(); d["team"] = t; _save_profile(d)
        self._update_gate()



    def set_circuits(self, items):
        while self._grid.count():
            it = self._grid.takeAt(0); w = it.widget()
            if w:
                w.deleteLater()
        self._empty.setVisible(not items)
        cols = self._COLS
        for c in range(cols):
            self._grid.setColumnStretch(c, 1)
        for i, (track, count, logo) in enumerate(items):
            self._grid.addWidget(_CircuitCard(track, count, logo, self._on_pick),
                                 i // cols, i % cols)
        self._grid.setRowStretch((len(items) // cols) + 1, 1)


_UNSET = object()


class TelemetryWindow(QMainWindow):

    def __init__(self):
        super().__init__()
        self.setWindowTitle("LMU Telemetry Pro")
        self.resize(900, 640)
        self._con = None
        self._car_class = ""
        self._groups = {}
        self._stint_keys = []
        self._lap_ids = []
        self._cmp_ids = []
        self._user_enabled = True

        central = QWidget(); self.setCentralWidget(central)
        croot = QVBoxLayout(central); croot.setContentsMargins(0, 0, 0, 0)
        self.stack = QStackedWidget()
        croot.addWidget(self.stack, 1)
        # ── footer: supporto allo sviluppo / donazioni ──
        foot = QWidget(); foot.setObjectName("appFooter")
        fl = QHBoxLayout(foot); fl.setContentsMargins(16, 6, 16, 6); fl.setSpacing(12)
        _flab = QLabel("LMU Telemetry Pro  %s  \u00b7  by Jonathan Sanfilippo"
                       % _APP_VERSION)
        _flab.setStyleSheet("color:#6e727b;font-size:11px;background:transparent;")
        fl.addWidget(_flab)
        fl.addStretch()
        _fsup = QLabel("Support development:")
        _fsup.setStyleSheet("color:#8a8f98;font-size:11px;background:transparent;")
        fl.addWidget(_fsup)
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl, QPropertyAnimation, QEasingCurve
        from PySide6.QtWidgets import QGraphicsOpacityEffect
        self._donate_btn = QPushButton("\u2764  DONATE")
        self._donate_btn.setObjectName("donateBtn")
        self._donate_btn.setCursor(Qt.PointingHandCursor)
        self._donate_btn.setToolTip("Support the development \u2014 grazie!")
        self._donate_btn.clicked.connect(
            lambda: QDesktopServices.openUrl(QUrl(_DONATE_URL)))
        fl.addWidget(self._donate_btn)
        # animazione "respiro" (pulsa per farsi notare)
        _eff = QGraphicsOpacityEffect(self._donate_btn)
        self._donate_btn.setGraphicsEffect(_eff)
        self._donate_anim = QPropertyAnimation(_eff, b"opacity")
        self._donate_anim.setDuration(1100)
        self._donate_anim.setStartValue(1.0)
        self._donate_anim.setKeyValueAt(0.5, 0.5)
        self._donate_anim.setEndValue(1.0)
        self._donate_anim.setLoopCount(-1)
        self._donate_anim.setEasingCurve(QEasingCurve.InOutSine)
        self._donate_anim.start()
        _gh = QLabel('<a href="%s" style="color:%s;text-decoration:none;">GitHub</a>'
                     % (_GITHUB_URL, _ACCENT))
        _gh.setOpenExternalLinks(True)
        _gh.setStyleSheet("font-size:11px;font-weight:700;background:transparent;")
        fl.addSpacing(4); fl.addWidget(_gh)
        croot.addWidget(foot)

        review_page = QWidget()
        root = QVBoxLayout(review_page)

        top = QHBoxLayout()
        self.btn_menu = QPushButton("\u2039 Circuits"); self.btn_menu.setObjectName("backBtn")
        self.btn_menu.setCursor(Qt.PointingHandCursor)
        self.btn_menu.setToolTip("Back to circuit selection")
        self.btn_menu.clicked.connect(self._show_menu)
        top.addWidget(self.btn_menu)
        top.addSpacing(8)
        self.btn_rec = QPushButton("START"); self.btn_rec.setObjectName("recBtn")
        self.btn_rec.setCursor(Qt.PointingHandCursor)
        self.btn_rec.setToolTip("Start/stop telemetry recording")
        self.btn_rec.setStyleSheet(
            "QPushButton{padding:4px 14px;border-radius:4px;background:transparent;font-weight:bold;}"
            "QPushButton[rec=\"off\"]{color:#22e06a;border:1px solid #22e06a;}"
            "QPushButton[rec=\"on\"]{color:#ff3b30;border:1px solid #ff3b30;}"
            "QPushButton[rec=\"wait\"]{color:#f0a23a;border:1px solid #f0a23a;}")
        self.btn_rec.clicked.connect(self._toggle_rec)
        self.btn_rec.setFixedWidth(96)   # larghezza fissa: START/WAITING/STOP non spostano gli altri
        top.addWidget(self.btn_rec)
        top.addSpacing(8)
        self.learn_status = QLabel(""); self.learn_status.setObjectName("learnStatus")
        self.learn_status.setStyleSheet(
            "#learnStatus{color:#45b4ef;font-weight:bold;font-size:12px;}")
        top.addWidget(self.learn_status)
        top.addSpacing(12)
        self.banner = QLabel(""); self.banner.setObjectName("statusBanner")
        self.banner.setAlignment(Qt.AlignVCenter | Qt.AlignLeft)
        top.addWidget(self.banner, 1)
        # card di riferimento sempre attive: ref + pace (real lap rimosso)
        self._show_ref = True
        self._show_pace = True
        top.addSpacing(12)
        self.btn_export = QPushButton("Export CSV"); self.btn_export.setObjectName("backBtn")
        self.btn_export.setCursor(Qt.PointingHandCursor)
        self.btn_export.setToolTip("Export the selected lap (all channels) to CSV")
        self.btn_export.clicked.connect(self._export_csv)
        top.addWidget(self.btn_export)
        self.btn_export_ld = QPushButton("Export i2"); self.btn_export_ld.setObjectName("backBtn")
        self.btn_export_ld.setCursor(Qt.PointingHandCursor)
        self.btn_export_ld.setToolTip("Export the current stint to MoTeC i2 (.ld)")
        self.btn_export_ld.clicked.connect(self._export_motec)
        top.addWidget(self.btn_export_ld)
        # combo "motore" (non mostrati): la selezione la guida la board nell'Overview
        from PySide6.QtWidgets import QListView
        self.cmb_stint = QComboBox(self); self.cmb_stint.setVisible(False)
        self.cmb_lap = QComboBox(self); self.cmb_lap.setVisible(False)
        self.cmb_cmp = QComboBox(self); self.cmb_cmp.setVisible(False)
        for _cmb in (self.cmb_stint, self.cmb_lap, self.cmb_cmp):
            _cmb.setMaxVisibleItems(12)
            _lv = QListView(); _cmb.setView(_lv)
        root.addLayout(top)

        # sotto-tab telemetria (tutte le tab attuali, senza Overview)
        self.tabs = QTabWidget()
        self._data = _LapData()
        self._stint_new_cache = {}
        self._cat = []
        self._cat_lap = _UNSET; self._cat_cmp = _UNSET
        self._cat_dirty_lap = set(); self._cat_dirty_cmp = set()
        self._overview = _OverviewTab()
        self._overview.board.set_callbacks(self._board_stint, self._board_pick)
        # Worksheet multi-canale (primo tab): vista a canali impilati
        self._worksheet = _WorksheetTab(self._data)
        self._worksheet.map_w.color_cb = self._pick_color
        self.tabs.addTab(self._worksheet, "Worksheet")
        self._cat.append(self._worksheet)
        _TRACE = {"Speed": ("speed", "km/h"), "VE": ("ve", "%"),
                  "Fuel": ("fuel", "L"), "Hybrid": ("soc", "%"),
                  "Tyres": ("tyre_t", "\u00b0C"), "Brakes": ("brake_t", "\u00b0C"),
                  "Gear": ("gear", ""), "Steering": ("steer", "\u00b0"),
                  "RPM": ("rpm", "rpm")}
        for label, metrics in _TAB_GROUPS:
            if label == "Tyres":
                t = _TyresTab(self._data)
                t.chart.color_cb = self._pick_color
                t.map_w.color_cb = self._pick_color
            elif label == "Pedals":
                t = _PedalsTab(self._data)
                t.map_w.color_cb = self._pick_color
            elif label == "G-G":
                t = _GGTab(self._data)
            elif label == "Aids":
                t = _TraceTab(self._data, "tc_active", "", "Aids",
                              modes=[("TC active", "tc_active"),
                                     ("ABS active", "abs_active"),
                                     ("Brake bias", "brake_bias"),
                                     ("TC map", "tc_map"), ("ABS map", "abs_map")])
                t.chart.color_cb = self._pick_color
                t.map_w.color_cb = self._pick_color
            elif label == "Brakes":
                t = _BrakesTab(self._data)
                t.chart.color_cb = self._pick_color
                t.map_w.color_cb = self._pick_color
            elif label == "Suspension":
                t = _SuspTab(self._data)
                t.chart.color_cb = self._pick_color
                t.map_w.color_cb = self._pick_color
            elif label in _TRACE:
                col, unit = _TRACE[label]
                t = _TraceTab(self._data, col, unit, label)
                t.chart.color_cb = self._pick_color
                t.map_w.color_cb = self._pick_color
            else:
                t = _CatTable(self._data, metrics, show_chart=(label != "Times"),
                              tyre_modes=(label == "Tyres"), pedal=(label == "Times"))
                if t.chart is not None:
                    t.chart.color_cb = self._pick_color
                if t.map_w is not None:
                    t.map_w.color_cb = self._pick_color
            self.tabs.addTab(t, label)
            self._cat.append(t)
        # Delta-T (Compare - Selected) vs distanza
        self._delta_tab = _DeltaTab(self._data)
        self._delta_tab.map_w.color_cb = self._pick_color
        self.tabs.addTab(self._delta_tab, "Delta")
        self._cat.append(self._delta_tab)
        # Engineer: spostata nelle tab principali (in fondo a destra)
        self._engineer = _EngineerTab(self)
        # sincronizzazione zoom + cursori A/B fra tutti i grafici a traccia
        self._charts = []
        for t in self._cat:
            ch = getattr(t, "chart", None)
            if isinstance(ch, _TraceChart):
                self._charts.append(ch)
            for ch2 in getattr(t, "charts", []):     # tab multi-chart (Worksheet)
                if isinstance(ch2, _TraceChart):
                    self._charts.append(ch2)
        for ch in self._charts:
            ch._zoom_cb = lambda v, src=ch: self._broadcast_view(v, src)
            ch._ab_cb = lambda a, b, src=ch: self._broadcast_ab(a, b, src)
        # ── sezione Settings (assetto .svm) — placeholder, riempita col .svm ──
        self.settings_page = _SettingsTab(self)
        # ── tab principali: Overview | Telemetry | Settings | Database ──
        self.main_tabs = QTabWidget(); self.main_tabs.setObjectName("mainTabs")
        self.main_tabs.addTab(self._overview, "Overview")
        self.main_tabs.addTab(self.tabs, "Telemetry")
        self.main_tabs.addTab(self.settings_page, "Settings")
        # tab "Database" (CSV pace OhneSpeed) rimossa
        self._community = _CommunityTab()
        self.main_tabs.addTab(self._community, "Community")
        self._teammode = _TeamModeTab(self)
        self.main_tabs.addTab(self._teammode, "Team Mode")
        self.main_tabs.addTab(self._engineer, "Engineer")   # in fondo a destra
        root.addWidget(self.main_tabs)
        self._graph_views = []

        self._review_page = review_page
        self.stack.addWidget(review_page)        # index 0: vista Review
        self._track_filter = None
        self._menu = _CircuitMenu(self._enter_circuit)
        self.stack.addWidget(self._menu)         # index 1: menu circuiti
        self.live = None

        self.setStyleSheet(
            f"QMainWindow,QWidget{{background:{_BG};color:{_FG};font-family:\"Google Sans\";}}"
            f"QComboBox,QPushButton{{background:#1d1f24;color:{_FG};border:none;"
            f"padding:5px 10px;border-radius:6px;}}"
            f"QComboBox:hover,QPushButton:hover{{border-color:#3a3d43;}}"
            f"QComboBox QAbstractItemView{{background:#1b1d20;color:{_FG};"
            f"selection-background-color:#2a2c30;outline:0;}}"
            f"QComboBox QAbstractItemView QScrollBar:vertical{{background:transparent;width:10px;margin:0;}}"
            f"QComboBox QAbstractItemView QScrollBar::handle:vertical{{background:#313338;"
            f"border-radius:5px;min-height:24px;}}"
            f"QComboBox QAbstractItemView QScrollBar::add-line,"
            f"QComboBox QAbstractItemView QScrollBar::sub-line{{height:0;}}"
            f"QLabel#barCap{{color:#6e727b;font-size:10px;font-weight:700;letter-spacing:1px;"
            f"padding:0 7px 0 0;}}"
            f"QComboBox#barCombo{{background:#1d1f24;border:none;"
            f"padding:5px 10px;border-radius:8px;}}"
            f"QComboBox#barCombo:hover{{border-color:#3a3d43;}}"
            f"QPushButton#iconBtn{{font-size:15px;padding:4px 9px;}}"
            f"QPushButton#swatch{{border:none;border-radius:5px;padding:0;}}"
            f"QPushButton#modeBtn{{padding:3px 12px;font-size:12px;}}"
            f"QPushButton#modeBtn:checked{{background:{_ACCENT};color:#09090b;border-color:{_ACCENT};}}"
            f"QPushButton#backBtn{{padding:5px 14px;}}"
            f"QTableWidget{{background:{_BG};alternate-background-color:#191a1d;"
            f"gridline-color:transparent;border:0;}}"
            f"QTableWidget::item{{padding:7px 12px;border:0;}}"
            f"QTableWidget::item:selected{{background:#2a2c30;color:{_FG};}}"
            f"QHeaderView::section{{background:{_BG};color:#a6a9af;border:0;"
            f"border-bottom:1px solid {_GRID};padding:8px 12px;"
            f"font-weight:600;}}"
            f"QTabWidget::pane{{border:0;border-top:0;}}"
            f"QTabBar::tab{{background:transparent;color:#a6a9af;padding:8px 16px;"
            f"border-bottom:2px solid transparent;}}"
            f"QTabBar::tab:hover{{color:{_FG};}}"
            f"QTabBar::tab:selected{{color:{_FG};border-bottom:2px solid {_ACCENT};}}"
            f"QScrollBar:vertical{{background:transparent;width:10px;margin:0;}}"
            f"QScrollBar::handle:vertical{{background:#313338;border-radius:5px;min-height:24px;}}"
            f"QScrollBar::add-line,QScrollBar::sub-line{{height:0;}}"
            f"QScrollBar:horizontal{{height:0;background:transparent;}}"
            f"QWidget#appFooter{{background:#0d0e10;border-top:1px solid #232529;}}"
            f"QPushButton#donateBtn{{background:#ff4d6d;color:#ffffff;border:none;"
            f"border-radius:13px;padding:5px 18px;font-size:12px;font-weight:800;"
            f"letter-spacing:.5px;}}"
            f"QPushButton#donateBtn:hover{{background:#ff6b85;}}")

        self._cur_sess = -1
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.cmb_stint.currentIndexChanged.connect(self._on_stint)
        self.cmb_lap.currentIndexChanged.connect(self._on_lap)
        self.cmb_cmp.currentIndexChanged.connect(self._on_cmp)

        self._sessions = []
        self._ref_available = False
        self._sel_none = False
        self._cmp_none = False
        self._reload_sessions()
        self._show_menu()
        QTimer.singleShot(400, self._start_learn_scan)   # impara sessioni mancanti

        # aggiorna la Review durante la sessione (nuovi giri), preservando la selezione
        self._rev_timer = QTimer(self)
        self._rev_timer.setInterval(8000)
        self._rev_timer.timeout.connect(self._live_refresh)
        self._rev_timer.start()
        # sincronizza il bottone AVVIA/STOP (riflette lo stop automatico)
        self._rec_timer = QTimer(self)
        self._rec_timer.setInterval(700)
        self._rec_timer.timeout.connect(self._sync_rec_btn)
        self._rec_timer.timeout.connect(self._capture_driver)
        self._rec_timer.start()
        # auto-best: quando esce un nuovo best, confronta best vs penultimo best
        self._auto_last_best = None
        self._auto_timer = QTimer(self)
        self._auto_timer.setInterval(1000)
        self._auto_timer.timeout.connect(self._auto_best_tick)
        self._auto_timer.start()

        # ── recorder telemetria ──────────────────────────────────────────
        # La registrazione su .lmtel è gestita qui (processo telemetry, sempre
        # attivo quando l'app è aperta). Se anche il widget 'strategy' è
        # abilitato lascia a lui la registrazione, per non scrivere due volte
        # sullo stesso file.
        self._recorder = None
        try:
            from core.config import get_config
            _cfg = get_config()
            scfg = _cfg.widget("strategy")
            from .recorder import TelemetryRecorder
            self._recorder = TelemetryRecorder(
                margin_laps=scfg.get("save_margin", 2.0),
                window=scfg.get("moving_window", 3),
                record=scfg.get("record", True),
            )
        except Exception:
            self._recorder = None
        self._sync_rec_btn()

    def _toggle_rec(self):
        if not getattr(self, "_recorder", None):
            return
        if self._recorder.is_armed():
            self._recorder.disarm()
        else:
            self._recorder.arm()
        self._sync_rec_btn()

    def _capture_driver(self):
        """Appena c'è una sessione in pista, legge il pilota dal session_meta
        del file in registrazione (una volta per file), lo salva in profilo e
        lo mostra in header accanto al team."""
        rec = getattr(self, "_recorder", None)
        if not (rec and rec.is_armed()):
            return
        try:
            f = rec.current_file()
        except Exception:
            f = None
        if not f or f == getattr(self, "_drv_cap_file", None):
            return
        try:
            con = sqlite3.connect(f)
            r = con.execute("SELECT driver FROM session_meta WHERE id=1").fetchone()
            con.close()
            drv = (r[0] if r else "") or ""
        except Exception:
            drv = ""
        if not drv:
            return                       # meta non ancora scritta: riprova dopo
        self._drv_cap_file = f           # catturato per questo file
        prof = _load_profile()
        if prof.get("driver") != drv:
            prof["driver"] = drv; _save_profile(prof)
        menu = getattr(self, "_menu", None)
        if menu is not None:
            menu.set_driver(drv)

    def _eng_log(self, text):
        eng = getattr(self, "_engineer", None)
        if eng is not None:
            try:
                eng.log(text)
            except Exception:
                pass

    def _start_learn_scan(self):
        """All'avvio: analizza le sessioni di telemetria non ancora imparate
        (marcatore persistente nel file). A pezzi, per non bloccare la UI."""
        try:
            import telemetry.db as _db
            from pathlib import Path
            d = Path(_db.LOGS_DIR)
            self._scan_files = sorted(d.glob("*.lmtel")) if d.exists() else []
        except Exception:
            self._scan_files = []
        self._scan_i = 0
        self._scan_done = 0
        if not self._scan_files:
            return
        self._scan_timer = QTimer(self)
        self._scan_timer.setInterval(40)
        self._scan_timer.timeout.connect(self._scan_step)
        self._scan_timer.start()
        ls = getattr(self, "learn_status", None)
        if ls is not None:
            ls.setText("Engineer: analyzing sessions\u2026")
        self._eng_log("Startup: scanning %d session(s) for learning\u2026"
                      % len(self._scan_files))

    def _scan_step(self):
        from core import engineer_learn as EL
        ls = getattr(self, "learn_status", None)
        if self._scan_i >= len(self._scan_files):
            self._scan_timer.stop()
            if ls is not None:
                if self._scan_done:
                    ls.setText("Engineer: learned \u00b7 %d sessions" % self._scan_done)
                    QTimer.singleShot(8000, lambda: ls.setText(""))
                else:
                    ls.setText("")
            self._eng_log("Startup scan done \u00b7 learned %d new session(s)"
                          % self._scan_done if self._scan_done
                          else "Startup scan done \u00b7 already up to date")
            return
        f = self._scan_files[self._scan_i]; self._scan_i += 1
        con = None
        try:
            con = sqlite3.connect(str(f)); con.row_factory = sqlite3.Row
            if not EL.is_learned(con):
                m = con.execute(
                    "SELECT track, car_class, wetness FROM session_meta WHERE id=1").fetchone()
                track = m["track"] if m else None
                cls = (m["car_class"] if m else "") or ""
                wet = bool(m and m["wetness"] is not None and m["wetness"] > 0.15)
                energy = "HYP" in cls.upper() or "LMH" in cls.upper()
                prof = EL.update_from_session(con, track, cls, energy_car=energy, wet=wet)
                EL.mark_learned(con)             # marca anche se 0 giri puliti
                if prof:
                    self._scan_done += 1
                    cnd = "wet" if wet else "dry"
                    self._eng_log("Learned %s \u00b7 %s [%s] from %s"
                                  % (track or "?", cls or "?", cnd, f.name))
        except Exception:
            pass
        finally:
            try:
                if con is not None:
                    con.close()
            except Exception:
                pass

    def _learn_after_session(self):
        """Sessione stoppata: l'ingegnere analizza il file e aggiorna il profilo."""
        f = getattr(self, "_rec_file", None)
        if not f:
            return
        seen = getattr(self, "_learned_files", None)
        if seen is None:
            seen = set(); self._learned_files = seen
        if f in seen:
            return
        ls = getattr(self, "learn_status", None)
        if ls is not None:
            ls.setText("Engineer: analyzing session\u2026")
        self._eng_log("Session stopped \u2014 analyzing\u2026")
        QTimer.singleShot(80, lambda: self._run_learn(f))

    def _run_learn(self, f):
        seen = getattr(self, "_learned_files", set())
        if f in seen:
            return
        seen.add(f); self._learned_files = seen
        ls = getattr(self, "learn_status", None)
        prof = None
        try:
            con = sqlite3.connect(f); con.row_factory = sqlite3.Row
            m = con.execute(
                "SELECT track, car_class, session_type, wetness FROM session_meta WHERE id=1").fetchone()
            track = m["track"] if m else None
            cls = (m["car_class"] if m else "") or getattr(self, "_car_class", "")
            wet = bool(m and m["wetness"] is not None and m["wetness"] > 0.15)
            energy = "HYP" in (cls or "").upper() or "LMH" in (cls or "").upper()
            from core import engineer_learn as EL
            prof = EL.update_from_session(con, track, cls, energy_car=bool(energy), wet=wet)
            con.close()
        except Exception:
            prof = None
        tot = 0
        if prof:
            cnd = prof.get("cond") or {}
            tot = sum(int((cnd.get(k) or {}).get("samples") or 0) for k in ("dry", "wet"))
        if ls is not None:
            if tot:
                ls.setText("Engineer: learned \u00b7 %d laps" % tot)
            else:
                ls.setText("Engineer: no clean laps")
            QTimer.singleShot(8000, lambda: ls.setText(""))
        if prof and tot:
            self._eng_log("Learned %s \u00b7 %s \u00b7 %d total clean laps"
                          % (prof.get("track") or "?", prof.get("car_class") or "?", tot))
        else:
            self._eng_log("Session analyzed \u00b7 no clean laps to learn")

    def _sync_rec_btn(self):
        btn = getattr(self, "btn_rec", None)
        if btn is None:
            return
        rec = getattr(self, "_recorder", None)
        # rileva fine sessione (armato -> disarmato): analizza e impara
        armed_now = bool(rec) and rec.is_armed()
        if armed_now:
            try:
                self._rec_file = rec.current_file()
            except Exception:
                pass
        if getattr(self, "_was_armed_rec", False) and not armed_now:
            self._learn_after_session()
        self._was_armed_rec = armed_now
        if rec is None:
            enabled, text, prop = False, "START", "off"
        elif not rec.is_armed():
            enabled, text, prop = True, "START", "off"
        elif rec.is_recording():
            enabled, text, prop = True, "STOP", "on"        # in pista = rosso
        else:
            enabled, text, prop = True, "STOP", "wait"      # armato/box = arancione
        if (enabled, text, prop) != getattr(self, "_rec_btn_cache", None):
            self._rec_btn_cache = (enabled, text, prop)
            btn.setEnabled(enabled)
            btn.setText(text); btn.setProperty("rec", prop)
            btn.style().unpolish(btn); btn.style().polish(btn)
        # banner di stato (testo + colore variabile) — solo se cambia
        bn = getattr(self, "banner", None)
        if bn is not None:
            kind, text = rec.banner() if rec is not None else ("idle", "Telemetry recorder unavailable")
            if (kind, text) != getattr(self, "_banner_cache", None):
                self._banner_cache = (kind, text)
                cols = {
                    "idle": ("#989ba2", "#16171a", "#2a2c30"),
                    "wait": ("#f0a23a", "#241a10", "#8a5a1e"),
                    "rec":  ("#2ecc71", "#122017", "#2e7d52"),
                }.get(kind, ("#989ba2", "#16171a", "#2a2c30"))
                bn.setText(text)
                bn.setStyleSheet(
                    "QLabel#statusBanner{color:%s;background:%s;border:1px solid %s;"
                    "border-radius:8px;padding:7px 14px;font-size:13px;font-weight:600;"
                    "letter-spacing:.3px;}" % cols)
        # Overview: condizioni LIVE solo se stai guardando la sessione ATTIVA
        # (la più recente = index 0). Se hai cliccato un'altra sessione per
        # rivederla, niente override live (altrimenti "saltava" sulla corrente).
        if getattr(self, "_overview", None) is not None:
            live_ok = bool(rec) and rec.is_armed() and (self._cur_sess == 0)
            self._overview.set_live(live_ok)

    def _auto_best_tick(self):
        """Ogni secondo: se nello stint corrente esce un NUOVO best lap, imposta
        in automatico sel = best e cmp = penultimo best. Se il best non è
        cambiato non tocca nulla (così una comparazione manuale ai box resta)."""
        if self.stack.currentIndex() != 0 or self._con is None:
            return
        rec = getattr(self, "_recorder", None)
        if not (rec and rec.is_armed()):
            return                      # a riposo i giri non cambiano: niente scan
        sidx = self.cmb_stint.currentIndex()
        if not (0 <= sidx < len(self._stint_keys)):
            return
        try:
            laps_all = _rows(self._con, "SELECT * FROM laps ORDER BY lap")
        except Exception:
            return
        if not laps_all:
            return
        base = min((L["stint"] or 1) for L in laps_all)
        groups = {}
        for L in laps_all:
            groups.setdefault((L["stint"] or 1) - base + 1, []).append(L)
        key = self._stint_keys[sidx]
        stint_laps = groups.get(key, [])
        if not stint_laps:
            return
        n = len(laps_all)
        new_lap = (n != getattr(self, "_last_lap_count", None))
        self._last_lap_count = n
        best, second = _two_best_laps(stint_laps)
        if best is not None and best != self._auto_last_best:
            self._auto_last_best = best
            self._groups = groups
            self._stint_keys = sorted(groups)
            self._data.set_stint(stint_laps)
            self._fill_laps(stint_laps, best)
            self._fill_compare(stint_laps,
                               None if getattr(self, "_ref_available", False) else second)
            return
        if new_lap:
            # nuovo giro chiuso (non best): aggiorna righe/board entro ~1s, tieni la selezione
            self._groups = groups
            self._stint_keys = sorted(groups)
            li = self.cmb_lap.currentIndex()
            keep = self._lap_ids[li] if 0 <= li < len(self._lap_ids) else None
            self._data.set_stint(stint_laps)
            self._fill_laps(stint_laps, keep)
        return

    def _pick_color(self, which):
        global _SEL_COL, _CMP_COL, _TRK_COL
        cur = {"sel": _SEL_COL, "cmp": _CMP_COL, "track": _TRK_COL}.get(which, _SEL_COL)
        title = {"sel": "Selected lap color", "cmp": "Compare lap color",
                 "track": "Track color"}.get(which, "Colore")
        c = QColorDialog.getColor(QColor(cur), self, title)
        if not c.isValid():
            return
        if which == "sel":
            _SEL_COL = c.name()
        elif which == "cmp":
            _CMP_COL = c.name()
        else:
            _TRK_COL = c.name()
        for t in self._cat:
            t.recolor()

    # contratto launcher
    def set_enabled(self, enabled):
        self._user_enabled = enabled
        if enabled:
            self.show(); self.raise_(); self.activateWindow()
        else:
            self.hide()

    def reload_config(self):
        pass

    def _close_con(self):
        if self._con is not None:
            try:
                self._con.close()
            except Exception:
                pass
            self._con = None
        self._data.set_con(None)
        for v in self._graph_views:
            v.con = None

    def _broadcast_view(self, view, src):
        """Propaga la finestra di zoom a tutti gli altri grafici a traccia."""
        for ch in getattr(self, "_charts", []):
            if ch is not src:
                ch.set_view(view)

    def _broadcast_ab(self, a, b, src):
        """Propaga i cursori A/B a tutti gli altri grafici a traccia."""
        for ch in getattr(self, "_charts", []):
            if ch is not src:
                ch.set_ab(a, b)

    def _refresh_all_tabs(self):
        for t in self._cat:
            if hasattr(t, "_refresh"):
                try:
                    t._refresh()
                except Exception:
                    pass

    def _autopick_reference(self):
        """Carica il reference (best record) per classe+pista+meteo della sessione."""
        self._ref_available = False
        self._data.clear_reference()
        if self._con is None:
            return
        try:
            mr = _rows(self._con,
                       "SELECT car_class, track, wetness FROM session_meta WHERE id=1")
            m = mr[0] if mr else {}
            path = _db.ref_path_for(m.get("car_class"), m.get("track"), m.get("wetness"))
            if path and self._data.load_reference(str(path)):
                self._ref_available = True
        except Exception:
            self._ref_available = False

    def _clear_views(self):
        """Svuota TUTTE le tab quando non resta alcuna sessione."""
        self._auto_last_best = None
        self._ref_available = False
        self._data.clear_reference()
        self._data.set_con(None)
        self._data.set_stint([])          # azzera lo stint (Stint tab non ricostruisce vecchi giri)
        for v in self._graph_views:
            v.con = None
        self._fill_stints({})             # combo stint/lap vuoti -> set_lap(None)
        self._fill_compare([])            # azzera anche il Compare -> set_compare(None)
        for ch in getattr(self, "_charts", []):
            ch.set_view(None); ch.clear_ab()
        if getattr(self, "_overview", None) is not None:
            self._overview.set_live(False)
            self._overview.set_meta({})

    def _populate_menu(self):
        # conteggio sessioni per circuito (per stem del logo)
        counts = {}
        for s in _db.list_sessions():
            k = _track_logo_stem(s.get("track")) or "Other"
            counts[k] = counts.get(k, 0) + 1
        # TUTTI i circuiti disponibili dai loghi SVG
        items = []
        try:
            logos = sorted(_OV_TRACKLOGO_DIR.glob("*.svg"), key=lambda p: p.stem.lower())
        except Exception:
            logos = []
        for f in logos:
            items.append((f.stem, counts.get(f.stem, 0), f))
        # sessioni senza logo abbinato
        if counts.get("Other"):
            items.append(("Other", counts["Other"], None))
        self._menu.set_circuits(items)

    def _show_menu(self):
        self._populate_menu()
        self.stack.setCurrentWidget(self._menu)

    def _enter_circuit(self, track):
        self._track_filter = track
        self._reload_sessions()
        self.stack.setCurrentWidget(self._review_page)
        if getattr(self, "main_tabs", None) is not None and \
                getattr(self, "_overview", None) is not None:
            self.main_tabs.setCurrentWidget(self._overview)   # sempre su Overview
        if self._sessions:
            self._user_picked_session = True
            self._on_session(0)            # prima sessione selezionata, tutto caricato

    def _reload_sessions(self):
        sess = _db.list_sessions()
        tf = getattr(self, "_track_filter", None)
        if tf == "Other":
            sess = [s for s in sess if _track_logo_stem(s.get("track")) is None]
        elif tf:
            sess = [s for s in sess if _track_logo_stem(s.get("track")) == tf]
        self._sessions = sess
        self._cur_sess = -1
        self._user_picked_session = False
        if getattr(self, "_overview", None) is not None:
            self._overview.set_sessions(self._sessions, -1,
                                        self._select_session, self._delete_session,
                                        self._open_session_folder)
            if hasattr(self._overview, "set_empty"):
                self._overview.set_empty(True)
        self._close_con()
        self._clear_views()

    def _select_session(self, idx):
        if 0 <= idx < len(self._sessions):
            self._user_picked_session = True
            self._on_session(idx)

    def _open_logs_folder(self):
        from core.paths import LOGS_DIR
        import subprocess, sys
        try:
            LOGS_DIR.mkdir(parents=True, exist_ok=True)
            p = str(LOGS_DIR)
            if sys.platform.startswith("win"):
                os.startfile(p)            # noqa: only on Windows
            elif sys.platform == "darwin":
                subprocess.Popen(["open", p])
            else:
                subprocess.Popen(["xdg-open", p])
        except Exception:
            pass

    def _export_csv(self):
        """Esporta il giro selezionato (tutti i canali dei sample) in CSV."""
        from PySide6.QtWidgets import QFileDialog
        con = getattr(self._data, "con", None)
        if con is None:
            return
        try:
            sel, _ = self._cur_sel_cmp()
        except Exception:
            sel = None
        if sel is None:
            return
        try:
            cur = con.execute("SELECT * FROM samples WHERE lap=? ORDER BY t", (sel,))
            cols = [c[0] for c in cur.description]
            rows = cur.fetchall()
        except Exception:
            return
        fn, _f = QFileDialog.getSaveFileName(self, "Export lap CSV",
                                             f"lap_{sel}.csv", "CSV (*.csv)")
        if not fn:
            return
        import csv
        try:
            with open(fn, "w", newline="") as f:
                wr = csv.writer(f)
                wr.writerow(cols)
                wr.writerows(rows)
        except Exception:
            pass

    def _export_motec(self):
        """Esporta l'intero stint corrente in MoTeC i2 (.ld), giri concatenati
        con tempo e distanza continui, resamplato a 50 Hz."""
        from PySide6.QtWidgets import QFileDialog
        con = getattr(self._data, "con", None)
        if con is None:
            return
        # giri dello stint corrente
        keys = getattr(self, "_stint_keys", [])
        ci = self.cmb_stint.currentIndex()
        cur_key = keys[ci] if 0 <= ci < len(keys) else None
        groups = getattr(self, "_groups", {})
        stint_laps = groups.get(cur_key, []) if cur_key is not None else []
        lap_ids = [L["lap"] for L in stint_laps]
        if not lap_ids:
            try:
                sel, _ = self._cur_sel_cmp()
            except Exception:
                sel = None
            if sel is None:
                return
            lap_ids = [sel]
        # canali: (nome MoTeC, short, unità, colonna sample, fattore)
        spec = [
            ("Speed", "Speed", "km/h", "speed", 1.0),
            ("RPM", "RPM", "rpm", "rpm", 1.0),
            ("Gear", "Gear", "", "gear", 1.0),
            ("Throttle", "Throt", "%", "throttle", 100.0),
            ("Brake", "Brake", "%", "brake", 100.0),
            ("Steering", "Steer", "", "steer", 1.0),
            ("G Force Long", "GLong", "g", "g_long", 1.0),
            ("G Force Lat", "GLat", "g", "g_lat", 1.0),
            ("TC Active", "TCAct", "", "tc_active", 1.0),
            ("ABS Active", "ABSAct", "", "abs_active", 1.0),
            ("Brake Bias", "BBias", "%", "brake_bias", 100.0),
            ("TC Map", "TCMap", "", "tc_map", 1.0),
            ("ABS Map", "ABSMap", "", "abs_map", 1.0),
            ("Fuel Level", "Fuel", "L", "fuel", 1.0),
            ("Virtual Energy", "VE", "%", "ve", 1.0),
            ("Tyre Temp FL", "TtFL", "C", "tyre_t_fl", 1.0),
            ("Tyre Temp FR", "TtFR", "C", "tyre_t_fr", 1.0),
            ("Tyre Temp RL", "TtRL", "C", "tyre_t_rl", 1.0),
            ("Tyre Temp RR", "TtRR", "C", "tyre_t_rr", 1.0),
            ("Tyre Press FL", "TpFL", "kPa", "tyre_p_fl", 1.0),
            ("Tyre Press FR", "TpFR", "kPa", "tyre_p_fr", 1.0),
            ("Tyre Press RL", "TpRL", "kPa", "tyre_p_rl", 1.0),
            ("Tyre Press RR", "TpRR", "kPa", "tyre_p_rr", 1.0),
            ("Tyre Wear FL", "TwFL", "%", "tyre_w_fl", 1.0),
            ("Tyre Wear FR", "TwFR", "%", "tyre_w_fr", 1.0),
            ("Tyre Wear RL", "TwRL", "%", "tyre_w_rl", 1.0),
            ("Tyre Wear RR", "TwRR", "%", "tyre_w_rr", 1.0),
            ("Brake Temp FL", "BtFL", "C", "brake_t_fl", 1.0),
            ("Brake Temp FR", "BtFR", "C", "brake_t_fr", 1.0),
            ("Brake Temp RL", "BtRL", "C", "brake_t_rl", 1.0),
            ("Brake Temp RR", "BtRR", "C", "brake_t_rr", 1.0),
            ("Brake Press FL", "BpFL", "%", "brake_p_fl", 1.0),
            ("Brake Press FR", "BpFR", "%", "brake_p_fr", 1.0),
            ("Brake Press RL", "BpRL", "%", "brake_p_rl", 1.0),
            ("Brake Press RR", "BpRR", "%", "brake_p_rr", 1.0),
            ("Ride Height FL", "RhFL", "mm", "ride_h_fl", 1.0),
            ("Ride Height FR", "RhFR", "mm", "ride_h_fr", 1.0),
            ("Ride Height RL", "RhRL", "mm", "ride_h_rl", 1.0),
            ("Ride Height RR", "RhRR", "mm", "ride_h_rr", 1.0),
            ("Susp Defl FL", "SdFL", "mm", "susp_d_fl", 1.0),
            ("Susp Defl FR", "SdFR", "mm", "susp_d_fr", 1.0),
            ("Susp Defl RL", "SdRL", "mm", "susp_d_rl", 1.0),
            ("Susp Defl RR", "SdRR", "mm", "susp_d_rr", 1.0),
        ]
        read_cols = ["t", "lapdist"] + [s[3] for s in spec]
        # concatena i giri con tempo e distanza continui
        ts = []
        chan_raw = [[] for _ in spec]
        dist = []
        t_off = 0.0; d_off = 0.0
        last = [0.0] * len(spec)
        any_rows = False
        for lid in lap_ids:
            try:
                rs = con.execute(
                    "SELECT %s FROM samples WHERE lap=? ORDER BY t" % ",".join(read_cols),
                    (lid,)).fetchall()
            except Exception:
                continue
            rs = [r for r in rs if r[0] is not None]
            if not rs:
                continue
            any_rows = True
            t0 = float(rs[0][0]); lap_dmax = 0.0
            for r in rs:
                ts.append(t_off + (float(r[0]) - t0))
                ld = r[1] if r[1] is not None else 0.0
                dist.append(d_off + float(ld))
                if ld > lap_dmax:
                    lap_dmax = float(ld)
                for k in range(len(spec)):
                    v = r[2 + k]
                    if v is not None:
                        last[k] = float(v)
                    chan_raw[k].append(last[k])
            t_off = ts[-1] + 1.0 / 50.0
            d_off += lap_dmax
        if not any_rows or len(ts) < 2:
            return
        freq = 50
        t1 = ts[-1]
        ngrid = max(2, int(t1 * freq) + 1)
        grid = [i / float(freq) for i in range(ngrid)]

        def resample(vs):
            res = []; j = 0; nt = len(ts)
            for g in grid:
                while j + 1 < nt and ts[j + 1] < g:
                    j += 1
                if j + 1 >= nt:
                    res.append(vs[-1]); continue
                a, b = ts[j], ts[j + 1]
                if b == a:
                    res.append(vs[j])
                else:
                    res.append(vs[j] + (vs[j + 1] - vs[j]) * (g - a) / (b - a))
            return res

        chans = [("Distance", "Dist", "m", resample(dist))]
        for k, (name, short, unit, _c, fac) in enumerate(spec):
            data = resample(chan_raw[k])
            if fac != 1.0:
                data = [v * fac for v in data]
            chans.append((name, short, unit, data))

        m = getattr(self._overview, "_meta", {}) or {}
        driver = (m.get("driver") or "").strip()
        vehicle = (m.get("vehicle") or "").strip()
        venue = (m.get("track") or "").strip()
        stint_lbl = cur_key if cur_key is not None else "?"
        fn, _f = QFileDialog.getSaveFileName(self, "Export MoTeC i2",
                                             f"stint_{stint_lbl}.ld", "MoTeC i2 (*.ld)")
        if not fn:
            return
        try:
            from core.motec_ld import write_ld
            import datetime as _dt
            write_ld(fn, chans, freq=freq, driver=driver, vehicle=vehicle,
                     venue=venue, comment=f"Stint {stint_lbl}", when=_dt.datetime.now())
        except Exception:
            pass

    def _open_session_folder(self, file_path):
        """Apre la cartella della sessione, evidenziando il file se possibile."""
        import subprocess, sys, os as _os
        try:
            if not file_path:
                return self._open_logs_folder()
            f = str(file_path); folder = _os.path.dirname(f) or "."
            if sys.platform.startswith("win"):
                subprocess.Popen(["explorer", "/select,", f])   # reveal del file
            elif sys.platform == "darwin":
                subprocess.Popen(["open", "-R", f])
            else:
                subprocess.Popen(["xdg-open", folder])
        except Exception:
            pass

    def _on_session(self, idx):
        self._cur_sess = idx
        self._stint_new_cache = {}
        if getattr(self, "_overview", None) is not None:
            self._overview.highlight_session(idx)
        self._close_con()
        self._auto_last_best = None
        if not (0 <= idx < len(self._sessions)):
            self._fill_stints({}); return
        try:
            self._con = sqlite3.connect(self._sessions[idx]["file"])
            meta = _rows(self._con, "SELECT car_class FROM session_meta WHERE id=1")
            self._car_class = (meta[0]["car_class"] if meta else "") or ""
        except Exception:
            self._con = None
            self._fill_stints({}); return
        self._data.set_con(self._con)
        self._data.car_class = self._car_class
        self._autopick_reference()
        for v in self._graph_views:
            v.con = self._con
        laps = _rows(self._con, "SELECT * FROM laps ORDER BY lap")
        groups = {}
        if laps:
            base = min((L["stint"] or 1) for L in laps)
            for L in laps:
                groups.setdefault((L["stint"] or 1) - base + 1, []).append(L)
        # CONDIZIONI dell'Overview prima di _fill_stints: _fill_stints scatena
        # _on_lap -> _sync_board, che deve già vedere il meta (altrimenti per certe
        # sessioni il board resta vuoto al primo click e serve un secondo click).
        if getattr(self, "_overview", None) is not None:
            try:
                mr = _rows(self._con, "SELECT * FROM session_meta WHERE id=1")
                meta_d = dict(mr[0]) if mr else {}
                meta_d["_laps"] = len(laps)
                br = _rows(self._con,
                           "SELECT MIN(lap_time) b FROM laps WHERE lap_time>0 AND invalid=0")
                meta_d["_best"] = br[0]["b"] if br and br[0]["b"] else None
                sr = _rows(self._con,
                           "SELECT MIN(s1) a, MIN(s2) b, MIN(s3) c FROM laps "
                           "WHERE invalid=0 AND s1>0 AND s2>0 AND s3>0")
                if sr and sr[0]["a"] and sr[0]["b"] and sr[0]["c"]:
                    meta_d["_theo"] = sr[0]["a"] + sr[0]["b"] + sr[0]["c"]
                else:
                    meta_d["_theo"] = None
                self._overview.set_meta(meta_d)
            except Exception:
                pass
        self._fill_stints(groups)

    def _fill_stints(self, groups, keep_idx=None, keep_lap_id=None, keep_cmp_id=None):
        self._groups = groups
        self._stint_keys = sorted(groups)
        self.cmb_stint.blockSignals(True)
        self.cmb_stint.clear()
        for s in self._stint_keys:
            self.cmb_stint.addItem(f"Stint {s}")
        sel = 0
        if keep_idx is not None and 0 <= keep_idx < len(self._stint_keys):
            sel = keep_idx
        if self._stint_keys:
            self.cmb_stint.setCurrentIndex(sel)
        self.cmb_stint.blockSignals(False)
        if self._stint_keys:
            self._on_stint(sel, keep_lap_id, keep_cmp_id)
        else:
            self._fill_laps([])

    def _on_stint(self, idx, keep_lap_id=None, keep_cmp_id=None):
        if not (0 <= idx < len(self._stint_keys)):
            self._fill_laps([]); return
        laps = self._groups[self._stint_keys[idx]]
        self._data.set_stint(laps)
        self._fill_laps(laps, keep_lap_id)
        self._fill_compare(laps, keep_cmp_id)

    def _fill_laps(self, laps, keep_lap_id=None):
        self._lap_ids = [L["lap"] for L in laps]
        self.cmb_lap.blockSignals(True)
        self.cmb_lap.clear()
        for L in laps:
            self.cmb_lap.addItem(f"Lap {L['lap']}")
        lap_idx = -1
        if laps:
            fast = _fastest_lap(laps)
            if fast in self._lap_ids:
                fi = self._lap_ids.index(fast)
                self.cmb_lap.setItemData(fi, QColor(_FUCHSIA), Qt.ForegroundRole)
            if keep_lap_id is not None and keep_lap_id in self._lap_ids:
                lap_idx = self._lap_ids.index(keep_lap_id)
            else:
                lap_idx = self._lap_ids.index(fast) if fast in self._lap_ids else 0
            self.cmb_lap.setCurrentIndex(lap_idx)
        self.cmb_lap.blockSignals(False)
        self._on_lap(lap_idx)

    def _visible_cat(self):
        w = self.tabs.currentWidget()
        return w if w in self._cat else None

    def _cur_best_lap(self):
        """Numero del giro più veloce dello stint corrente (None se assente)."""
        keys = getattr(self, "_stint_keys", [])
        ci = self.cmb_stint.currentIndex()
        cur_key = keys[ci] if 0 <= ci < len(keys) else None
        laps = getattr(self, "_groups", {}).get(cur_key, []) if cur_key is not None else []
        return _fastest_lap(laps) if laps else None

    def _set_lap_lazy(self, lap):
        """Aggiorna SUBITO solo il tab visibile; gli altri all'apertura."""
        global _SEL_IS_BEST
        _SEL_IS_BEST = (lap is not None and lap == self._cur_best_lap())
        self._cat_lap = lap
        self._cat_dirty_lap = set(id(t) for t in self._cat)
        vis = self._visible_cat()
        if vis is not None:
            vis.set_lap(lap)
            self._cat_dirty_lap.discard(id(vis))

    def _set_compare_lazy(self, lap):
        global _CMP_IS_BEST
        _CMP_IS_BEST = (lap is not None and lap == self._cur_best_lap())
        self._cat_cmp = lap
        self._cat_dirty_cmp = set(id(t) for t in self._cat)
        vis = self._visible_cat()
        if vis is not None:
            vis.set_compare(lap)
            self._cat_dirty_cmp.discard(id(vis))

    def _on_tab_changed(self, *_):
        """All'apertura di un tab rimasto indietro, applica lo stato corrente."""
        vis = self._visible_cat()
        if vis is None:
            return
        if id(vis) in self._cat_dirty_lap and self._cat_lap is not _UNSET:
            vis.set_lap(self._cat_lap)
            self._cat_dirty_lap.discard(id(vis))
        if id(vis) in self._cat_dirty_cmp and self._cat_cmp is not _UNSET:
            vis.set_compare(self._cat_cmp)
            self._cat_dirty_cmp.discard(id(vis))

    def _on_lap(self, idx):
        self._sel_none = False
        lap = self._lap_ids[idx] if 0 <= idx < len(self._lap_ids) else None
        self._set_lap_lazy(lap)
        self._sync_board()

    def _fill_compare(self, laps, keep_cmp_id=None):
        self._cmp_ids = [L["lap"] for L in laps]
        self.cmb_cmp.blockSignals(True)
        self.cmb_cmp.clear()
        # voce REF sempre in cima (best record classe+pista+meteo)
        ref_ok = getattr(self, "_ref_available", False)
        ref_lab = ("REF  " + _fmt(self._data.ref_time)) if (ref_ok and self._data.ref_time) else "REF \u2014"
        self.cmb_cmp.addItem(ref_lab)
        try:
            self.cmb_cmp.model().item(0).setEnabled(bool(ref_ok))
        except Exception:
            pass
        for L in laps:
            self.cmb_cmp.addItem(f"Lap {L['lap']}")
        # default: REF se disponibile, altrimenti secondo miglior giro
        if keep_cmp_id is not None and keep_cmp_id in self._cmp_ids:
            cmp_idx = self._cmp_ids.index(keep_cmp_id) + 1
        elif ref_ok:
            cmp_idx = 0
        elif laps:
            _, second = _two_best_laps(laps)
            li = self._cmp_ids.index(second) if second in self._cmp_ids else 0
            cmp_idx = li + 1
        else:
            cmp_idx = 0
        self.cmb_cmp.setCurrentIndex(cmp_idx)
        self.cmb_cmp.blockSignals(False)
        self._on_cmp(cmp_idx)

    def _on_cmp(self, idx):
        self._cmp_none = False
        if idx == 0:                         # REF
            self._data.ref_on = getattr(self, "_ref_available", False)
            self._set_compare_lazy(None)
        else:
            self._data.ref_on = False
            lap = self._cmp_ids[idx - 1] if 1 <= idx <= len(self._cmp_ids) else None
            self._set_compare_lazy(lap)
        self._sync_board()

    # ── board Overview (pilota i combo nascosti) ──────────────────────────
    def _board_stint(self, key):
        keys = getattr(self, "_stint_keys", [])
        if key in keys:
            self.cmb_stint.setCurrentIndex(keys.index(key))

    def _cur_sel_cmp(self):
        """(sel_lap_id|None, cmp_spec) attuali, tenendo conto dei flag 'none'."""
        ids = getattr(self, "_lap_ids", [])
        li = self.cmb_lap.currentIndex()
        sel = None if getattr(self, "_sel_none", False) else (ids[li] if 0 <= li < len(ids) else None)
        if getattr(self, "_cmp_none", False):
            cmp = None
        else:
            ci = self.cmb_cmp.currentIndex()
            cids = getattr(self, "_cmp_ids", [])
            if ci == 0:
                cmp = ("ref",) if getattr(self, "_ref_available", False) else None
            else:
                cid = cids[ci - 1] if 1 <= ci <= len(cids) else None
                cmp = ("lap", cid) if cid is not None else None
        return sel, cmp

    def _board_select(self, lap_id):
        ids = getattr(self, "_lap_ids", [])
        if lap_id in ids:
            i = ids.index(lap_id)
            self._sel_none = False
            self.cmb_lap.blockSignals(True); self.cmb_lap.setCurrentIndex(i)
            self.cmb_lap.blockSignals(False)
            self._on_lap(i)

    def _board_select_none(self):
        self._sel_none = True
        self._set_lap_lazy(None)
        self._sync_board()

    def _board_compare(self, lap_id):
        ids = getattr(self, "_cmp_ids", [])
        if lap_id in ids:
            i = ids.index(lap_id) + 1
            self._cmp_none = False
            self.cmb_cmp.blockSignals(True); self.cmb_cmp.setCurrentIndex(i)
            self.cmb_cmp.blockSignals(False)
            self._on_cmp(i)

    def _board_compare_ref(self):
        if getattr(self, "_ref_available", False):
            self._cmp_none = False
            self.cmb_cmp.blockSignals(True); self.cmb_cmp.setCurrentIndex(0)
            self.cmb_cmp.blockSignals(False)
            self._on_cmp(0)

    def _board_compare_none(self):
        self._cmp_none = True
        self._data.ref_on = False
        self._set_compare_lazy(None)
        self._sync_board()

    def _board_pick(self, item):
        """Un solo check per riga: regola sel-sticky.
        item = ('lap', id), ('ref',) oppure ('pace',)."""
        if item and item[0] == "pace":
            self._pace_sel = not getattr(self, "_pace_sel", True)
            self._sync_board()
            return
        sel, cmp = self._cur_sel_cmp()
        if item[0] == "lap":
            lid = item[1]
            if sel == lid:                       # deseleziona il Selected
                if cmp and cmp[0] == "lap":      # promuovi il compare-lap a selected
                    promote = cmp[1]
                    self._board_compare_none()
                    self._board_select(promote)
                else:
                    self._board_select_none()
            elif cmp == ("lap", lid):            # deseleziona il compare
                self._board_compare_none()
            else:
                if sel is None:
                    self._board_select(lid)
                else:
                    self._board_compare(lid)
        else:                                    # REF: sempre come compare
            if cmp == ("ref",):
                self._board_compare_none()
            else:
                self._board_compare_ref()

    def _stint_start_new_from_samples(self, laps):
        """Verità dal DB: integrità a inizio stint = MAX wear tra i sample dello
        stint (il consumo cala, quindi il picco = uscita box). ~100% -> nuova.
        None se non disponibile."""
        if not laps:
            return None
        con = getattr(self._data, "con", None)
        if con is None:
            return None
        ids = [L.get("lap") for L in laps if L.get("lap") is not None]
        if not ids:
            return None
        cache = self.__dict__.setdefault("_stint_new_cache", {})
        ck = tuple(ids)
        if ck in cache:
            return cache[ck]
        qm = ",".join("?" * len(ids))
        try:
            rs = _rows(con, "SELECT MAX((tyre_w_fl+tyre_w_fr+tyre_w_rl+tyre_w_rr)/4.0) AS mw "
                            "FROM samples WHERE lap IN (%s) AND tyre_w_fl IS NOT NULL" % qm, ids)
        except Exception:
            return None
        if not rs or rs[0].get("mw") is None:
            cache[ck] = None
            return None
        res = rs[0]["mw"] >= 99.5
        cache[ck] = res
        return res

    def _stint_start_new4_from_samples(self, laps):
        """Come sopra ma PER GOMMA: [FL,FR,RL,RR] bool (MAX wear per ruota
        >=99.5 -> nuova). None se non disponibile."""
        if not laps:
            return None
        con = getattr(self._data, "con", None)
        if con is None:
            return None
        ids = [L.get("lap") for L in laps if L.get("lap") is not None]
        if not ids:
            return None
        cache = self.__dict__.setdefault("_stint_new4_cache", {})
        ck = tuple(ids)
        if ck in cache:
            return cache[ck]
        qm = ",".join("?" * len(ids))
        try:
            rs = _rows(con, "SELECT MAX(tyre_w_fl) a, MAX(tyre_w_fr) b, "
                            "MAX(tyre_w_rl) c, MAX(tyre_w_rr) d "
                            "FROM samples WHERE lap IN (%s) AND tyre_w_fl IS NOT NULL" % qm, ids)
        except Exception:
            return None
        if not rs or rs[0].get("a") is None:
            cache[ck] = None
            return None
        r0 = rs[0]
        res = [(r0["a"] or 0) >= 99.5, (r0["b"] or 0) >= 99.5,
               (r0["c"] or 0) >= 99.5, (r0["d"] or 0) >= 99.5]
        cache[ck] = res
        return res

    def _maybe_learn(self, ov):
        """A sessione ferma, aggiorna il profilo appreso pista+classe una sola
        volta per file (apprendimento sessione dopo sessione)."""
        rec = getattr(self, "_recorder", None)
        if rec and rec.is_armed():
            return                              # non in registrazione
        con = getattr(self, "_con", None)
        if con is None:
            return
        f = None
        if 0 <= getattr(self, "_cur_sess", -1) < len(getattr(self, "_sessions", [])):
            f = self._sessions[self._cur_sess].get("file")
        if not f:
            return
        seen = getattr(self, "_learned_files", None)
        if seen is None:
            seen = set(); self._learned_files = seen
        if f in seen:
            return
        seen.add(f)
        m = getattr(ov, "_meta", {}) or {}
        cls = getattr(self, "_car_class", "") or m.get("car_class", "")
        try:
            from core import engineer_learn as EL
            EL.update_from_session(con, m.get("track"), cls, energy_car=False)
        except Exception:
            pass

    def _sync_board(self):
        ov = getattr(self, "_overview", None)
        if ov is None or not hasattr(ov, "board"):
            return
        if not getattr(self, "_user_picked_session", False):
            if hasattr(ov, "set_empty"):
                ov.set_empty(True)
            return
        keys = getattr(self, "_stint_keys", [])
        ci = self.cmb_stint.currentIndex()
        cur_key = keys[ci] if 0 <= ci < len(keys) else None
        groups = getattr(self, "_groups", {})
        laps = groups.get(cur_key, []) if cur_key is not None else []
        m0 = getattr(ov, "_meta", {}) or {}
        has_meta = bool(m0.get("track") or m0.get("session_type") or m0.get("driver"))
        if (not keys) and (not laps) and (not has_meta):
            if hasattr(ov, "set_empty"):
                ov.set_empty(True)
            return
        if hasattr(ov, "set_empty"):
            ov.set_empty(False)
        best = _fastest_lap(laps) if laps else None
        sel, cmp_spec = self._cur_sel_cmp()
        ref = None
        if getattr(self, "_ref_available", False):
            _rs = _ov_session_label(self._data.ref_session)
            _rd = _date_human(self._data.ref_started)
            _rwhen = " \u00b7 ".join(p for p in (_rs, _rd)
                                    if p and p != "Session")
            ref = {"driver": self._data.ref_driver, "team": self._data.ref_team,
                   "vehicle": self._data.ref_vehicle, "time": self._data.ref_time,
                   "secs": self._data.ref_secs, "when": _rwhen,
                   "compounds4": self._data.ref_compounds4,
                   "tyre_state": self._data.ref_tyre_state,
                   "load_pct": self._data.ref_load_pct,
                   "load_kind": self._data.ref_load_kind,
                   "wear4": self._data.ref_wear4,
                   "fuel_l": self._data.ref_fuel_l}
        theo = None
        valid = [L for L in laps if not L.get("invalid")
                 and L.get("s1") and L.get("s2") and L.get("s3")]
        if valid:
            theo = (min(L["s1"] for L in valid) + min(L["s2"] for L in valid)
                    + min(L["s3"] for L in valid))
        cmp_lap = cmp_spec[1] if (cmp_spec and cmp_spec[0] == "lap") else None
        tyre4 = []
        m = getattr(ov, "_meta", {}) or {}
        c4 = (m.get("compounds4") or "").strip()
        if c4:
            tyre4 = [x.strip() for x in c4.split(",") if x.strip()]
        # ONLINE REF: best globale dal Worker (se configurato in settings/online.json).
        # Senza url/dati la card blue resta sui placeholder. Niente pace sul board.
        pace_info = {"kind": None, "sel": getattr(self, "_pace_sel", True)}
        board_pace = None
        try:
            from core import online as _online
            if _online.enabled():
                _online.load_async()
                _wet = float(m.get("wetness") or 0.0) > 0.10
                _okey = _online.make_key(class_tag(m.get("car_class") or ""),
                                         m.get("track"), _wet)
                _row = _online.get_ref(_okey) if _okey else None
                if _row:
                    _lm = _row.get("lap_ms")
                    _s1 = _row.get("s1_ms"); _s2 = _row.get("s2_ms"); _s3 = _row.get("s3_ms")
                    _ld = _row.get("ve_pct")
                    if _ld is None:
                        _ld = _row.get("fuel_pct")
                    pace_info.update({
                        "online": True,
                        "player": _row.get("player"),
                        "team": _row.get("team"),
                        "car": _row.get("car"),
                        "compound": _row.get("compound"),
                        "compounds4": _row.get("compounds4"),
                        "tyre_state_pct": _row.get("tyre_state_pct"),
                        "load_pct": _ld,
                        "fuel_l": _row.get("fuel_l"),
                        "ref_time": (_lm / 1000.0) if _lm else None,
                        "secs": [(_s1 / 1000.0) if _s1 else None,
                                 (_s2 / 1000.0) if _s2 else None,
                                 (_s3 / 1000.0) if _s3 else None],
                    })
        except Exception:
            pass
        # gap blu sul giro migliore quando la card ONLINE REF e selezionata
        if (pace_info.get("online") and pace_info.get("sel")
                and pace_info.get("ref_time") and best):
            _bL = next((L for L in laps if L["lap"] == best), None)
            _blt = (_bL.get("lap_time") if _bL else None) or 0
            if _blt > 0:
                board_pace = {"kind": "online",
                              "label": pace_info.get("player") or "ONLINE",
                              "gap": _blt - pace_info["ref_time"],
                              "color": "#4aa3df"}
        stint_new = {}
        stint_new4 = {}
        for k in keys:
            lk = groups.get(k, [])
            v = self._stint_start_new_from_samples(lk)
            if v is None and lk:
                v = ov.board._stint_started_new(lk)
            stint_new[k] = True if v is None else bool(v)
            stint_new4[k] = self._stint_start_new4_from_samples(lk)
        _rec = getattr(self, "_recorder", None)
        ov.board._live = bool(_rec) and _rec.is_armed()   # auto-scroll solo in pista
        try:
            self._maybe_learn(ov)
        except Exception:
            pass
        ov.board.update_board(keys, cur_key, laps, best, sel, cmp_lap, tyre4, pace=board_pace, stint_new=stint_new, stint_new4=stint_new4)
        ov.set_ref(ref, cmp_spec == ("ref",), theo, self._board_pick, pace=pace_info)

    def _live_refresh(self):
        """Aggiorna la Review durante la sessione: nuove sessioni/giri appena
        registrati, preservando la selezione (sessione/stint/giro/compare)."""
        if self.stack.currentIndex() != 0:
            return                                   # solo quando la Review è visibile
        rec = getattr(self, "_recorder", None)
        armed_now = bool(rec) and rec.is_armed()
        if armed_now and not getattr(self, "_was_armed_live", False):
            self._live_jump_pending = True         # sessione in pista appena avviata
        if not armed_now:
            self._live_jump_pending = False
        self._was_armed_live = armed_now
        if not armed_now:
            return                       # a riposo la lista sessioni non cambia
        live_file = rec.current_file() if (rec and armed_now) else None

        cur_file = None
        si = self._cur_sess
        if 0 <= si < len(self._sessions):
            cur_file = self._sessions[si]["file"]
        cur_stint = self.cmb_stint.currentIndex()
        li = self.cmb_lap.currentIndex()
        keep_lap = self._lap_ids[li] if 0 <= li < len(self._lap_ids) else None
        ci = self.cmb_cmp.currentIndex()
        keep_cmp = self._cmp_ids[ci - 1] if 1 <= ci <= len(self._cmp_ids) else None

        sessions_all = _db.list_sessions()
        live_sess = (next((s for s in sessions_all if s["file"] == live_file), None)
                     if live_file else None)
        # registrazione appena avviata su una pista diversa da quella filtrata:
        # cambia il filtro circuito sulla nuova pista (es. ero su Monza -> nuova)
        if getattr(self, "_live_jump_pending", False) and live_sess is not None:
            live_stem = _track_logo_stem(live_sess.get("track")) or "Other"
            if getattr(self, "_track_filter", None) != live_stem:
                self._track_filter = live_stem
        # applica il filtro circuito corrente (coerente con _reload_sessions)
        tf = getattr(self, "_track_filter", None)
        if tf == "Other":
            sessions = [s for s in sessions_all if _track_logo_stem(s.get("track")) is None]
        elif tf:
            sessions = [s for s in sessions_all if _track_logo_stem(s.get("track")) == tf]
        else:
            sessions = sessions_all
        self._sessions = sessions
        live_idx = (next((i for i, s in enumerate(sessions)
                          if s["file"] == live_file), None)
                    if live_file else None)
        if getattr(self, "_live_jump_pending", False) and live_idx is not None:
            sel_idx = live_idx                     # salta sulla sessione in registrazione
            cur_file = live_file
            cur_stint = 0; keep_lap = None; keep_cmp = None   # niente residui
            self._live_jump_pending = False
            self._user_picked_session = True        # in registrazione il pannello si mostra
        else:
            sel_idx = 0
            for i, s in enumerate(sessions):
                if cur_file and s["file"] == cur_file:
                    sel_idx = i
        self._cur_sess = sel_idx if sessions else -1
        if getattr(self, "_overview", None) is not None:
            self._overview.set_sessions(sessions, self._cur_sess,
                                        self._select_session, self._delete_session,
                                        self._open_session_folder)
        if not sessions:
            self._close_con(); self._fill_stints({}); return

        # riapre la connessione per vedere i giri appena committati dal recorder
        self._close_con()
        try:
            self._con = sqlite3.connect(sessions[sel_idx]["file"])
            meta = _rows(self._con, "SELECT car_class FROM session_meta WHERE id=1")
            self._car_class = (meta[0]["car_class"] if meta else "") or ""
        except Exception:
            self._con = None
            self._fill_stints({}); return
        self._data.set_con(self._con)
        self._data.car_class = self._car_class
        self._autopick_reference()
        for v in self._graph_views:
            v.con = self._con
        laps = _rows(self._con, "SELECT * FROM laps ORDER BY lap")
        groups = {}
        if laps:
            base = min((L["stint"] or 1) for L in laps)
            for L in laps:
                groups.setdefault((L["stint"] or 1) - base + 1, []).append(L)
        # follow-stint: se in live (sessione attiva, la più recente) compare un nuovo
        # stint e si stava guardando l'ultimo, passa automaticamente al nuovo.
        keys = sorted(groups)
        auto_idx = cur_stint
        prev_file = getattr(self, "_live_stint_file", None)
        prev_cnt = getattr(self, "_live_stint_count", 0)
        if prev_file != cur_file:
            prev_cnt = 0                              # nuova sessione: reset
        if (sel_idx == 0 and prev_cnt > 0 and len(keys) > prev_cnt
                and cur_stint == prev_cnt - 1):
            auto_idx = len(keys) - 1                  # segui il nuovo stint
        self._live_stint_count = len(keys)
        self._live_stint_file = cur_file
        self._fill_stints(groups, keep_idx=auto_idx,
                          keep_lap_id=keep_lap, keep_cmp_id=keep_cmp)

    def _delete_session(self, idx=None):
        if idx is None or idx is False:
            idx = self._cur_sess
        if not (0 <= idx < len(self._sessions)):
            return
        s = self._sessions[idx]
        r = QMessageBox.question(
            self, "Delete session",
            "Permanently delete this telemetry?\n\n" + s.get("name", ""),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if r != QMessageBox.Yes:
            return
        self._close_con()
        err = None
        for suffix in ("-wal", "-shm", ""):      # sidecar prima, file principale per ultimo
            p = s["file"] + suffix
            try:
                if os.path.exists(p):
                    os.remove(p)
            except OSError as e:
                if suffix == "":
                    err = e
        if os.path.exists(s["file"]):
            QMessageBox.warning(
                self, "Delete session",
                "Could not delete the file. It is probably in use by an "
                "active recording (stop the on-track session and try again).\n\n"
                + (str(err) if err else s["file"]))
            return
        self._reload_sessions()

    def closeEvent(self, e):
        if getattr(self, "_overview", None) is not None:
            try:
                self._overview.stop()
            except Exception:
                pass
        if getattr(self, "_recorder", None) is not None:
            try:
                self._recorder.stop()
            except Exception:
                pass
        eng = getattr(self, "_engineer", None)
        if eng is not None and getattr(eng, "_ov", None) is not None:
            try:
                eng._ov.close()
            except Exception:
                pass
        self._close_con()
        try:
            self._data.clear_reference()
        except Exception:
            pass
        super().closeEvent(e)
