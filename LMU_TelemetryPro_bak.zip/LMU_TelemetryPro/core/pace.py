"""
core/pace.py — "Pace" verdict from Ohne Speed's published LMU laptimes sheet.

The published Google Sheet (CSV export) holds, per class and per track, a
race-pace baseline ("Alien ~100%") and a hot-lap/Q reference ("Class avgW").
Each lap is rated by how far its time sits above the baseline:

    ~100%  Alien        101%  Competitive
    102-103%  Good      104-105%  Midpack
    106%  Tail-ender    >=107%  Offline

Pure stdlib (urllib + csv): no Qt here so the parser stays testable in isolation.
fetch_table() is cached in RAM; the network call happens once per process unless
refresh=True. Everything degrades to "no verdict" (None) instead of raising.
"""
import csv
import io
import re
import threading
import time
import urllib.request
from pathlib import Path

from core.classes import class_tag

# Published CSV endpoint of the sheet (read-only, public).
CSV_URL = ("https://docs.google.com/spreadsheets/d/e/"
           "2PACX-1vTN03UvJDm99byA6vQPZHKOCYVvfxLu1zkJAzdaKyROykzEKY2-"
           "Xl1rl1q5znZEf36m88dxMKsY2eaO/pub?output=csv")

# Colonne fisse del foglio (per ogni riga dato):
# 0 key | 1 Track | 2 Patch | 3 Class avgW (Hotlap/Q) | 4..11 bande | 12 Fastest car | 16 tag classe
_TRACK_COL = 1
_HOT_COL = 3
_CAR_COL = 12
_CLS_COL = 16
# (internal label, pct text, column index) — Alien->Offline
_BAND_DEFS = [
    ("Alien",       "~100%", 4),
    ("Competitive", "101%",  5),
    ("Good",        "102%",  6),
    ("Good",        "103%",  7),
    ("Midpack",     "104%",  8),
    ("Midpack",     "105%",  9),
    ("Tail-ender",  "106%",  10),
    ("Offline",     "107%",  11),
]

# Tag classe del foglio (col16) -> tag interno app (per badge/ordinamento).
# LMP2 e' diviso in due tabelle: ELMS e WEC (auto/tempi diversi) -> entrambe P2.
_SHEET_CLASS = {
    "LMGT3": "GT3", "LMH": "HY", "LMP3": "P3",
    "LMP2elms": "P2", "LMP2wec": "P2", "GTE": "GTE",
}


def display_class(sheet_id):
    """Tag foglio (LMGT3/LMP2wec/...) -> tag interno app (GT3/P2/...)."""
    return _SHEET_CLASS.get(sheet_id, sheet_id)


def _sheet_keys_for(app_tag):
    """Tag app (GT3/HY/P3/P2/GTE) -> chiavi foglio (P2 -> ELMS + WEC)."""
    return [k for k, v in _SHEET_CLASS.items() if v == app_tag]

# Colore per banda (sfondo card; bianco sopra). Le due Good / Midpack condividono.
VERDICT_COLOR = {
    "Alien":       "#2e8b57",
    "Competitive": "#3b6fb5",
    "Good":        "#4f9e6a",
    "Midpack":     "#c9a227",
    "Tail-ender":  "#c2627a",
    "Offline":     "#b34740",
}
HOTLAP_COLOR = "#6b7079"   # famiglia hotlap/Q (grigio)

_TIME_RE = re.compile(r"^\s*(\d+):(\d{2})(?:\.(\d{1,3}))?\s*$")

# Canonical track keys (match world_records.json) + loose aliases. We normalise
# any sheet/track string to one of these so class+track lookups line up.
_TRACK_ALIASES = {
    "lemans": "LeMans", "lesarthe": "LeMans", "sarthe": "LeMans", "lemans24": "LeMans",
    "spa": "Spa", "spafrancorchamps": "Spa", "francorchamps": "Spa",
    "imola": "Imola", "enzoedino": "Imola",
    "monza": "Monza",
    "bahrain": "Bahrain", "sakhir": "Bahrain",
    "lusail": "Lusail", "qatar": "Lusail", "losail": "Lusail",
    "cota": "COTA", "americas": "COTA", "austin": "COTA",
    "fuji": "Fuji",
    "interlagos": "Interlagos", "saopaulo": "Interlagos", "carlospace": "Interlagos",
    "sebring": "Sebring",
    "portimao": "Portimao", "algarve": "Portimao",
    "barcelona": "Barcelona", "catalunya": "Barcelona", "montmelo": "Barcelona",
    "paulricard": "PaulRicard", "lecastellet": "PaulRicard", "castellet": "PaulRicard",
    "silverstone": "Silverstone",
}


def _norm_key(s):
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


# Marcatori di LAYOUT alternativo (oltre al tracciato principale). Servono a non
# far prendere a un layout alternativo il tempo del layout base (es. Monza Curva
# Grande non deve usare il tempo di Monza normale). Ordine: più lungo prima.
_ALT_LAYOUTS = ("curvagrande", "outercircuit", "outer", "paddock", "endurance",
                "shortcircuit", "short", "classic", "school", "mulsanne")


def _layout_marker(s):
    """'' per il layout principale, altrimenti il marcatore del layout alternativo."""
    n = _norm_key(s)
    for m in _ALT_LAYOUTS:
        if m in n:
            return m
    return ""


def _track_key(s):
    """Any track string -> canonical short key, or '' if unknown."""
    k = _norm_key(s)
    if not k:
        return ""
    if k in _TRACK_ALIASES:
        return _TRACK_ALIASES[k]
    for alias, canon in _TRACK_ALIASES.items():
        if alias in k or k in alias:
            return canon
    return ""


def _to_secs(cell):
    """'1:59.08' -> 119.08 ; '38.807' handled too ; None if not a time."""
    if cell is None:
        return None
    m = _TIME_RE.match(str(cell))
    if not m:
        return None
    mm, ss, frac = m.group(1), m.group(2), m.group(3) or "0"
    try:
        return int(mm) * 60 + int(ss) + float("0." + frac)
    except Exception:
        return None


def _detect_class_title(cells):
    """Riga-titolo di un blocco classe (LMGT3/LMP3/LMP2ELMS/LMH/GTE)."""
    for c in cells:
        s = re.sub(r"[^A-Z0-9]", "", (c or "").upper())
        if not s:
            continue
        if s == "LMGT3":
            return "GT3"
        if s in ("LMP2ELMS", "LMP2"):
            return "P2"
        if s == "LMP3":
            return "P3"
        if s in ("LMH", "HYPERCAR", "LMDH"):
            return "HY"
        if s == "GTE":
            return "GTE"
    return ""


_CAR_BRANDS = [
    "Aston Martin", "Mercedes-Amg", "Mercedes", "Lamborghini", "Corvette",
    "Cadillac", "Chevrolet", "Ferrari", "Porsche", "Toyota", "Peugeot",
    "Genesis", "Ginetta", "Duqueine", "Oreca", "Lexus", "BMW", "Ford",
    "Alpine", "Mclaren", "McLaren", "Ligier", "Glickenhaus", "Vanwall",
]


def _brand_from_car(car):
    """'Lamborghini Huracan EVO II (v1.33)' -> 'Lamborghini' (stem logo)."""
    if not car:
        return ""
    c = re.sub(r"\(.*?\)", "", car).strip()
    cl = c.lower()
    for b in _CAR_BRANDS:
        if cl.startswith(b.lower()):
            if b.lower().startswith("mercedes"):
                return "Mercedes-Amg"
            if b == "McLaren":
                return "Mclaren"
            return b
    return c.split()[0] if c else ""


def parse(text):
    """CSV del foglio (tutte le classi impilate) ->
    {sheet_class_id: {raw_track: {'hot','bands','car','brand'}}}.

    La classe di ogni riga e' presa dalla col16 (LMGT3/LMH/LMP3/LMP2elms/
    LMP2wec/GTE): affidabile e immune dalle righe-titolo/header. Colonne dato:
    1 Track, 3 Class avgW, 4..11 bande, 12 auto.
    """
    out = {}
    try:
        reader = csv.reader(io.StringIO(text))
    except Exception:
        return out
    for cells in reader:
        if len(cells) <= _CLS_COL:
            continue
        cls = cells[_CLS_COL].strip()
        if cls not in _SHEET_CLASS:
            continue                          # header/titoli/altro: scartati
        track = (cells[_TRACK_COL] or "").strip()
        if not track:
            continue
        hot = _to_secs(cells[_HOT_COL]) if len(cells) > _HOT_COL else None
        bands = []
        for label, pct, idx in _BAND_DEFS:
            secs = _to_secs(cells[idx]) if len(cells) > idx else None
            bands.append({"label": label, "pct": pct, "secs": secs})
        if bands[0]["secs"] is None and hot is None:
            continue
        car = (cells[_CAR_COL].strip() if len(cells) > _CAR_COL else "")
        out.setdefault(cls, {})[track] = {
            "hot": hot, "bands": bands,
            "car": car, "brand": _brand_from_car(car),
        }
    return out


def _find_rec(table, car_class, track):
    """Trova (rec, raw_track, sheet_id) per classe app + pista in-gioco."""
    app = class_tag(car_class or "")
    for sk in _sheet_keys_for(app):
        tracks = table.get(sk, {})
        raw = _resolve_track(tracks, track)
        if raw:
            return tracks[raw], raw, sk
    return None, None, None


def _resolve_track(tracks, ingame):
    """Dal nome pista in-gioco trova la riga giusta del foglio (gestendo le
    varianti: preferisce '(wec)' o il layout senza parentesi)."""
    if not tracks or not ingame:
        return None
    key = _track_key(ingame)
    cands = [raw for raw in tracks if key and _track_key(raw) == key]
    if not cands:
        nk = _norm_key(ingame)
        cands = [raw for raw in tracks if _norm_key(raw).startswith(nk) or nk.startswith(_norm_key(raw))]
    if not cands:
        return None
    # layout-aware: il layout in-gioco deve combaciare col layout della riga.
    # Se il giocatore è su un layout alternativo (es. Monza Curva Grande) e il
    # foglio non ha quel layout, NON usare il tempo del layout base -> None.
    want = _layout_marker(ingame)
    same = [raw for raw in cands if _layout_marker(raw) == want]
    if want and not same:
        return None
    cands = same or cands
    for raw in cands:
        if "(wec)" in raw.lower():
            return raw
    for raw in cands:
        if "(" not in raw:
            return raw
    return cands[0]


def reference(car_class, track, lap_secs, session, table=None):
    """Riferimento contestuale per la card.
    session 'qualifying' -> Hotlap (Class avgW); altrimenti -> banda racepace
    piu' vicina al passo. Ritorna dict o None."""
    table = table if table is not None else load_table()
    rec, raw, _sk = _find_rec(table, car_class, track)
    if not rec:
        return None
    base = {"car": rec.get("car", ""), "brand": rec.get("brand", ""), "track": raw}
    if (session or "").lower().startswith("qual"):
        if not rec.get("hot"):
            return None
        return dict(base, kind="hotlap", label="Hotlap",
                    secs=rec["hot"], color=HOTLAP_COLOR)
    timed = [(b["label"], b["secs"]) for b in rec.get("bands", []) if b.get("secs")]
    if not timed:
        return None
    if lap_secs and lap_secs > 0:
        label, secs = min(timed, key=lambda x: abs(x[1] - lap_secs))
    else:
        label, secs = timed[0]
    return dict(base, kind="pace", label=label, secs=secs,
                color=VERDICT_COLOR.get(label, "#6b7079"))


def generated_at():
    """time.struct_time dell'ultimo download (mtime della cache), o None."""
    try:
        return time.localtime(CACHE_FILE.stat().st_mtime)
    except Exception:
        return None


_CACHE = {"table": None, "loading": False, "done": False}

# Copia locale del foglio (CSV grezzo). Si riscarica al massimo una volta ogni
# MAX_AGE; nel frattempo si usa questa, senza rete.
CACHE_FILE = Path(__file__).resolve().parent.parent / "settings" / "pace_cache.csv"
MAX_AGE = 24 * 3600        # 24h


def _cache_age():
    try:
        return time.time() - CACHE_FILE.stat().st_mtime
    except Exception:
        return None          # file assente


def _load_cache_into_ram():
    """Carica la copia locale (anche vecchia) in RAM. True se riuscito."""
    try:
        if CACHE_FILE.exists():
            _CACHE["table"] = parse(CACHE_FILE.read_text(encoding="utf-8", errors="replace"))
            _CACHE["done"] = True
            return True
    except Exception:
        pass
    return False


def fetch_table(refresh=False, timeout=8):
    """Download + scrittura cache + parse in RAM (BLOCCANTE). Per test/refresh
    espliciti. La UI usa load_async() per non bloccare l'event loop."""
    if _CACHE["done"] and not refresh:
        return _CACHE["table"]
    table = {}
    try:
        req = urllib.request.Request(CSV_URL, headers={"User-Agent": "LMU-TelemetryPro"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
        try:
            CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            CACHE_FILE.write_text(raw, encoding="utf-8")   # persiste per i prossimi avvii
        except Exception:
            pass
        table = parse(raw)
    except Exception:
        table = _CACHE["table"] or {}                      # rete ko: tieni la cache esistente
    _CACHE["table"] = table
    _CACHE["done"] = True
    return table


def load_async(timeout=8):
    """Pronta-subito + refresh al massimo 1/giorno, sempre fuori dal thread UI.
    1) carica la copia locale (anche vecchia) cosi' la card funziona subito;
    2) se la copia manca o ha piu' di 24h, scarica in un thread di sfondo."""
    if _CACHE["table"] is None:
        _load_cache_into_ram()                # uso immediato della cache, niente rete
    age = _cache_age()
    fresh = age is not None and age < MAX_AGE
    if _CACHE["loading"] or fresh:
        return                                # gia' aggiornata oggi: nessun download
    _CACHE["loading"] = True

    def _work():
        try:
            fetch_table(refresh=True, timeout=timeout)
        finally:
            _CACHE["loading"] = False

    t = threading.Thread(target=_work, name="pace-fetch", daemon=True)
    t.start()


def ready():
    """True se in RAM c'e' una tabella (caricata da cache o appena scaricata)."""
    return _CACHE["table"] is not None


def load_table(refresh=False):
    """Tabella di riferimento in RAM, letta dalla copia locale. {} se assente.
    Non scarica nulla (per il download usa load_async)."""
    if refresh:
        _CACHE["table"] = None
    if _CACHE["table"] is None:
        _load_cache_into_ram()
        if _CACHE["table"] is None:
            _CACHE["table"] = {}
    return _CACHE["table"]


def verdict(car_class, track, lap_secs, is_hot=False, table=None):
    """(label, color, pct) per un giro, o None. Sceglie la banda piu' vicina."""
    if not lap_secs or lap_secs <= 0:
        return None
    table = table if table is not None else load_table()
    rec, _raw, _sk = _find_rec(table, car_class, track)
    if not rec:
        return None
    timed = [(b["label"], b["secs"]) for b in rec.get("bands", []) if b.get("secs")]
    if not timed:
        return None
    label, secs = min(timed, key=lambda x: abs(x[1] - lap_secs))
    pct = lap_secs / secs * 100.0 if secs else 0.0
    return label, VERDICT_COLOR.get(label, "#6b7079"), pct
