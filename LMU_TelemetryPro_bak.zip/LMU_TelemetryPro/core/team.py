"""Modalita' squadra (driver swap endurance).

Una cartella condivisa (es. sincronizzata con Syncthing/Drive tra i PC dei
piloti) ospita:
  - learn/                 i profili appresi (passo, consumo, best, frenate)
  - live_state.json        lo stato live di CHI sta guidando (uno scrittore)

Chi guida scrive; gli altri leggono. Non guidano in tre nello stesso momento,
quindi niente conflitti. Se la modalita' e' spenta o la cartella non e' valida,
tutto torna ai dati locali (USER_DIR).
"""
import json
import time
from pathlib import Path

try:
    from core import paths as _paths
    _CFG = _paths.USER_DIR / "team.json"
except Exception:
    _CFG = Path(__file__).resolve().parent.parent / "settings" / "team.json"


def load_cfg():
    try:
        d = json.loads(_CFG.read_text(encoding="utf-8")) or {}
    except Exception:
        d = {}
    return {"enabled": bool(d.get("enabled")),
            "dir": d.get("dir") or "",
            "driver": d.get("driver") or "",
            "team": d.get("team") or ""}


def save_cfg(enabled=None, dir=None, driver=None, team=None):
    d = load_cfg()
    if enabled is not None:
        d["enabled"] = bool(enabled)
    if dir is not None:
        d["dir"] = str(dir)
    if driver is not None:
        d["driver"] = str(driver)
    if team is not None:
        d["team"] = str(team)
    try:
        _CFG.parent.mkdir(parents=True, exist_ok=True)
        _CFG.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return d


def _base():
    """Cartella squadra valida (Path) o None se modalita' spenta/percorso ko."""
    c = load_cfg()
    if not c["enabled"] or not c["dir"]:
        return None
    p = Path(c["dir"])
    try:
        p.mkdir(parents=True, exist_ok=True)
        return p
    except Exception:
        return None


def is_active():
    return _base() is not None


def _profile_identity():
    """(team, driver) dal profilo impostato nel menu iniziale (profile.json)."""
    try:
        p = Path(__file__).resolve().parent.parent / "settings" / "profile.json"
        d = json.loads(p.read_text(encoding="utf-8")) or {}
        return (d.get("team") or "").strip(), (d.get("driver") or "").strip()
    except Exception:
        return "", ""


def driver_name():
    return _profile_identity()[1]


def team_name():
    return _profile_identity()[0]


def learn_dir():
    """Cartella dei profili appresi: squadra se attiva, altrimenti None
    (il chiamante usa la cartella locale)."""
    b = _base()
    if b is None:
        return None
    d = b / "learn"
    try:
        d.mkdir(parents=True, exist_ok=True)
    except Exception:
        return None
    return d


# ── stato live (chi guida scrive, gli altri leggono) ──────────────────────
def live_path():
    b = _base()
    return (b / "live_state.json") if b is not None else None


def write_live(state):
    """Scrive lo stato live in modo atomico (tmp + replace). Solo chi guida."""
    p = live_path()
    if p is None:
        return False
    try:
        state = dict(state or {})
        state["ts"] = time.time()
        state["driver"] = state.get("driver") or driver_name()
        tmp = p.with_suffix(".tmp")
        tmp.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
        tmp.replace(p)
        return True
    except Exception:
        return False


def read_live(max_age=8.0):
    """Legge lo stato live del pilota in pista. None se assente o vecchio."""
    p = live_path()
    if p is None or not p.exists():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        ts = d.get("ts")
        if ts is not None and (time.time() - ts) > max_age:
            return None
        return d
    except Exception:
        return None
