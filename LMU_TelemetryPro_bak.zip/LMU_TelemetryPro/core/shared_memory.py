"""
core/shared_memory.py — Wrapper sulla shared memory LMU (pyLMUSharedMemory).

Centralizza l'accesso a SimInfo così non viene istanziato in ogni widget.
Espone letture di alto livello: stato sessione, fasi gialle per-driver,
compound gomme. Tollerante agli errori: se LMU non c'è, ritorna default.
"""
import threading
import time

try:
    from pyLMUSharedMemory.lmu_data import (
        SimInfo as _SimInfo,
        MAX_MAPPED_VEHICLES as _MAX_VEH,
    )
    _AVAILABLE = True
except Exception:
    _SimInfo = None
    _MAX_VEH = 104
    _AVAILABLE = False


def _ttl_cache(ttl):
    """Cache a TTL per metodi senza argomenti: chiamanti diversi (standings,
    relative, mappa) entro la finestra riusano lo stesso risultato invece di
    rifare il giro su tutte le auto. Riduce il picco di lavoro per secondo."""
    def deco(fn):
        name = fn.__name__
        def wrapper(self):
            now = time.monotonic()
            ent = self._mcache.get(name)
            if ent is not None and (now - ent[0]) < ttl:
                return ent[1]
            val = fn(self)
            self._mcache[name] = (now, val)
            return val
        wrapper.__name__ = name
        return wrapper
    return deco


class SharedMemory:
    """Accesso condiviso alla shared memory LMU. Singleton."""

    _instance = None
    _lock = threading.Lock()

    def __init__(self):
        self._sim = None
        self._last_et = None          # ultimo mCurrentET letto (per rilevare pausa)
        self._et_frozen_since = None  # da quando il tempo è fermo (monotonic)
        self._sim_cache = None        # copia condivisa entro un frame (anti-scatto)
        self._sim_cache_t = 0.0
        self._sim_ttl = 0.012         # 12ms: i widget nello stesso frame riusano 1 copia
        self._mcache = {}             # cache TTL per i get_* pesanti (condivisa tra widget)

    @classmethod
    def instance(cls) -> "SharedMemory":
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    def _get_sim(self):
        # _SimInfo copia tutta la shared memory alla creazione. Ricrearlo per OGNI
        # lettura di OGNI widget = molte copie pesanti per frame -> scatti.
        # Cache a TTL brevissimo: i widget che leggono nello stesso frame riusano
        # la stessa copia; i dati restano comunque freschi (sim ~50-90Hz).
        if not _AVAILABLE:
            return None
        now = time.monotonic()
        if self._sim_cache is not None and (now - self._sim_cache_t) < self._sim_ttl:
            return self._sim_cache
        try:
            self._sim_cache = _SimInfo()
            self._sim_cache_t = now
            return self._sim_cache
        except Exception:
            self._sim_cache = None
            return None

    # ── SESSIONE ──────────────────────────────────────────────────────
    def is_on_track(self) -> bool:
        """True se sei in pista (realtime) e il gioco NON è in pausa.
        False nei menu, in pausa e nei replay.

        Rilevazione pausa: quando il gioco è in pausa il tempo di sessione
        (mCurrentET) si congela. Se resta fermo per oltre 0.5s consideriamo
        il gioco in pausa e nascondiamo gli overlay.

        In dubbio (shared memory non disponibile) ritorna True per non
        nascondere i widget per errore.
        """
        try:
            sim = self._get_sim()
            if not sim:
                self._last_et = None
                self._et_frozen_since = None
                return True
            si = sim.scoring.scoringInfo
            if not bool(si.mInRealtime):
                self._last_et = None
                self._et_frozen_since = None
                return False
            # ── rilevazione pausa: il tempo di sessione si ferma ──
            et = float(si.mCurrentET)
            now = time.monotonic()
            if self._last_et is not None and et == self._last_et:
                if self._et_frozen_since is None:
                    self._et_frozen_since = now
                elif (now - self._et_frozen_since) > 0.5:
                    return False          # tempo fermo da >0.5s = pausa
            else:
                self._et_frozen_since = None
            self._last_et = et
            return True
        except Exception:
            self._sim = None
            return True

    def game_phase(self):
        """mGamePhase corrente (0 garage,1 warmup,2 gridwalk,3 formation,
        4 countdown,5 green,6 FCY,7 stopped,8 over,9 paused) o None."""
        try:
            sim = self._get_sim()
            if not sim:
                return None
            return int(sim.scoring.scoringInfo.mGamePhase)
        except Exception:
            return None

    def read_session(self):
        """(session_type, remaining_secs, [s1,s2,s3]). Default se non disponibile."""
        try:
            sim = self._get_sim()
            if not sim:
                return 0, 0.0, [11, 11, 11]
            si = sim.scoring.scoringInfo
            session_type = int(si.mSession)
            remaining = max(0.0, float(si.mEndET) - float(si.mCurrentET)) if si.mEndET > 0 else 0.0
            sector_flags = [int(si.mSectorFlag[i]) for i in range(3)]
            return session_type, remaining, sector_flags
        except Exception:
            self._sim = None
            return 0, 0.0, [11, 11, 11]

    # ── FASI GIALLE per-driver ────────────────────────────────────────
    def get_car_states(self) -> dict:
        """{mID: {'in_pits':bool, 'garage':bool, 'moving':bool, 'is_player':bool}}
        per ogni auto. Usato per la logica dello stint:
        - in pista e in movimento = stint attivo
        - in garage / fermo in box = stint non ancora partito."""
        try:
            sim = self._get_sim()
            if not sim:
                return {}
            out = {}
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            for i in range(min(num, _MAX_VEH)):
                v = sim.scoring.vehScoringInfo[i]
                vv = v.mLocalVel
                speed = (vv.x * vv.x + vv.y * vv.y + vv.z * vv.z) ** 0.5
                try:
                    garage = bool(v.mInGarageStall)
                except Exception:
                    garage = False
                out[int(v.mID)] = {
                    "in_pits": bool(v.mInPits),
                    "garage": garage,
                    "moving": speed > 3.0,
                    "is_player": bool(v.mIsPlayer),
                }
            return out
        except Exception:
            self._sim = None
            return {}

    def get_weather(self):
        """{'air':°C, 'track':°C, 'wet':bool, 'raining':0-1, 'wetness':0-1}.
        wet=True se pista bagnata (wetness o pioggia significativa)."""
        try:
            sim = self._get_sim()
            if not sim:
                return None
            si = sim.scoring.scoringInfo
            air = float(si.mAmbientTemp)
            track = float(si.mTrackTemp)
            raining = float(si.mRaining)
            wetness = float(si.mAvgPathWetness)
            wet = (wetness > 0.10) or (raining > 0.10)
            return {"air": air, "track": track, "wet": wet,
                    "raining": raining, "wetness": wetness}
        except Exception:
            self._sim = None
            return None

    def get_session_time(self):
        """Tempo di gara trascorso in secondi (mCurrentET). Parte da 0 al via,
        anche online. None se non disponibile."""
        try:
            sim = self._get_sim()
            if not sim:
                return None
            return float(sim.scoring.scoringInfo.mCurrentET)
        except Exception:
            self._sim = None
            return None

    def get_track_name(self):
        """Nome circuito corrente (mTrackName), stringa. '' se non disponibile."""
        try:
            sim = self._get_sim()
            if not sim:
                return ""
            raw = bytes(sim.scoring.scoringInfo.mTrackName)
            return raw.split(b"\x00")[0].decode("utf-8", "ignore").strip()
        except Exception:
            self._sim = None
            return ""

    def get_session_clock(self):
        """(total_et, current_et, time_of_day) in secondi.
        total_et = durata sessione (mEndET), 0 se non disponibile."""
        try:
            sim = self._get_sim()
            if not sim:
                return 0.0, 0.0, 43200.0
            si = sim.scoring.scoringInfo
            total = float(si.mEndET) if si.mEndET > 0 else 0.0
            cur = float(si.mCurrentET)
            tod = float(si.mTimeOfDay)
            return total, cur, tod
        except Exception:
            self._sim = None
            return 0.0, 0.0, 43200.0

    def get_positions(self):
        """(track_len, {mID: mLapDist}) — distanza sul giro di ogni auto.

        Usato per il gap LIVE in gara (come il Relative): la differenza di
        distanza in pista convertita in tempo si aggiorna a ogni frame, non
        solo ai punti di cronometraggio.
        """
        try:
            sim = self._get_sim()
            if not sim:
                return 0.0, {}
            si = sim.scoring.scoringInfo
            track_len = float(si.mLapDist)
            out = {}
            num = int(si.mNumVehicles)
            for i in range(min(num, _MAX_VEH)):
                v = sim.scoring.vehScoringInfo[i]
                out[int(v.mID)] = float(v.mLapDist)
            return track_len, out
        except Exception:
            return 0.0, {}

    def get_totals(self):
        """(track_len, {mID: distanza_totale}) — distanza monotona crescente
        (giri completati * lunghezza pista + mLapDist). Serve al gap a TEMPO
        (confronto dell'istante in cui due auto passano lo stesso punto)."""
        try:
            sim = self._get_sim()
            if not sim:
                return 0.0, {}
            si = sim.scoring.scoringInfo
            track_len = float(si.mLapDist)
            out = {}
            num = int(si.mNumVehicles)
            for i in range(min(num, _MAX_VEH)):
                v = sim.scoring.vehScoringInfo[i]
                laps = max(0, int(v.mTotalLaps))
                out[int(v.mID)] = laps * track_len + float(v.mLapDist)
            return track_len, out
        except Exception:
            return 0.0, {}

    def get_yellow_phases(self) -> dict:
        """{mID: bool} — mIndividualPhase==10 oppure mUnderYellow."""
        try:
            sim = self._get_sim()
            if not sim:
                return {}
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            out = {}
            for i in range(min(num, _MAX_VEH)):
                v = sim.scoring.vehScoringInfo[i]
                out[int(v.mID)] = (int(v.mIndividualPhase) == 10 or bool(v.mUnderYellow))
            return out
        except Exception:
            self._sim = None
            return {}

    # ── COMPOUND GOMME per-driver ─────────────────────────────────────
    @_ttl_cache(0.5)
    def get_compounds(self) -> dict:
        """{mID: 'S'|'M'|'H'|'W'|...} per ogni veicolo nello scoring."""
        try:
            sim = self._get_sim()
            if not sim:
                return {}
            out = {}
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            for i in range(min(num, _MAX_VEH)):
                vid = int(sim.scoring.vehScoringInfo[i].mID)
                out[vid] = sim.get_compound_name(i)
            return out
        except Exception:
            self._sim = None
            return {}

    @_ttl_cache(0.5)
    def get_pitstops(self) -> dict:
        """{mID: num_pitstops} per ogni auto (mNumPitstops nello scoring)."""
        try:
            sim = self._get_sim()
            if not sim:
                return {}
            out = {}
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            for i in range(min(num, _MAX_VEH)):
                v = sim.scoring.vehScoringInfo[i]
                out[int(v.mID)] = int(v.mNumPitstops)
            return out
        except Exception:
            return {}

    @_ttl_cache(0.5)
    def get_sectors(self) -> dict:
        """{mID: {'last': [s1,s2,s3], 'best': [s1,s2,s3], 'cur': [s1,s2]}} per ogni auto.

        I campi scoring danno sector2 CUMULATIVO (s1+s2), quindi ricavo i singoli.
        s3 si ricava: lastLap - lastSector2. -1 se non disponibile.
        """
        try:
            sim = self._get_sim()
            if not sim:
                return {}
            out = {}
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            for i in range(min(num, _MAX_VEH)):
                v = sim.scoring.vehScoringInfo[i]
                mid = int(v.mID)
                # last
                ls1 = float(v.mLastSector1)
                ls2c = float(v.mLastSector2)   # cumulativo s1+s2
                llap = float(v.mLastLapTime)
                ls2 = (ls2c - ls1) if (ls1 > 0 and ls2c > 0) else -1
                ls3 = (llap - ls2c) if (llap > 0 and ls2c > 0) else -1
                # best (settori del best lap)
                bs1 = float(v.mBestLapSector1)
                bs2c = float(v.mBestLapSector2)
                blap = float(v.mBestLapTime)
                bs2 = (bs2c - bs1) if (bs1 > 0 and bs2c > 0) else -1
                bs3 = (blap - bs2c) if (blap > 0 and bs2c > 0) else -1
                # cur (settori in corso)
                cs1 = float(v.mCurSector1)
                cs2c = float(v.mCurSector2)
                cs2 = (cs2c - cs1) if (cs1 > 0 and cs2c > 0) else -1
                out[mid] = {
                    "last": [ls1 if ls1 > 0 else -1, ls2, ls3],
                    "best": [bs1 if bs1 > 0 else -1, bs2, bs3],
                    "cur":  [cs1 if cs1 > 0 else -1, cs2],
                    "sector": int(v.mSector),  # 0=S3,1=S1,2=S2
                }
            return out
        except Exception:
            return {}

    def get_pit_count(self) -> dict:
        return self.get_pitstops()

    @_ttl_cache(0.5)
    def get_tyre_wear(self) -> dict:
        """{mID: wear_pct} usura gomme per ogni auto (0-100, 100=nuova).

        mWear è 'fraction of maximum' rimanente: 1.0=nuova, 0.0=finita.
        Faccio la media delle 4 ruote. Disponibile per TUTTI i piloti.
        """
        try:
            sim = self._get_sim()
            if not sim or not sim.telemetry:
                return {}
            out = {}
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            for i in range(min(num, _MAX_VEH)):
                t = sim.telemetry.telemInfo[i]
                tid = int(t.mID)
                try:
                    ws = [float(t.mWheels[w].mWear) for w in range(4)]
                    avg = sum(ws) / 4.0
                    out[tid] = round(avg * 100, 0)
                except Exception:
                    out[tid] = None
            return out
        except Exception:
            return {}

    @_ttl_cache(0.5)
    def get_track_limits(self) -> dict:
        """{mID: {'steps': int, 'per_penalty': int, 'per_point': int}} per ogni auto.

        mTrackLimitsSteps (telemetry per veicolo) = punti accumulati.
        mTrackLimitsStepsPerPenalty / PerPoint (scoring globale) = soglie.
        Penalità quando steps >= per_penalty. Track limit "pieno" = per_point.
        """
        try:
            sim = self._get_sim()
            if not sim or not sim.telemetry:
                return {}
            si = sim.scoring.scoringInfo
            try:
                per_penalty = int(si.mTrackLimitsStepsPerPenalty)
            except Exception:
                per_penalty = 0
            try:
                per_point = int(si.mTrackLimitsStepsPerPoint)
            except Exception:
                per_point = 0
            out = {}
            from pyLMUSharedMemory.lmu_data import MAX_MAPPED_VEHICLES as _MM
            num = int(si.mNumVehicles)
            for i in range(min(num, _MM)):
                t = sim.telemetry.telemInfo[i]
                tid = int(t.mID)
                try:
                    steps = int(t.mTrackLimitsSteps)
                except Exception:
                    steps = 0
                out[tid] = {"steps": steps, "per_penalty": per_penalty, "per_point": per_point}
            return out
        except Exception:
            return {}

    def get_lap_valid(self) -> dict:
        """{mID: bool} — True se l'ultimo giro è valido (conta il tempo).

        mCountLapFlag: 0=non contare, 1=conta giro ma NON il tempo (invalido
        per track limits), 2=conta giro e tempo (valido). Disponibile per
        ogni auto nello scoring (come TinyPedal).
        """
        try:
            sim = self._get_sim()
            if not sim:
                return {}
            out = {}
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            for i in range(min(num, _MAX_VEH)):
                v = sim.scoring.vehScoringInfo[i]
                out[int(v.mID)] = (int(v.mCountLapFlag) >= 2)
            return out
        except Exception:
            return {}

    @_ttl_cache(0.5)
    def get_compounds_4(self) -> dict:
        """{mID: ['S','M','H','W'(x4 ruote FL,FR,RL,RR)]} per ogni veicolo.

        Legge mWheels[].mCompoundType dal telemetry di OGNI veicolo
        (come TinyPedal), indicizzato dal proprio mID.
        """
        _CT = {0: "S", 1: "M", 2: "H", 3: "W"}
        try:
            sim = self._get_sim()
            if not sim or not sim.telemetry:
                return {}
            out = {}
            from pyLMUSharedMemory.lmu_data import MAX_MAPPED_VEHICLES as _MM
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            for i in range(min(max(num, 0), _MM)):
                t = sim.telemetry.telemInfo[i]
                tid = int(t.mID)
                try:
                    four = [_CT.get(int(t.mWheels[w].mCompoundType), "") for w in range(4)]
                except Exception:
                    four = ["", "", "", ""]
                out[tid] = four
            return out
        except Exception:
            return {}

    @_ttl_cache(0.5)
    def get_all_maps(self) -> dict:
        """Tutte le mappe per-auto in UNA passata scoring + UNA telemetry,
        invece di 6-8 giri separati. Riduce drasticamente il picco di lavoro
        quando standings/relative ricalcolano (1×/sec). Cacheato e condiviso.

        Ritorna: compounds, compounds4, sectors, wear, track_limits,
        pitstops, car_states, lap_valid (stessa struttura dei get_* singoli).
        """
        empty = {"compounds": {}, "compounds4": {}, "sectors": {}, "wear": {},
                 "track_limits": {}, "pitstops": {}, "car_states": {}, "lap_valid": {}}
        try:
            sim = self._get_sim()
            if not sim:
                return empty
            compounds = {}; sectors = {}; pitstops = {}; car_states = {}; lap_valid = {}
            num = int(sim.scoring.scoringInfo.mNumVehicles)
            n = min(num, _MAX_VEH)
            # ── UNA passata su scoring ──
            for i in range(n):
                v = sim.scoring.vehScoringInfo[i]
                mid = int(v.mID)
                # compound (gomma attuale)
                try:
                    compounds[mid] = sim.get_compound_name(i)
                except Exception:
                    compounds[mid] = ""
                # settori
                ls1 = float(v.mLastSector1); ls2c = float(v.mLastSector2); llap = float(v.mLastLapTime)
                ls2 = (ls2c - ls1) if (ls1 > 0 and ls2c > 0) else -1
                ls3 = (llap - ls2c) if (llap > 0 and ls2c > 0) else -1
                bs1 = float(v.mBestLapSector1); bs2c = float(v.mBestLapSector2); blap = float(v.mBestLapTime)
                bs2 = (bs2c - bs1) if (bs1 > 0 and bs2c > 0) else -1
                bs3 = (blap - bs2c) if (blap > 0 and bs2c > 0) else -1
                cs1 = float(v.mCurSector1); cs2c = float(v.mCurSector2)
                cs2 = (cs2c - cs1) if (cs1 > 0 and cs2c > 0) else -1
                sectors[mid] = {
                    "last": [ls1 if ls1 > 0 else -1, ls2, ls3],
                    "best": [bs1 if bs1 > 0 else -1, bs2, bs3],
                    "cur":  [cs1 if cs1 > 0 else -1, cs2],
                    "sector": int(v.mSector),
                }
                # pitstops
                pitstops[mid] = int(v.mNumPitstops)
                # stato auto
                vv = v.mLocalVel
                speed = (vv.x * vv.x + vv.y * vv.y + vv.z * vv.z) ** 0.5
                try:
                    garage = bool(v.mInGarageStall)
                except Exception:
                    garage = False
                car_states[mid] = {
                    "in_pits": bool(v.mInPits),
                    "garage": garage,
                    "moving": speed > 3.0,
                    "is_player": bool(v.mIsPlayer),
                }
                # lap valid
                lap_valid[mid] = (int(v.mCountLapFlag) >= 2)

            # ── UNA passata su telemetry (gomme×4, usura, track limits) ──
            compounds4 = {}; wear = {}; track_limits = {}
            _CT = {0: "S", 1: "M", 2: "H", 3: "W"}
            tel = getattr(sim, "telemetry", None)
            if tel:
                si = sim.scoring.scoringInfo
                try:
                    per_penalty = int(si.mTrackLimitsStepsPerPenalty)
                except Exception:
                    per_penalty = 0
                try:
                    per_point = int(si.mTrackLimitsStepsPerPoint)
                except Exception:
                    per_point = 0
                for i in range(n):
                    t = tel.telemInfo[i]
                    tid = int(t.mID)
                    try:
                        compounds4[tid] = [_CT.get(int(t.mWheels[w].mCompoundType), "") for w in range(4)]
                    except Exception:
                        compounds4[tid] = ["", "", "", ""]
                    try:
                        ws = [float(t.mWheels[w].mWear) for w in range(4)]
                        wear[tid] = round(sum(ws) / 4.0 * 100, 0)
                    except Exception:
                        wear[tid] = None
                    try:
                        steps = int(t.mTrackLimitsSteps)
                    except Exception:
                        steps = 0
                    track_limits[tid] = {"steps": steps, "per_penalty": per_penalty, "per_point": per_point}

            return {"compounds": compounds, "compounds4": compounds4, "sectors": sectors,
                    "wear": wear, "track_limits": track_limits, "pitstops": pitstops,
                    "car_states": car_states, "lap_valid": lap_valid}
        except Exception:
            self._sim = None
            return empty
